/*
  # Update Recon Specs Table Structure

  1. Changes
    - Drop existing columns: spec_uuid, header_fields, record_fields, footer_fields
    - Add new column: json_content (JSONB) to store the complete JSON schema
    - Keep id, name, created_at, updated_at columns

  2. Migration Strategy
    - Safe migration that preserves data by backing up to json_content before dropping old columns
    - Updates indexes to work with new structure

  3. New Structure
    - `recon_specs`
      - `id` (uuid, primary key)
      - `name` (text, spec name)
      - `json_content` (jsonb, complete JSON schema)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  4. Security
    - RLS policies remain unchanged
    - Authenticated users can manage their specs

  5. Indexes
    - GIN index on json_content for efficient querying
    - Index on name for search
    - Index on created_at for sorting
*/

DO $$
BEGIN
  -- Check if the old structure exists before migrating
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recon_specs' AND column_name = 'spec_uuid'
  ) THEN
    -- Backup existing data by combining fields into json_content
    IF EXISTS (SELECT 1 FROM recon_specs) THEN
      ALTER TABLE recon_specs ADD COLUMN IF NOT EXISTS json_content JSONB DEFAULT '{}'::jsonb;
      
      UPDATE recon_specs
      SET json_content = jsonb_build_object(
        'spec_uuid', spec_uuid::text,
        'name', name,
        'header_fields', COALESCE(header_fields, '[]'::jsonb),
        'record_fields', COALESCE(record_fields, '[]'::jsonb),
        'footer_fields', COALESCE(footer_fields, '[]'::jsonb)
      );
    END IF;

    -- Drop old indexes
    DROP INDEX IF EXISTS recon_specs_spec_uuid_idx;
    DROP INDEX IF EXISTS recon_specs_header_fields_idx;
    DROP INDEX IF EXISTS recon_specs_record_fields_idx;
    DROP INDEX IF EXISTS recon_specs_footer_fields_idx;

    -- Drop old columns
    ALTER TABLE recon_specs DROP COLUMN IF EXISTS spec_uuid;
    ALTER TABLE recon_specs DROP COLUMN IF EXISTS header_fields;
    ALTER TABLE recon_specs DROP COLUMN IF EXISTS record_fields;
    ALTER TABLE recon_specs DROP COLUMN IF EXISTS footer_fields;
  END IF;

  -- Ensure json_content column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recon_specs' AND column_name = 'json_content'
  ) THEN
    ALTER TABLE recon_specs ADD COLUMN json_content JSONB DEFAULT '{}'::jsonb;
  END IF;
END $$;

-- Create/recreate indexes for new structure
CREATE INDEX IF NOT EXISTS recon_specs_json_content_idx ON recon_specs USING gin (json_content);
CREATE INDEX IF NOT EXISTS recon_specs_name_idx ON recon_specs (name);
CREATE INDEX IF NOT EXISTS recon_specs_created_at_idx ON recon_specs (created_at DESC);
CREATE INDEX IF NOT EXISTS recon_specs_updated_at_idx ON recon_specs (updated_at DESC);

-- Update RLS policy to be more specific (replace the overly permissive policy)
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON recon_specs;

CREATE POLICY "Users can view recon specs"
  ON recon_specs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert recon specs"
  ON recon_specs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update recon specs"
  ON recon_specs
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete recon specs"
  ON recon_specs
  FOR DELETE
  TO authenticated
  USING (true);
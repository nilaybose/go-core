/*
  # Create Recon Specs Table

  1. New Tables
    - `recon_specs`
      - `id` (uuid, primary key, auto-generated)
      - `spec_uuid` (uuid, unique, identifies the spec)
      - `name` (text, spec name for identification)
      - `header_fields` (jsonb, array of field definitions for header section)
      - `record_fields` (jsonb, array of field definitions for record section)
      - `footer_fields` (jsonb, array of field definitions for footer section)
      - `created_at` (timestamptz, auto-generated)
      - `updated_at` (timestamptz, auto-updated on changes)
  
  2. Security
    - Enable RLS on `recon_specs` table
    - Add policy for authenticated users to manage their own specs
  
  3. Indexes
    - Index on spec_uuid for fast lookups
    - Index on name for search functionality
    - Index on created_at for sorting
    - GIN indexes on JSONB fields for efficient querying
  
  4. Notes
    - Each field in header_fields, record_fields, and footer_fields will have structure:
      {name: string, type: string, length: number}
    - JSONB format allows flexible field definitions while maintaining query performance
*/

CREATE TABLE IF NOT EXISTS recon_specs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  spec_uuid UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  header_fields JSONB DEFAULT '[]'::jsonb,
  record_fields JSONB DEFAULT '[]'::jsonb,
  footer_fields JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE recon_specs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all operations for authenticated users"
  ON recon_specs
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS recon_specs_spec_uuid_idx ON recon_specs (spec_uuid);
CREATE INDEX IF NOT EXISTS recon_specs_name_idx ON recon_specs (name);
CREATE INDEX IF NOT EXISTS recon_specs_created_at_idx ON recon_specs (created_at DESC);
CREATE INDEX IF NOT EXISTS recon_specs_updated_at_idx ON recon_specs (updated_at DESC);
CREATE INDEX IF NOT EXISTS recon_specs_header_fields_idx ON recon_specs USING gin (header_fields);
CREATE INDEX IF NOT EXISTS recon_specs_record_fields_idx ON recon_specs USING gin (record_fields);
CREATE INDEX IF NOT EXISTS recon_specs_footer_fields_idx ON recon_specs USING gin (footer_fields);
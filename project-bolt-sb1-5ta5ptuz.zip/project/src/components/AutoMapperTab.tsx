import { useState, useEffect } from 'react';
import { Download, Save, Wand2, Loader2, CheckCircle, AlertCircle, FileJson, Plus, List as ListIcon } from 'lucide-react';
import { api, SpecMapping, ReconSpec } from '../api';
import { extractFieldsWithMetadata, buildFieldCatalog, findArrayFields, calculateFieldSimilarity, FieldMetadata, FieldCatalog } from '../utils/fieldExtractor';
import { FieldTree } from './mapping/FieldTree';
import { MappingCard } from './mapping/MappingCard';
import { FieldMappingModal } from './mapping/FieldMappingModal';
import { ListMappingModal } from './mapping/ListMappingModal';
import { GlobalTransformationsPanel } from './mapping/GlobalTransformationsPanel';
import { CompleteMappingJSON, FieldMapping, ListMapping, GlobalTransformations } from '../types/mapping';

export function AutoMapperTab() {
  const [specMappers, setSpecMappers] = useState<SpecMapping[]>([]);
  const [reconSpecs, setReconSpecs] = useState<ReconSpec[]>([]);
  const [selectedSpecMapper, setSelectedSpecMapper] = useState<string>('');
  const [selectedReconMapper, setSelectedReconMapper] = useState<string>('');
  const [currentMapper, setCurrentMapper] = useState<any>(null);

  const [sourceFields, setSourceFields] = useState<FieldMetadata[]>([]);
  const [targetFields, setTargetFields] = useState<FieldMetadata[]>([]);
  const [sourceCatalog, setSourceCatalog] = useState<FieldCatalog>({});
  const [targetCatalog, setTargetCatalog] = useState<FieldCatalog>({});

  const [fieldMappings, setFieldMappings] = useState<FieldMapping[]>([]);
  const [listMappings, setListMappings] = useState<ListMapping[]>([]);
  const [globalTransformations, setGlobalTransformations] = useState<GlobalTransformations>({
    pre_processing_transformations: [],
    post_processing_transformations: [],
    validation_rules: []
  });

  const [selectedSourceField, setSelectedSourceField] = useState<FieldMetadata | undefined>();
  const [selectedTargetField, setSelectedTargetField] = useState<FieldMetadata | undefined>();
  const [draggedField, setDraggedField] = useState<FieldMetadata | undefined>();

  const [showFieldMappingModal, setShowFieldMappingModal] = useState(false);
  const [showListMappingModal, setShowListMappingModal] = useState(false);
  const [editingMapping, setEditingMapping] = useState<FieldMapping | undefined>();
  const [editingListMapping, setEditingListMapping] = useState<ListMapping | undefined>();

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [activeView, setActiveView] = useState<'mapping' | 'global'>('mapping');

  useEffect(() => {
    loadSpecMappers();
    loadReconSpecs();
  }, []);

  useEffect(() => {
    if (selectedSpecMapper && selectedReconMapper) {
      loadExistingMapper();
    }
  }, [selectedSpecMapper, selectedReconMapper]);

  const loadSpecMappers = async () => {
    try {
      const result = await api.listSpecMappings();
      setSpecMappers(result.mappings);
    } catch (error) {
      showNotification('error', 'Failed to load spec mappers');
    }
  };

  const loadReconSpecs = async () => {
    try {
      const result = await api.listReconSpecs();
      setReconSpecs(result.specs);
    } catch (error) {
      showNotification('error', 'Failed to load recon specs');
    }
  };

  const loadExistingMapper = async () => {
    setLoading(true);
    try {
      const selectedSpec = specMappers.find(s => s.file_id === selectedSpecMapper);
      const selectedRecon = reconSpecs.find(r => r.id === selectedReconMapper);

      if (!selectedSpec || !selectedRecon) {
        setLoading(false);
        return;
      }

      const sourceFieldsList = extractFieldsWithMetadata(selectedSpec.json_content);
      const targetFieldsList = extractFieldsWithMetadata(selectedRecon.json_content);

      setSourceFields(sourceFieldsList);
      setTargetFields(targetFieldsList);
      setSourceCatalog(buildFieldCatalog(sourceFieldsList));
      setTargetCatalog(buildFieldCatalog(targetFieldsList));

      const result = await api.getAutoMapperByPair(selectedSpecMapper, selectedReconMapper);
      if (result.mapper && result.mapper.mapping_json) {
        const mappingJson = result.mapper.mapping_json as CompleteMappingJSON;
        setCurrentMapper(result.mapper);
        setFieldMappings(mappingJson.field_mappings || []);
        setListMappings(mappingJson.list_mappings || []);
        setGlobalTransformations(mappingJson.global_transformations || {
          pre_processing_transformations: [],
          post_processing_transformations: [],
          validation_rules: []
        });
        setHasUnsavedChanges(false);
      } else {
        setCurrentMapper(null);
        setFieldMappings([]);
        setListMappings([]);
        setGlobalTransformations({
          pre_processing_transformations: [],
          post_processing_transformations: [],
          validation_rules: []
        });
        setHasUnsavedChanges(false);
      }
    } catch (error) {
      showNotification('error', 'Failed to load existing mapper');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveMapping = async () => {
    if (!selectedSpecMapper || !selectedReconMapper) {
      showNotification('error', 'Please select both spec and recon mappers');
      return;
    }

    const selectedSpec = specMappers.find(s => s.file_id === selectedSpecMapper);
    const selectedRecon = reconSpecs.find(r => r.id === selectedReconMapper);

    if (!selectedSpec || !selectedRecon) {
      showNotification('error', 'Selected mappers not found');
      return;
    }

    setSaving(true);
    try {
      const completeMapping: CompleteMappingJSON = {
        version: '2.0',
        metadata: {
          version: '2.0',
          created_at: currentMapper?.created_at || new Date().toISOString(),
          updated_at: new Date().toISOString(),
          description: `Mapping from ${selectedSpec.transaction_layout} to ${selectedRecon.name}`
        },
        source_schema_info: {
          mapper_uuid: selectedSpec.file_id,
          transaction_layout: selectedSpec.transaction_layout,
          full_field_catalog: Object.fromEntries(
            Object.entries(sourceCatalog).map(([path, field]) => [
              path,
              {
                field_type: field.field_type,
                sample_values: field.sample_values,
                is_array: field.is_array,
                parent_path: field.parent_full_path
              }
            ])
          )
        },
        destination_schema_info: {
          mapper_uuid: selectedRecon.id,
          name: selectedRecon.name,
          full_field_catalog: Object.fromEntries(
            Object.entries(targetCatalog).map(([path, field]) => [
              path,
              {
                field_type: field.field_type,
                is_required: field.is_required || false,
                is_array: field.is_array,
                parent_path: field.parent_full_path
              }
            ])
          )
        },
        field_mappings: fieldMappings,
        list_mappings: listMappings,
        global_transformations: globalTransformations
      };

      if (currentMapper) {
        await api.updateAutoMapper(currentMapper.mapper_uuid, completeMapping);
        showNotification('success', 'Mapping configuration updated successfully');
      } else {
        const result = await api.createAutoMapper({
          spec_mapper_uuid: selectedSpecMapper,
          recon_mapper_uuid: selectedReconMapper,
          mapping_json: completeMapping,
        });
        setCurrentMapper({ mapper_uuid: result.mapper_uuid });
        showNotification('success', 'Mapping configuration saved successfully');
      }
      setHasUnsavedChanges(false);
    } catch (error) {
      showNotification('error', 'Failed to save mapping');
    } finally {
      setSaving(false);
    }
  };

  const handleAutoMap = () => {
    if (!selectedSpecMapper || !selectedReconMapper) {
      showNotification('error', 'Please select both spec and recon mappers');
      return;
    }

    const newMappings: FieldMapping[] = [];
    let mappedCount = 0;

    const sourcePrimitives = sourceFields.filter(f => !f.is_array && f.field_type !== 'object');
    const targetPrimitives = targetFields.filter(f => !f.is_array && f.field_type !== 'object');

    const alreadyMappedTargets = new Set(fieldMappings.map(m => m.target_full_path));

    sourcePrimitives.forEach(sourceField => {
      targetPrimitives.forEach(targetField => {
        if (alreadyMappedTargets.has(targetField.field_full_path)) return;

        const similarity = calculateFieldSimilarity(sourceField, targetField);
        if (similarity > 0.7) {
          const mapping: FieldMapping = {
            mapping_id: `auto_${Date.now()}_${mappedCount}`,
            mapping_type: 'direct',
            source_full_path: sourceField.field_full_path,
            target_full_path: targetField.field_full_path,
            source_type: sourceField.field_type,
            target_type: targetField.field_type,
            is_required: false,
            execution_order: mappedCount,
            confidence: similarity
          };

          if (sourceField.field_type !== targetField.field_type) {
            mapping.nlp_transformation_text = `Convert ${sourceField.field_type} to ${targetField.field_type}`;
          }

          newMappings.push(mapping);
          alreadyMappedTargets.add(targetField.field_full_path);
          mappedCount++;
        }
      });
    });

    setFieldMappings([...fieldMappings, ...newMappings]);
    setHasUnsavedChanges(true);
    showNotification('success', `Auto-mapped ${mappedCount} fields`);
  };

  const handleFieldMappingDrop = (targetField: FieldMetadata) => {
    if (!draggedField) return;

    const existingMapping = fieldMappings.find(m => m.target_full_path === targetField.field_full_path);
    if (existingMapping) {
      showNotification('error', 'Target field is already mapped');
      return;
    }

    setSelectedSourceField(draggedField);
    setSelectedTargetField(targetField);
    setEditingMapping(undefined);
    setShowFieldMappingModal(true);
  };

  const handleSaveFieldMapping = (mapping: FieldMapping) => {
    const existingIndex = fieldMappings.findIndex(m => m.mapping_id === mapping.mapping_id);
    if (existingIndex >= 0) {
      const updated = [...fieldMappings];
      updated[existingIndex] = mapping;
      setFieldMappings(updated);
    } else {
      setFieldMappings([...fieldMappings, mapping]);
    }
    setHasUnsavedChanges(true);
  };

  const handleDeleteFieldMapping = (mapping: FieldMapping) => {
    setFieldMappings(fieldMappings.filter(m => m.mapping_id !== mapping.mapping_id));
    setHasUnsavedChanges(true);
  };

  const handleEditFieldMapping = (mapping: FieldMapping) => {
    const sourceField = sourceCatalog[mapping.source_full_path];
    const targetField = targetCatalog[mapping.target_full_path];
    if (sourceField && targetField) {
      setSelectedSourceField(sourceField);
      setSelectedTargetField(targetField);
      setEditingMapping(mapping);
      setShowFieldMappingModal(true);
    }
  };

  const handleCreateListMapping = () => {
    const sourceArrays = findArrayFields(sourceCatalog);
    const targetArrays = findArrayFields(targetCatalog);

    if (sourceArrays.length === 0 || targetArrays.length === 0) {
      showNotification('error', 'No array fields found in source or destination');
      return;
    }

    setEditingListMapping(undefined);
    setShowListMappingModal(true);
  };

  const handleSaveListMapping = (mapping: ListMapping) => {
    const existingIndex = listMappings.findIndex(m => m.mapping_id === mapping.mapping_id);
    if (existingIndex >= 0) {
      const updated = [...listMappings];
      updated[existingIndex] = mapping;
      setListMappings(updated);
    } else {
      setListMappings([...listMappings, mapping]);
    }
    setHasUnsavedChanges(true);
  };

  const handleDeleteListMapping = (mapping: ListMapping) => {
    setListMappings(listMappings.filter(m => m.mapping_id !== mapping.mapping_id));
    setHasUnsavedChanges(true);
  };

  const handleEditListMapping = (mapping: ListMapping) => {
    setEditingListMapping(mapping);
    setShowListMappingModal(true);
  };

  const handleDownloadMapping = () => {
    const completeMapping: CompleteMappingJSON = {
      version: '2.0',
      metadata: {
        version: '2.0',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      source_schema_info: {
        mapper_uuid: selectedSpecMapper,
        transaction_layout: specMappers.find(s => s.file_id === selectedSpecMapper)?.transaction_layout || '',
        full_field_catalog: {}
      },
      destination_schema_info: {
        mapper_uuid: selectedReconMapper,
        name: reconSpecs.find(r => r.id === selectedReconMapper)?.name || '',
        full_field_catalog: {}
      },
      field_mappings: fieldMappings,
      list_mappings: listMappings,
      global_transformations: globalTransformations
    };

    const timestamp = new Date().toISOString().split('T')[0];
    api.downloadJSON(completeMapping, `mapping_${timestamp}.json`);
    showNotification('success', 'Mapping downloaded');
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  const mappedTargetPaths = new Set(fieldMappings.map(m => m.target_full_path));
  const mappedSourcePaths = new Set(fieldMappings.map(m => m.source_full_path));

  const selectedSpec = specMappers.find(s => s.file_id === selectedSpecMapper);
  const sourceArrayFields = findArrayFields(sourceCatalog);
  const targetArrayFields = findArrayFields(targetCatalog);
  const targetArrayField = targetArrayFields.length > 0 ? targetArrayFields[0] : undefined;

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50">
      {notification && (
        <div className={`fixed top-4 right-4 z-50 px-6 py-4 rounded-xl shadow-2xl backdrop-blur-sm flex items-center gap-3 ${
          notification.type === 'success'
            ? 'bg-emerald-500/90 text-white'
            : 'bg-red-500/90 text-white'
        }`}>
          {notification.type === 'success' ? (
            <CheckCircle className="w-5 h-5" />
          ) : (
            <AlertCircle className="w-5 h-5" />
          )}
          <span className="font-medium">{notification.message}</span>
        </div>
      )}

      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200 shadow-lg sticky top-0 z-10">
        <div className="px-8 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Auto Mapper
              </h2>
              <p className="text-sm text-gray-600 mt-1">Create intelligent field mappings with transformations</p>
            </div>
            {hasUnsavedChanges && (
              <div className="flex items-center gap-2 text-orange-600 bg-orange-50 px-4 py-2 rounded-lg">
                <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse" />
                <span className="text-sm font-medium">Unsaved changes</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Source Spec Mapper
              </label>
              <select
                value={selectedSpecMapper}
                onChange={(e) => setSelectedSpecMapper(e.target.value)}
                className="w-full px-4 py-3 bg-white border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all outline-none font-medium text-gray-700"
              >
                <option value="">Select a spec mapper...</option>
                {specMappers.map((spec) => (
                  <option key={spec.file_id} value={spec.file_id}>
                    {spec.transaction_layout}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Destination Recon Mapper
              </label>
              <select
                value={selectedReconMapper}
                onChange={(e) => setSelectedReconMapper(e.target.value)}
                className="w-full px-4 py-3 bg-white border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all outline-none font-medium text-gray-700"
              >
                <option value="">Select a recon mapper...</option>
                {reconSpecs.map((recon) => (
                  <option key={recon.id} value={recon.id}>
                    {recon.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleAutoMap}
              disabled={!selectedSpecMapper || !selectedReconMapper || loading}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <Wand2 className="w-5 h-5" />
              Auto Map
            </button>

            <button
              onClick={handleCreateListMapping}
              disabled={!selectedSpecMapper || !selectedReconMapper || loading}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-600 to-red-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <ListIcon className="w-5 h-5" />
              Create List Mapping
            </button>

            <button
              onClick={handleSaveMapping}
              disabled={!selectedSpecMapper || !selectedReconMapper || saving}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {saving ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Save className="w-5 h-5" />
              )}
              Save Configuration
            </button>

            <button
              onClick={handleDownloadMapping}
              disabled={fieldMappings.length === 0 && listMappings.length === 0}
              className="flex items-center gap-2 px-5 py-3 bg-white border-2 border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 hover:border-gray-400 hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <FileJson className="w-4 h-4" />
              Download
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-8">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
              <p className="text-gray-600 font-medium">Loading configuration...</p>
            </div>
          </div>
        ) : !selectedSpecMapper || !selectedReconMapper ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center max-w-md">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Wand2 className="w-10 h-10 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Get Started</h3>
              <p className="text-gray-600 leading-relaxed">
                Select source and destination mappers to create field mappings with transformations.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex gap-4 mb-6">
              <button
                onClick={() => setActiveView('mapping')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                  activeView === 'mapping'
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                    : 'bg-white text-gray-700 border-2 border-gray-300'
                }`}
              >
                Field & List Mappings
              </button>
              <button
                onClick={() => setActiveView('global')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                  activeView === 'global'
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                    : 'bg-white text-gray-700 border-2 border-gray-300'
                }`}
              >
                Global Transformations
              </button>
            </div>

            {activeView === 'mapping' ? (
              <>
                <div className="grid grid-cols-12 gap-6">
                  <div className="col-span-5">
                    <FieldTree
                      fields={sourceFields}
                      title="Source Fields"
                      onFieldSelect={setSelectedSourceField}
                      onFieldDragStart={setDraggedField}
                      selectedPath={selectedSourceField?.field_full_path}
                      mappedPaths={mappedSourcePaths}
                    />
                  </div>

                  <div className="col-span-2 flex flex-col items-center justify-center">
                    <div className="bg-white rounded-xl border-2 border-gray-200 p-6 shadow-lg">
                      <div className="text-center mb-4">
                        <div className="text-sm font-semibold text-gray-700 mb-2">Mappings</div>
                        <div className="text-3xl font-bold text-blue-600">
                          {fieldMappings.length + listMappings.length}
                        </div>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Fields:</span>
                          <span className="font-semibold">{fieldMappings.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Lists:</span>
                          <span className="font-semibold">{listMappings.length}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-5">
                    <div
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => {
                        e.preventDefault();
                        const fieldData = e.dataTransfer.getData('field');
                        if (fieldData && selectedTargetField) {
                          handleFieldMappingDrop(selectedTargetField);
                        }
                      }}
                    >
                      <FieldTree
                        fields={targetFields}
                        title="Destination Fields"
                        onFieldSelect={(field) => {
                          setSelectedTargetField(field);
                          if (draggedField) {
                            handleFieldMappingDrop(field);
                          }
                        }}
                        selectedPath={selectedTargetField?.field_full_path}
                        mappedPaths={mappedTargetPaths}
                      />
                    </div>
                  </div>
                </div>

                {(fieldMappings.length > 0 || listMappings.length > 0) && (
                  <div className="bg-white rounded-xl border-2 border-gray-200 shadow-lg p-6">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Active Mappings</h3>
                    <div className="space-y-3">
                      {fieldMappings.map((mapping) => (
                        <MappingCard
                          key={mapping.mapping_id}
                          mapping={mapping}
                          type="field"
                          onEdit={() => handleEditFieldMapping(mapping)}
                          onDelete={() => handleDeleteFieldMapping(mapping)}
                        />
                      ))}
                      {listMappings.map((mapping) => (
                        <MappingCard
                          key={mapping.mapping_id}
                          mapping={mapping}
                          type="list"
                          onEdit={() => handleEditListMapping(mapping)}
                          onDelete={() => handleDeleteListMapping(mapping)}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <GlobalTransformationsPanel
                transformations={globalTransformations}
                onChange={(t) => {
                  setGlobalTransformations(t);
                  setHasUnsavedChanges(true);
                }}
              />
            )}
          </div>
        )}
      </div>

      <FieldMappingModal
        isOpen={showFieldMappingModal}
        onClose={() => setShowFieldMappingModal(false)}
        onSave={handleSaveFieldMapping}
        sourceField={selectedSourceField}
        targetField={selectedTargetField}
        existingMapping={editingMapping}
      />

      <ListMappingModal
        isOpen={showListMappingModal}
        onClose={() => setShowListMappingModal(false)}
        onSave={handleSaveListMapping}
        sourceArrayFields={sourceArrayFields}
        targetArrayField={targetArrayField}
        existingMapping={editingListMapping}
      />
    </div>
  );
}

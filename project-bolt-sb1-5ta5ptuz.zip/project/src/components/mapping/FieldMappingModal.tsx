import { useState, useEffect } from 'react';
import { X, Sparkles, Save, ArrowRight } from 'lucide-react';
import { FieldMapping } from '../../types/mapping';
import { FieldMetadata } from '../../utils/fieldExtractor';

interface FieldMappingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (mapping: FieldMapping) => void;
  sourceField?: FieldMetadata;
  targetField?: FieldMetadata;
  existingMapping?: FieldMapping;
}

export function FieldMappingModal({
  isOpen,
  onClose,
  onSave,
  sourceField,
  targetField,
  existingMapping
}: FieldMappingModalProps) {
  const [nlpText, setNlpText] = useState('');
  const [isRequired, setIsRequired] = useState(false);
  const [defaultValue, setDefaultValue] = useState('');

  useEffect(() => {
    if (existingMapping) {
      setNlpText(existingMapping.nlp_transformation_text || '');
      setIsRequired(existingMapping.is_required);
      setDefaultValue(existingMapping.default_value || '');
    } else {
      setNlpText('');
      setIsRequired(false);
      setDefaultValue('');
    }
  }, [existingMapping, isOpen]);

  if (!isOpen || !sourceField || !targetField) return null;

  const handleSave = () => {
    const mapping: FieldMapping = {
      mapping_id: existingMapping?.mapping_id || `mapping_${Date.now()}`,
      mapping_type: 'direct',
      source_full_path: sourceField.field_full_path,
      target_full_path: targetField.field_full_path,
      source_type: sourceField.field_type,
      target_type: targetField.field_type,
      nlp_transformation_text: nlpText.trim() || undefined,
      is_required: isRequired,
      default_value: defaultValue || undefined,
      execution_order: existingMapping?.execution_order || 0
    };
    onSave(mapping);
    onClose();
  };

  const typeCompatible = sourceField.field_type === targetField.field_type;

  const getTransformationPlaceholder = () => {
    if (!typeCompatible) {
      if (sourceField.field_type === 'string' && targetField.field_type === 'number') {
        return 'Convert string to number, removing any non-numeric characters';
      } else if (sourceField.field_type === 'string' && targetField.field_type === 'date') {
        return 'Parse string as date in format YYYY-MM-DD and convert to ISO 8601';
      } else if (sourceField.field_type === 'number' && targetField.field_type === 'string') {
        return 'Format number as string with 2 decimal places';
      }
    }
    return 'Describe the transformation in plain English (optional)';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4 flex items-center justify-between">
          <h3 className="text-xl font-bold text-white">Configure Field Mapping</h3>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-6">
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Field Mapping</h4>
            <div className="bg-gray-50 rounded-xl p-4 border-2 border-gray-200">
              <div className="mb-4">
                <div className="text-xs font-semibold text-gray-500 mb-2">SOURCE FIELD</div>
                <div className="bg-white rounded-lg p-3 border border-gray-300">
                  <div className="font-mono text-sm text-gray-800 mb-1">
                    {sourceField.field_full_path}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700 font-semibold">
                      {sourceField.field_type}
                    </span>
                    {sourceField.sample_values && sourceField.sample_values[0] && (
                      <span className="text-xs text-gray-500 italic">
                        Sample: {JSON.stringify(sourceField.sample_values[0])}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center mb-4">
                <ArrowRight className="w-6 h-6 text-gray-400" />
              </div>

              <div>
                <div className="text-xs font-semibold text-gray-500 mb-2">TARGET FIELD</div>
                <div className="bg-white rounded-lg p-3 border border-gray-300">
                  <div className="font-mono text-sm text-blue-700 mb-1">
                    {targetField.field_full_path}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700 font-semibold">
                      {targetField.field_type}
                    </span>
                  </div>
                </div>
              </div>

              {!typeCompatible && (
                <div className="mt-4 p-3 bg-amber-50 border border-amber-300 rounded-lg">
                  <p className="text-sm text-amber-800">
                    <strong>Type mismatch:</strong> Source is <strong>{sourceField.field_type}</strong> but target is <strong>{targetField.field_type}</strong>. A transformation is recommended.
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <h4 className="text-sm font-semibold text-gray-700">Transformation (Optional)</h4>
            </div>
            <textarea
              value={nlpText}
              onChange={(e) => setNlpText(e.target.value)}
              placeholder={getTransformationPlaceholder()}
              rows={4}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-4 focus:ring-purple-100 outline-none resize-none"
            />
            <p className="text-xs text-gray-600 mt-2">
              Describe how to transform the source value in plain English. Examples:
            </p>
            <ul className="text-xs text-gray-600 mt-1 ml-4 space-y-1">
              <li>• Convert date from MM/DD/YYYY to YYYY-MM-DD format</li>
              <li>• Convert amount from cents to dollars with 2 decimal places</li>
              <li>• Concatenate with space if not empty</li>
              <li>• Convert to uppercase and trim whitespace</li>
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isRequired}
                  onChange={(e) => setIsRequired(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
                <span className="text-sm font-medium text-gray-700">Required Field</span>
              </label>
              <p className="text-xs text-gray-500 mt-1 ml-6">
                Mark as required for validation
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Default Value
              </label>
              <input
                type="text"
                value={defaultValue}
                onChange={(e) => setDefaultValue(e.target.value)}
                placeholder="Optional default value"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
              />
            </div>
          </div>
        </div>

        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl hover:scale-105 transition-all"
          >
            <Save className="w-4 h-4" />
            Save Mapping
          </button>
        </div>
      </div>
    </div>
  );
}

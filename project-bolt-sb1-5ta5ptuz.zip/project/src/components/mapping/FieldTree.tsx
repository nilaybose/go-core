import { useState } from 'react';
import { ChevronRight, ChevronDown, List, Box, Type, Hash, Calendar, CheckSquare, File, Copy } from 'lucide-react';
import { FieldMetadata } from '../../utils/fieldExtractor';

interface FieldTreeProps {
  fields: FieldMetadata[];
  title: string;
  onFieldSelect?: (field: FieldMetadata) => void;
  onFieldDragStart?: (field: FieldMetadata) => void;
  selectedPath?: string;
  mappedPaths?: Set<string>;
}

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'array': return <List className="w-4 h-4 text-orange-600" />;
    case 'object': return <Box className="w-4 h-4 text-blue-600" />;
    case 'string': return <Type className="w-4 h-4 text-green-600" />;
    case 'number': return <Hash className="w-4 h-4 text-purple-600" />;
    case 'date': return <Calendar className="w-4 h-4 text-pink-600" />;
    case 'boolean': return <CheckSquare className="w-4 h-4 text-teal-600" />;
    default: return <File className="w-4 h-4 text-gray-600" />;
  }
};

const getTypeBadgeColor = (type: string) => {
  switch (type) {
    case 'array': return 'bg-orange-100 text-orange-700 border-orange-300';
    case 'object': return 'bg-blue-100 text-blue-700 border-blue-300';
    case 'string': return 'bg-green-100 text-green-700 border-green-300';
    case 'number': return 'bg-purple-100 text-purple-700 border-purple-300';
    case 'date': return 'bg-pink-100 text-pink-700 border-pink-300';
    case 'boolean': return 'bg-teal-100 text-teal-700 border-teal-300';
    default: return 'bg-gray-100 text-gray-700 border-gray-300';
  }
};

interface FieldNodeProps {
  field: FieldMetadata;
  level: number;
  onFieldSelect?: (field: FieldMetadata) => void;
  onFieldDragStart?: (field: FieldMetadata) => void;
  selectedPath?: string;
  mappedPaths?: Set<string>;
}

function FieldNode({ field, level, onFieldSelect, onFieldDragStart, selectedPath, mappedPaths }: FieldNodeProps) {
  const [isExpanded, setIsExpanded] = useState(level < 2);
  const hasChildren = field.nested_fields && field.nested_fields.length > 0;
  const isMapped = mappedPaths?.has(field.field_full_path);
  const isSelected = selectedPath === field.field_full_path;
  const isPrimitive = !field.is_array && field.field_type !== 'object';

  const copyToClipboard = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(field.field_full_path);
  };

  const handleDragStart = (e: React.DragEvent) => {
    if (onFieldDragStart && isPrimitive) {
      e.dataTransfer.effectAllowed = 'copy';
      e.dataTransfer.setData('field', JSON.stringify(field));
      onFieldDragStart(field);
    }
  };

  return (
    <div className="select-none">
      <div
        className={`flex items-center gap-2 py-2 px-3 rounded-lg cursor-pointer transition-all hover:bg-blue-50 group ${
          isSelected ? 'bg-blue-100 border-2 border-blue-400' : ''
        } ${isMapped ? 'bg-emerald-50' : ''}`}
        style={{ marginLeft: `${level * 20}px` }}
        onClick={() => {
          if (hasChildren) {
            setIsExpanded(!isExpanded);
          }
          onFieldSelect?.(field);
        }}
        draggable={isPrimitive}
        onDragStart={handleDragStart}
        title={field.field_full_path}
      >
        {hasChildren ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsExpanded(!isExpanded);
            }}
            className="flex-shrink-0"
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4 text-gray-600" />
            ) : (
              <ChevronRight className="w-4 h-4 text-gray-600" />
            )}
          </button>
        ) : (
          <div className="w-4" />
        )}

        <div className="flex-shrink-0">
          {getTypeIcon(field.field_type)}
        </div>

        <span className="font-medium text-gray-800 flex-shrink-0">
          {field.field_name}
        </span>

        <span
          className={`text-xs px-2 py-0.5 rounded-full border font-semibold flex-shrink-0 ${getTypeBadgeColor(
            field.field_type
          )}`}
        >
          {field.field_type}
        </span>

        {isMapped && (
          <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 border border-emerald-300 font-semibold flex-shrink-0">
            Mapped
          </span>
        )}

        <span className="text-xs text-gray-500 truncate flex-1 min-w-0">
          {field.field_full_path}
        </span>

        <button
          onClick={copyToClipboard}
          className="opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 p-1 hover:bg-blue-200 rounded"
          title="Copy path"
        >
          <Copy className="w-3 h-3 text-blue-600" />
        </button>

        {field.sample_values && field.sample_values.length > 0 && field.field_type !== 'object' && (
          <span className="text-xs text-gray-400 italic truncate max-w-xs flex-shrink-0">
            {JSON.stringify(field.sample_values[0])}
          </span>
        )}
      </div>

      {hasChildren && isExpanded && (
        <div>
          {field.nested_fields!.map((childField) => (
            <FieldNode
              key={childField.field_full_path}
              field={childField}
              level={level + 1}
              onFieldSelect={onFieldSelect}
              onFieldDragStart={onFieldDragStart}
              selectedPath={selectedPath}
              mappedPaths={mappedPaths}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function FieldTree({ fields, title, onFieldSelect, onFieldDragStart, selectedPath, mappedPaths }: FieldTreeProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filterFields = (fields: FieldMetadata[], query: string): FieldMetadata[] => {
    if (!query) return fields;
    const lowerQuery = query.toLowerCase();
    return fields.filter(field =>
      field.field_full_path.toLowerCase().includes(lowerQuery) ||
      field.field_name.toLowerCase().includes(lowerQuery)
    );
  };

  const filteredFields = filterFields(fields, searchQuery);
  const rootFields = filteredFields.filter(f => f.parent_full_path === 'root' || f.parent_full_path === '');

  return (
    <div className="flex flex-col h-full bg-white rounded-xl border-2 border-gray-200 shadow-lg">
      <div className="px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-t-xl">
        <h3 className="font-bold text-white text-lg">{title}</h3>
        <p className="text-xs text-blue-100 mt-1">
          {filteredFields.length} field{filteredFields.length !== 1 ? 's' : ''}
        </p>
      </div>

      <div className="px-4 py-3 border-b border-gray-200">
        <input
          type="text"
          placeholder="Search fields..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
        />
      </div>

      <div className="flex-1 overflow-auto p-4">
        {rootFields.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            <p className="text-sm">No fields found</p>
          </div>
        ) : (
          rootFields.map((field) => (
            <FieldNode
              key={field.field_full_path}
              field={field}
              level={0}
              onFieldSelect={onFieldSelect}
              onFieldDragStart={onFieldDragStart}
              selectedPath={selectedPath}
              mappedPaths={mappedPaths}
            />
          ))
        )}
      </div>
    </div>
  );
}

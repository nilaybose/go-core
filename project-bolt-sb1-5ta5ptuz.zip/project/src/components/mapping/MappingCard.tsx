import { ArrowRight, Edit2, Trash2, Sparkles, List as ListIcon } from 'lucide-react';
import { FieldMapping, ListMapping } from '../../types/mapping';

interface MappingCardProps {
  mapping: FieldMapping | ListMapping;
  onEdit: () => void;
  onDelete: () => void;
  type: 'field' | 'list';
}

export function MappingCard({ mapping, onEdit, onDelete, type }: MappingCardProps) {
  const isListMapping = type === 'list';
  const hasTransformation = isListMapping
    ? (mapping as ListMapping).array_transformation_nlp
    : (mapping as FieldMapping).nlp_transformation_text;

  return (
    <div className="bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-blue-400 hover:shadow-lg transition-all group">
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 mt-1">
          {isListMapping ? (
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <ListIcon className="w-5 h-5 text-orange-600" />
            </div>
          ) : (
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <ArrowRight className="w-5 h-5 text-blue-600" />
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start gap-2 mb-2">
            <div className="flex-1 min-w-0">
              {isListMapping ? (
                <div>
                  <div className="text-xs font-semibold text-gray-500 mb-1">SOURCE LISTS</div>
                  {(mapping as ListMapping).source_list_paths.map((path, idx) => (
                    <div key={idx} className="text-sm font-mono text-gray-700 bg-gray-50 px-2 py-1 rounded mb-1 truncate">
                      {path}
                    </div>
                  ))}
                  <div className="flex items-center justify-center my-2">
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                  </div>
                  <div className="text-xs font-semibold text-gray-500 mb-1">TARGET LIST</div>
                  <div className="text-sm font-mono text-blue-700 bg-blue-50 px-2 py-1 rounded truncate">
                    {(mapping as ListMapping).target_list_path}
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    Strategy: <span className="font-semibold">{(mapping as ListMapping).merge_strategy}</span>
                    {(mapping as ListMapping).sub_field_mappings.length > 0 && (
                      <span className="ml-2">
                        • {(mapping as ListMapping).sub_field_mappings.length} sub-field mappings
                      </span>
                    )}
                  </div>
                </div>
              ) : (
                <div>
                  <div className="text-xs font-semibold text-gray-500 mb-1">SOURCE</div>
                  <div className="text-sm font-mono text-gray-700 bg-gray-50 px-2 py-1 rounded mb-2 truncate">
                    {(mapping as FieldMapping).source_full_path}
                  </div>
                  <div className="flex items-center justify-center my-2">
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                  </div>
                  <div className="text-xs font-semibold text-gray-500 mb-1">TARGET</div>
                  <div className="text-sm font-mono text-blue-700 bg-blue-50 px-2 py-1 rounded truncate">
                    {(mapping as FieldMapping).target_full_path}
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={onEdit}
                className="p-2 hover:bg-blue-100 rounded-lg transition-colors"
                title="Edit mapping"
              >
                <Edit2 className="w-4 h-4 text-blue-600" />
              </button>
              <button
                onClick={onDelete}
                className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                title="Delete mapping"
              >
                <Trash2 className="w-4 h-4 text-red-600" />
              </button>
            </div>
          </div>

          {hasTransformation && (
            <div className="mt-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-semibold text-purple-700">TRANSFORMATION</span>
              </div>
              <p className="text-sm text-gray-700 line-clamp-2">
                {hasTransformation}
              </p>
            </div>
          )}

          {!isListMapping && (mapping as FieldMapping).confidence && (
            <div className="mt-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-600">Confidence:</span>
                <div className="flex-1 bg-gray-200 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-emerald-500 to-green-500 h-full rounded-full transition-all"
                    style={{ width: `${(mapping as FieldMapping).confidence! * 100}%` }}
                  />
                </div>
                <span className="text-xs font-semibold text-gray-700">
                  {Math.round((mapping as FieldMapping).confidence! * 100)}%
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { X, Plus, Trash2, Sparkles, Save, ArrowRight } from 'lucide-react';
import { ListMapping, SubFieldMapping } from '../../types/mapping';
import { FieldMetadata } from '../../utils/fieldExtractor';

interface ListMappingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (mapping: ListMapping) => void;
  sourceArrayFields: FieldMetadata[];
  targetArrayField?: FieldMetadata;
  existingMapping?: ListMapping;
}

export function ListMappingModal({
  isOpen,
  onClose,
  onSave,
  sourceArrayFields,
  targetArrayField,
  existingMapping
}: ListMappingModalProps) {
  const [selectedSourceLists, setSelectedSourceLists] = useState<string[]>([]);
  const [mergeStrategy, setMergeStrategy] = useState<'replace' | 'append' | 'merge_by_key'>('replace');
  const [mergeKeySource, setMergeKeySource] = useState('');
  const [mergeKeyTarget, setMergeKeyTarget] = useState('');
  const [subFieldMappings, setSubFieldMappings] = useState<SubFieldMapping[]>([]);
  const [arrayTransformationNlp, setArrayTransformationNlp] = useState('');
  const [filterConditionNlp, setFilterConditionNlp] = useState('');

  useEffect(() => {
    if (existingMapping) {
      setSelectedSourceLists(existingMapping.source_list_paths);
      setMergeStrategy(existingMapping.merge_strategy);
      setMergeKeySource(existingMapping.merge_key_source || '');
      setMergeKeyTarget(existingMapping.merge_key_target || '');
      setSubFieldMappings(existingMapping.sub_field_mappings);
      setArrayTransformationNlp(existingMapping.array_transformation_nlp || '');
      setFilterConditionNlp(existingMapping.filter_condition_nlp || '');
    } else {
      setSelectedSourceLists([]);
      setMergeStrategy('replace');
      setMergeKeySource('');
      setMergeKeyTarget('');
      setSubFieldMappings([]);
      setArrayTransformationNlp('');
      setFilterConditionNlp('');
    }
  }, [existingMapping, isOpen]);

  if (!isOpen || !targetArrayField) return null;

  const handleAddSourceList = (path: string) => {
    if (!selectedSourceLists.includes(path)) {
      setSelectedSourceLists([...selectedSourceLists, path]);
    }
  };

  const handleRemoveSourceList = (path: string) => {
    setSelectedSourceLists(selectedSourceLists.filter(p => p !== path));
  };

  const handleAddSubFieldMapping = () => {
    const newMapping: SubFieldMapping = {
      mapping_id: `sub_mapping_${Date.now()}`,
      source_full_path: '',
      target_full_path: '',
      source_type: '',
      target_type: ''
    };
    setSubFieldMappings([...subFieldMappings, newMapping]);
  };

  const handleUpdateSubFieldMapping = (index: number, field: keyof SubFieldMapping, value: string) => {
    const updated = [...subFieldMappings];
    updated[index] = { ...updated[index], [field]: value };
    setSubFieldMappings(updated);
  };

  const handleRemoveSubFieldMapping = (index: number) => {
    setSubFieldMappings(subFieldMappings.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    const mapping: ListMapping = {
      mapping_id: existingMapping?.mapping_id || `list_mapping_${Date.now()}`,
      source_list_paths: selectedSourceLists,
      target_list_path: targetArrayField.field_full_path,
      merge_strategy: mergeStrategy,
      merge_key_source: mergeKeySource || undefined,
      merge_key_target: mergeKeyTarget || undefined,
      sub_field_mappings: subFieldMappings.filter(m => m.source_full_path && m.target_full_path),
      array_transformation_nlp: arrayTransformationNlp.trim() || undefined,
      filter_condition_nlp: filterConditionNlp.trim() || undefined
    };
    onSave(mapping);
    onClose();
  };

  const availableSourceLists = sourceArrayFields.filter(f => !selectedSourceLists.includes(f.field_full_path));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="bg-gradient-to-r from-orange-600 to-red-600 px-6 py-4 flex items-center justify-between">
          <h3 className="text-xl font-bold text-white">Configure List-to-List Mapping</h3>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-6">
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Source Lists</h4>
            <div className="space-y-2 mb-3">
              {selectedSourceLists.map((path, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-gray-50 rounded-lg p-3 border border-gray-300">
                  <span className="flex-1 font-mono text-sm text-gray-700">{path}</span>
                  <button
                    onClick={() => handleRemoveSourceList(path)}
                    className="p-1 hover:bg-red-100 rounded transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              ))}
            </div>
            {availableSourceLists.length > 0 && (
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-2">Add Source List</label>
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      handleAddSourceList(e.target.value);
                      e.target.value = '';
                    }
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-100 outline-none text-sm"
                >
                  <option value="">Select a source list...</option>
                  {availableSourceLists.map((field) => (
                    <option key={field.field_full_path} value={field.field_full_path}>
                      {field.field_full_path}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="flex items-center justify-center mb-6">
            <ArrowRight className="w-8 h-8 text-gray-400" />
          </div>

          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Target List</h4>
            <div className="bg-blue-50 rounded-lg p-3 border-2 border-blue-300">
              <span className="font-mono text-sm text-blue-700">{targetArrayField.field_full_path}</span>
            </div>
          </div>

          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Merge Strategy</h4>
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => setMergeStrategy('replace')}
                className={`p-3 rounded-lg border-2 transition-all ${
                  mergeStrategy === 'replace'
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="font-semibold text-sm">Replace</div>
                <div className="text-xs text-gray-600 mt-1">Clear and replace all items</div>
              </button>
              <button
                onClick={() => setMergeStrategy('append')}
                className={`p-3 rounded-lg border-2 transition-all ${
                  mergeStrategy === 'append'
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="font-semibold text-sm">Append</div>
                <div className="text-xs text-gray-600 mt-1">Add to end of list</div>
              </button>
              <button
                onClick={() => setMergeStrategy('merge_by_key')}
                className={`p-3 rounded-lg border-2 transition-all ${
                  mergeStrategy === 'merge_by_key'
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="font-semibold text-sm">Merge by Key</div>
                <div className="text-xs text-gray-600 mt-1">Match by field</div>
              </button>
            </div>

            {mergeStrategy === 'merge_by_key' && (
              <div className="mt-4 grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-2">Source Merge Key</label>
                  <input
                    type="text"
                    value={mergeKeySource}
                    onChange={(e) => setMergeKeySource(e.target.value)}
                    placeholder="e.g., items[].id"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-100 outline-none text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-2">Target Merge Key</label>
                  <input
                    type="text"
                    value={mergeKeyTarget}
                    onChange={(e) => setMergeKeyTarget(e.target.value)}
                    placeholder="e.g., items[].item_id"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-100 outline-none text-sm"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-semibold text-gray-700">Sub-Field Mappings</h4>
              <button
                onClick={handleAddSubFieldMapping}
                className="flex items-center gap-1 px-3 py-1 text-sm bg-orange-100 text-orange-700 rounded-lg hover:bg-orange-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Mapping
              </button>
            </div>
            <div className="space-y-3">
              {subFieldMappings.map((mapping, idx) => (
                <div key={idx} className="bg-gray-50 rounded-lg p-3 border border-gray-300">
                  <div className="grid grid-cols-2 gap-3 mb-2">
                    <input
                      type="text"
                      value={mapping.source_full_path}
                      onChange={(e) => handleUpdateSubFieldMapping(idx, 'source_full_path', e.target.value)}
                      placeholder="Source field path (e.g., items[].name)"
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-100 outline-none text-sm font-mono"
                    />
                    <input
                      type="text"
                      value={mapping.target_full_path}
                      onChange={(e) => handleUpdateSubFieldMapping(idx, 'target_full_path', e.target.value)}
                      placeholder="Target field path (e.g., items[].description)"
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-100 outline-none text-sm font-mono"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={mapping.nlp_transformation_text || ''}
                      onChange={(e) => handleUpdateSubFieldMapping(idx, 'nlp_transformation_text', e.target.value)}
                      placeholder="Transformation (optional)"
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:border-purple-500 focus:ring-2 focus:ring-purple-100 outline-none text-sm"
                    />
                    <button
                      onClick={() => handleRemoveSubFieldMapping(idx)}
                      className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <h4 className="text-sm font-semibold text-gray-700">Array Transformation (Optional)</h4>
            </div>
            <textarea
              value={arrayTransformationNlp}
              onChange={(e) => setArrayTransformationNlp(e.target.value)}
              placeholder="Describe array-level operations (e.g., 'Sort by date descending', 'Group by category')"
              rows={3}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-4 focus:ring-purple-100 outline-none resize-none"
            />
          </div>

          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Filter Condition (Optional)</h4>
            <input
              type="text"
              value={filterConditionNlp}
              onChange={(e) => setFilterConditionNlp(e.target.value)}
              placeholder="Filter items (e.g., 'Only include items where status equals active')"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-100 outline-none"
            />
          </div>
        </div>

        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={selectedSourceLists.length === 0}
            className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-orange-600 to-red-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <Save className="w-4 h-4" />
            Save List Mapping
          </button>
        </div>
      </div>
    </div>
  );
}

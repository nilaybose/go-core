import { useState } from 'react';
import { Sparkles, Plus, Trash2, ChevronDown, ChevronRight } from 'lucide-react';
import { GlobalTransformations } from '../../types/mapping';

interface GlobalTransformationsPanelProps {
  transformations: GlobalTransformations;
  onChange: (transformations: GlobalTransformations) => void;
}

export function GlobalTransformationsPanel({ transformations, onChange }: GlobalTransformationsPanelProps) {
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['pre']));

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(section)) {
      newExpanded.delete(section);
    } else {
      newExpanded.add(section);
    }
    setExpandedSections(newExpanded);
  };

  const addPreProcessing = () => {
    const newTransformation = {
      transformation_id: `pre_${Date.now()}`,
      nlp_text: '',
      execution_order: transformations.pre_processing_transformations.length
    };
    onChange({
      ...transformations,
      pre_processing_transformations: [
        ...transformations.pre_processing_transformations,
        newTransformation
      ]
    });
  };

  const updatePreProcessing = (index: number, nlpText: string) => {
    const updated = [...transformations.pre_processing_transformations];
    updated[index] = { ...updated[index], nlp_text: nlpText };
    onChange({
      ...transformations,
      pre_processing_transformations: updated
    });
  };

  const removePreProcessing = (index: number) => {
    onChange({
      ...transformations,
      pre_processing_transformations: transformations.pre_processing_transformations.filter((_, i) => i !== index)
    });
  };

  const addPostProcessing = () => {
    const newTransformation = {
      transformation_id: `post_${Date.now()}`,
      nlp_text: '',
      execution_order: transformations.post_processing_transformations.length
    };
    onChange({
      ...transformations,
      post_processing_transformations: [
        ...transformations.post_processing_transformations,
        newTransformation
      ]
    });
  };

  const updatePostProcessing = (index: number, nlpText: string) => {
    const updated = [...transformations.post_processing_transformations];
    updated[index] = { ...updated[index], nlp_text: nlpText };
    onChange({
      ...transformations,
      post_processing_transformations: updated
    });
  };

  const removePostProcessing = (index: number) => {
    onChange({
      ...transformations,
      post_processing_transformations: transformations.post_processing_transformations.filter((_, i) => i !== index)
    });
  };

  const updateDocumentLevelNlp = (nlpText: string) => {
    onChange({
      ...transformations,
      document_level_nlp: nlpText
    });
  };

  const addValidationRule = () => {
    const newRule = {
      rule_id: `rule_${Date.now()}`,
      target_path: '',
      validation_type: 'format',
      nlp_text: ''
    };
    onChange({
      ...transformations,
      validation_rules: [...transformations.validation_rules, newRule]
    });
  };

  const updateValidationRule = (index: number, field: string, value: string) => {
    const updated = [...transformations.validation_rules];
    updated[index] = { ...updated[index], [field]: value };
    onChange({
      ...transformations,
      validation_rules: updated
    });
  };

  const removeValidationRule = (index: number) => {
    onChange({
      ...transformations,
      validation_rules: transformations.validation_rules.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="bg-white rounded-xl border-2 border-gray-200 shadow-lg">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-4 rounded-t-xl">
        <div className="flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-white" />
          <h3 className="text-xl font-bold text-white">Global Transformations</h3>
        </div>
        <p className="text-purple-100 text-sm mt-1">
          Document-level transformations applied to entire JSON
        </p>
      </div>

      <div className="p-6 space-y-4">
        <div className="border-2 border-gray-200 rounded-xl overflow-hidden">
          <button
            onClick={() => toggleSection('pre')}
            className="w-full flex items-center justify-between px-4 py-3 bg-blue-50 hover:bg-blue-100 transition-colors"
          >
            <div className="flex items-center gap-2">
              {expandedSections.has('pre') ? (
                <ChevronDown className="w-5 h-5 text-blue-600" />
              ) : (
                <ChevronRight className="w-5 h-5 text-blue-600" />
              )}
              <span className="font-semibold text-blue-900">Pre-Processing</span>
              <span className="text-xs bg-blue-200 text-blue-700 px-2 py-1 rounded-full">
                {transformations.pre_processing_transformations.length} rules
              </span>
            </div>
          </button>

          {expandedSections.has('pre') && (
            <div className="p-4 space-y-3 bg-white">
              <p className="text-sm text-gray-600 mb-3">
                Transformations applied to source JSON before field mapping
              </p>
              {transformations.pre_processing_transformations.map((t, idx) => (
                <div key={t.transformation_id} className="flex gap-2">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-sm font-bold text-blue-700">
                    {idx + 1}
                  </div>
                  <textarea
                    value={t.nlp_text}
                    onChange={(e) => updatePreProcessing(idx, e.target.value)}
                    placeholder="e.g., Remove all null values from source JSON"
                    rows={2}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none resize-none text-sm"
                  />
                  <button
                    onClick={() => removePreProcessing(idx)}
                    className="flex-shrink-0 p-2 hover:bg-red-100 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              ))}
              <button
                onClick={addPreProcessing}
                className="flex items-center gap-2 px-4 py-2 text-sm bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Pre-Processing Rule
              </button>
            </div>
          )}
        </div>

        <div className="border-2 border-gray-200 rounded-xl overflow-hidden">
          <button
            onClick={() => toggleSection('post')}
            className="w-full flex items-center justify-between px-4 py-3 bg-green-50 hover:bg-green-100 transition-colors"
          >
            <div className="flex items-center gap-2">
              {expandedSections.has('post') ? (
                <ChevronDown className="w-5 h-5 text-green-600" />
              ) : (
                <ChevronRight className="w-5 h-5 text-green-600" />
              )}
              <span className="font-semibold text-green-900">Post-Processing</span>
              <span className="text-xs bg-green-200 text-green-700 px-2 py-1 rounded-full">
                {transformations.post_processing_transformations.length} rules
              </span>
            </div>
          </button>

          {expandedSections.has('post') && (
            <div className="p-4 space-y-3 bg-white">
              <p className="text-sm text-gray-600 mb-3">
                Transformations applied to destination JSON after field mapping
              </p>
              {transformations.post_processing_transformations.map((t, idx) => (
                <div key={t.transformation_id} className="flex gap-2">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center text-sm font-bold text-green-700">
                    {idx + 1}
                  </div>
                  <textarea
                    value={t.nlp_text}
                    onChange={(e) => updatePostProcessing(idx, e.target.value)}
                    placeholder="e.g., Calculate total_amount from sum of items[].amount"
                    rows={2}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-100 outline-none resize-none text-sm"
                  />
                  <button
                    onClick={() => removePostProcessing(idx)}
                    className="flex-shrink-0 p-2 hover:bg-red-100 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              ))}
              <button
                onClick={addPostProcessing}
                className="flex items-center gap-2 px-4 py-2 text-sm bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Post-Processing Rule
              </button>
            </div>
          )}
        </div>

        <div className="border-2 border-purple-200 rounded-xl p-4 bg-purple-50">
          <label className="block text-sm font-semibold text-purple-900 mb-3">
            Document-Level Transformation
          </label>
          <textarea
            value={transformations.document_level_nlp || ''}
            onChange={(e) => updateDocumentLevelNlp(e.target.value)}
            placeholder="Overall transformation description (e.g., 'Convert all dates to ISO 8601 format throughout the document')"
            rows={3}
            className="w-full px-4 py-3 border-2 border-purple-300 rounded-lg focus:border-purple-500 focus:ring-4 focus:ring-purple-100 outline-none resize-none"
          />
        </div>

        <div className="border-2 border-gray-200 rounded-xl overflow-hidden">
          <button
            onClick={() => toggleSection('validation')}
            className="w-full flex items-center justify-between px-4 py-3 bg-amber-50 hover:bg-amber-100 transition-colors"
          >
            <div className="flex items-center gap-2">
              {expandedSections.has('validation') ? (
                <ChevronDown className="w-5 h-5 text-amber-600" />
              ) : (
                <ChevronRight className="w-5 h-5 text-amber-600" />
              )}
              <span className="font-semibold text-amber-900">Validation Rules</span>
              <span className="text-xs bg-amber-200 text-amber-700 px-2 py-1 rounded-full">
                {transformations.validation_rules.length} rules
              </span>
            </div>
          </button>

          {expandedSections.has('validation') && (
            <div className="p-4 space-y-3 bg-white">
              <p className="text-sm text-gray-600 mb-3">
                Validation rules for output data
              </p>
              {transformations.validation_rules.map((rule, idx) => (
                <div key={rule.rule_id} className="bg-gray-50 rounded-lg p-3 border border-gray-300 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={rule.target_path}
                      onChange={(e) => updateValidationRule(idx, 'target_path', e.target.value)}
                      placeholder="Target path (e.g., invoice.total)"
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none text-sm font-mono"
                    />
                    <select
                      value={rule.validation_type}
                      onChange={(e) => updateValidationRule(idx, 'validation_type', e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none text-sm"
                    >
                      <option value="format">Format</option>
                      <option value="range">Range</option>
                      <option value="required">Required</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={rule.nlp_text}
                      onChange={(e) => updateValidationRule(idx, 'nlp_text', e.target.value)}
                      placeholder="Validation rule (e.g., 'Must be a valid email address')"
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none text-sm"
                    />
                    <button
                      onClick={() => removeValidationRule(idx)}
                      className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
              <button
                onClick={addValidationRule}
                className="flex items-center gap-2 px-4 py-2 text-sm bg-amber-100 text-amber-700 rounded-lg hover:bg-amber-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Validation Rule
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

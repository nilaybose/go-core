import { useState } from 'react';
import { Search, Plus, Trash2, Loader2, FileText, X, Eye, Edit2, Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { api, ReconSpec, CreateReconSpecRequest } from '../api';

interface FieldInput {
  name: string;
  type: string;
  length: string;
}

export function ReconSpecsTab() {
  const [specs, setSpecs] = useState<ReconSpec[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [deletingUuid, setDeletingUuid] = useState<string | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [viewModalSpec, setViewModalSpec] = useState<ReconSpec | null>(null);
  const [editModalSpec, setEditModalSpec] = useState<ReconSpec | null>(null);

  const [specName, setSpecName] = useState('');
  const [headerFields, setHeaderFields] = useState<FieldInput[]>([]);
  const [recordFields, setRecordFields] = useState<FieldInput[]>([]);
  const [footerFields, setFooterFields] = useState<FieldInput[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [uploadStatus, setUploadStatus] = useState<{
    type: 'success' | 'error' | null;
    message: string;
  }>({ type: null, message: '' });

  const fetchSpecs = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.listReconSpecs(searchQuery);
      setSpecs(response.specs);
    } catch (err) {
      setError('Failed to load recon specs');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setHasSearched(true);
    fetchSpecs();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleDelete = async (specUuid: string, name: string) => {
    if (!confirm(`Are you sure you want to delete "${name}"?`)) {
      return;
    }

    try {
      setDeletingUuid(specUuid);
      await api.deleteReconSpec(specUuid);
      setSpecs(specs.filter(s => s.spec_uuid !== specUuid));
    } catch (err) {
      setError('Failed to delete recon spec');
      console.error(err);
    } finally {
      setDeletingUuid(null);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      setUploadStatus({ type: 'error', message: 'Please upload a JSON file' });
      return;
    }

    try {
      const text = await file.text();
      const json = JSON.parse(text);

      if (!json.header || !json.records || !json.footer) {
        setUploadStatus({ type: 'error', message: 'JSON must contain header, records, and footer arrays' });
        return;
      }

      const parseFields = (fields: any[]): FieldInput[] => {
        return fields.map(f => ({
          name: f.name || '',
          type: f.type || 'string',
          length: String(f.length || 0)
        }));
      };

      setHeaderFields(parseFields(json.header));
      setRecordFields(parseFields(json.records));
      setFooterFields(parseFields(json.footer));
      setSpecName(file.name.replace('.json', ''));
      setUploadedFileName(file.name);
      setUploadStatus({ type: 'success', message: 'JSON file parsed successfully' });
    } catch (err) {
      setUploadStatus({ type: 'error', message: 'Invalid JSON file' });
      console.error(err);
    }
  };


  const handleCreate = async () => {
    if (!specName.trim()) {
      setUploadStatus({ type: 'error', message: 'Spec name is required' });
      return;
    }

    if (headerFields.length === 0 && recordFields.length === 0 && footerFields.length === 0) {
      setUploadStatus({ type: 'error', message: 'Please upload a JSON file first' });
      return;
    }

    setUploading(true);
    setUploadStatus({ type: null, message: '' });

    try {
      const data: CreateReconSpecRequest = {
        name: specName,
        header_fields: headerFields.map(f => ({ name: f.name, type: f.type, length: Number(f.length) })),
        record_fields: recordFields.map(f => ({ name: f.name, type: f.type, length: Number(f.length) })),
        footer_fields: footerFields.map(f => ({ name: f.name, type: f.type, length: Number(f.length) })),
      };

      await api.createReconSpec(data);

      setUploadStatus({ type: 'success', message: 'Recon spec created successfully' });
      resetForm();

      setTimeout(() => {
        setShowUploadModal(false);
        setUploadStatus({ type: null, message: '' });
        if (hasSearched) {
          fetchSpecs();
        }
      }, 1500);
    } catch (error) {
      setUploadStatus({
        type: 'error',
        message: error instanceof Error ? error.message : 'Failed to create recon spec',
      });
    } finally {
      setUploading(false);
    }
  };

  const handleUpdate = async () => {
    if (!editModalSpec) return;

    if (!specName.trim()) {
      setUploadStatus({ type: 'error', message: 'Spec name is required' });
      return;
    }

    if (headerFields.length === 0 && recordFields.length === 0 && footerFields.length === 0) {
      setUploadStatus({ type: 'error', message: 'Please upload a JSON file first' });
      return;
    }

    setUploading(true);
    setUploadStatus({ type: null, message: '' });

    try {
      const data: CreateReconSpecRequest = {
        name: specName,
        header_fields: headerFields.map(f => ({ name: f.name, type: f.type, length: Number(f.length) })),
        record_fields: recordFields.map(f => ({ name: f.name, type: f.type, length: Number(f.length) })),
        footer_fields: footerFields.map(f => ({ name: f.name, type: f.type, length: Number(f.length) })),
      };

      await api.updateReconSpec(editModalSpec.spec_uuid, data);

      setUploadStatus({ type: 'success', message: 'Recon spec updated successfully' });

      setTimeout(() => {
        setEditModalSpec(null);
        resetForm();
        setUploadStatus({ type: null, message: '' });
        fetchSpecs();
      }, 1500);
    } catch (error) {
      setUploadStatus({
        type: 'error',
        message: error instanceof Error ? error.message : 'Failed to update recon spec',
      });
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setSpecName('');
    setHeaderFields([]);
    setRecordFields([]);
    setFooterFields([]);
    setUploadedFileName('');
    const fileInput = document.getElementById('recon-file-input') as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  };

  const openViewModal = (spec: ReconSpec) => {
    setViewModalSpec(spec);
  };

  const openEditModal = (spec: ReconSpec) => {
    setSpecName(spec.name);
    setHeaderFields([]);
    setRecordFields([]);
    setFooterFields([]);
    setUploadedFileName('');
    setEditModalSpec(spec);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const renderFieldsTable = (fields: Array<{ name: string; type: string; length: number }>, title: string) => (
    <div className="mb-6">
      <h4 className="text-sm font-semibold text-gray-700 mb-3">{title}</h4>
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Field Name</th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Type</th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Length</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {fields.map((field, idx) => (
              <tr key={idx} className="hover:bg-gray-50">
                <td className="px-4 py-2 text-sm text-gray-900">{field.name}</td>
                <td className="px-4 py-2 text-sm text-gray-600">{field.type}</td>
                <td className="px-4 py-2 text-sm text-gray-600">{field.length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );


  return (
    <div className="h-full flex flex-col p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Recon Specs</h2>
          <p className="text-gray-600">Manage normalized spec and JSON structure definitions</p>
        </div>
        <button
          onClick={() => setShowUploadModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all"
        >
          <Plus className="w-5 h-5" />
          Create Spec
        </button>
      </div>

      <div className="mb-6 flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <button
          onClick={handleSearch}
          className="px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all"
        >
          Search
        </button>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <div className="flex-1 overflow-auto bg-white rounded-lg border border-gray-200">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
          </div>
        ) : !hasSearched ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <Search className="w-16 h-16 mb-4 text-gray-300" />
            <p className="text-lg">Search to view recon specs</p>
            <p className="text-sm mt-2">Use the search above to find specs</p>
          </div>
        ) : specs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <FileText className="w-16 h-16 mb-4 text-gray-300" />
            <p className="text-lg">No recon specs found</p>
            <p className="text-sm mt-2">Create your first recon spec to get started</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {specs.map((spec) => (
              <div key={spec.spec_uuid} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex justify-between items-start gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {spec.name}
                    </h3>
                    <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                      <span>Header: {spec.header_fields.length} fields</span>
                      <span>Records: {spec.record_fields.length} fields</span>
                      <span>Footer: {spec.footer_fields.length} fields</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-400">
                      <span>Created: {formatDate(spec.created_at)}</span>
                      <span>UUID: {spec.spec_uuid.substring(0, 8)}...</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => openViewModal(spec)}
                      className="text-gray-600 hover:text-gray-800 transition-colors"
                      title="View spec"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => openEditModal(spec)}
                      className="text-blue-600 hover:text-blue-800 transition-colors"
                      title="Edit spec"
                    >
                      <Edit2 className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(spec.spec_uuid, spec.name)}
                      disabled={deletingUuid === spec.spec_uuid}
                      className="text-red-600 hover:text-red-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      title="Delete spec"
                    >
                      {deletingUuid === spec.spec_uuid ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <Trash2 className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {hasSearched && (
        <div className="mt-4 text-sm text-gray-500">
          Showing {specs.length} spec{specs.length !== 1 ? 's' : ''}
        </div>
      )}

      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-800">Create Recon Spec</h3>
              <button
                onClick={() => {
                  setShowUploadModal(false);
                  resetForm();
                  setUploadStatus({ type: null, message: '' });
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="bg-blue-50 rounded-lg border-2 border-dashed border-blue-300 p-8">
                <div className="flex flex-col items-center justify-center space-y-4">
                  <Upload className="w-16 h-16 text-blue-600" />
                  <div className="text-center">
                    <label
                      htmlFor="recon-file-input"
                      className="cursor-pointer text-blue-600 hover:text-blue-700 font-medium text-lg"
                    >
                      Upload JSON file
                    </label>
                    <p className="text-sm text-gray-500 mt-1">
                      File must contain header, records, and footer arrays
                    </p>
                  </div>
                  <input
                    id="recon-file-input"
                    type="file"
                    accept=".json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  {uploadedFileName && (
                    <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-blue-200">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <span className="text-sm text-gray-700">{uploadedFileName}</span>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Spec Name
                </label>
                <input
                  type="text"
                  value={specName}
                  onChange={(e) => setSpecName(e.target.value)}
                  placeholder="Enter spec name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              {headerFields.length > 0 && renderFieldsTable(headerFields.map(f => ({ ...f, length: Number(f.length) })), 'Header Fields')}
              {recordFields.length > 0 && renderFieldsTable(recordFields.map(f => ({ ...f, length: Number(f.length) })), 'Record Fields')}
              {footerFields.length > 0 && renderFieldsTable(footerFields.map(f => ({ ...f, length: Number(f.length) })), 'Footer Fields')}

              {uploadStatus.type && (
                <div
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg ${
                    uploadStatus.type === 'success'
                      ? 'bg-green-50 text-green-800 border border-green-200'
                      : 'bg-red-50 text-red-800 border border-red-200'
                  }`}
                >
                  {uploadStatus.type === 'success' ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <AlertCircle className="w-5 h-5" />
                  )}
                  <p className="text-sm">{uploadStatus.message}</p>
                </div>
              )}

              <button
                onClick={handleCreate}
                disabled={uploading}
                className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Plus className="w-5 h-5" />
                    Create Recon Spec
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {viewModalSpec && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold text-gray-900">{viewModalSpec.name}</h3>
                <div className="flex items-center gap-4 text-xs text-gray-400 mt-2">
                  <span>Created: {formatDate(viewModalSpec.created_at)}</span>
                  <span>UUID: {viewModalSpec.spec_uuid}</span>
                </div>
              </div>
              <button
                onClick={() => setViewModalSpec(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6">
              {renderFieldsTable(viewModalSpec.header_fields, 'Header Fields')}
              {renderFieldsTable(viewModalSpec.record_fields, 'Record Fields')}
              {renderFieldsTable(viewModalSpec.footer_fields, 'Footer Fields')}

              <div className="flex justify-end gap-3 mt-6">
                <button
                  onClick={() => {
                    setViewModalSpec(null);
                    openEditModal(viewModalSpec);
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:shadow-lg transition-all"
                >
                  <Edit2 className="w-5 h-5" />
                  Edit
                </button>
                <button
                  onClick={() => setViewModalSpec(null)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {editModalSpec && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-800">Edit Recon Spec</h3>
              <button
                onClick={() => {
                  setEditModalSpec(null);
                  resetForm();
                  setUploadStatus({ type: null, message: '' });
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Spec Name
                </label>
                <input
                  type="text"
                  value={specName}
                  onChange={(e) => setSpecName(e.target.value)}
                  placeholder="Enter spec name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="bg-blue-50 rounded-lg border-2 border-dashed border-blue-300 p-8">
                <div className="flex flex-col items-center justify-center space-y-4">
                  <Upload className="w-16 h-16 text-blue-600" />
                  <div className="text-center">
                    <label
                      htmlFor="recon-edit-file-input"
                      className="cursor-pointer text-blue-600 hover:text-blue-700 font-medium text-lg"
                    >
                      Upload new JSON file
                    </label>
                    <p className="text-sm text-gray-500 mt-1">
                      Replace with a new spec definition
                    </p>
                  </div>
                  <input
                    id="recon-edit-file-input"
                    type="file"
                    accept=".json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  {uploadedFileName && (
                    <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-blue-200">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <span className="text-sm text-gray-700">{uploadedFileName}</span>
                    </div>
                  )}
                </div>
              </div>

              {headerFields.length > 0 && renderFieldsTable(headerFields.map(f => ({ ...f, length: Number(f.length) })), 'Header Fields')}
              {recordFields.length > 0 && renderFieldsTable(recordFields.map(f => ({ ...f, length: Number(f.length) })), 'Record Fields')}
              {footerFields.length > 0 && renderFieldsTable(footerFields.map(f => ({ ...f, length: Number(f.length) })), 'Footer Fields')}

              {uploadStatus.type && (
                <div
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg ${
                    uploadStatus.type === 'success'
                      ? 'bg-green-50 text-green-800 border border-green-200'
                      : 'bg-red-50 text-red-800 border border-red-200'
                  }`}
                >
                  {uploadStatus.type === 'success' ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <AlertCircle className="w-5 h-5" />
                  )}
                  <p className="text-sm">{uploadStatus.message}</p>
                </div>
              )}

              <div className="flex justify-end gap-3">
                <button
                  onClick={() => {
                    setEditModalSpec(null);
                    resetForm();
                    setUploadStatus({ type: null, message: '' });
                  }}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdate}
                  disabled={uploading}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Edit2 className="w-5 h-5" />
                      Update Spec
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

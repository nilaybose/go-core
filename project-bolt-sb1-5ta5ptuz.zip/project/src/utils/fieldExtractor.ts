export interface FieldMetadata {
  field_full_path: string;
  field_name: string;
  field_type: string;
  parent_full_path: string;
  depth_level: number;
  is_array: boolean;
  is_array_element: boolean;
  array_parent_path: string;
  sample_values: any[];
  nested_fields?: FieldMetadata[];
}

export interface FieldCatalog {
  [path: string]: FieldMetadata;
}

function inferType(value: any): string {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  if (typeof value === 'object') return 'object';
  if (typeof value === 'boolean') return 'boolean';
  if (typeof value === 'number') return 'number';
  if (typeof value === 'string') {
    if (/^\d{4}-\d{2}-\d{2}/.test(value)) return 'date';
    if (/^\d+$/.test(value)) return 'numeric_string';
    return 'string';
  }
  return 'unknown';
}

export function extractFieldsWithMetadata(
  jsonContent: any,
  prefix = '',
  parentPath = '',
  depth = 0,
  isArrayElement = false,
  arrayParentPath = ''
): FieldMetadata[] {
  const fields: FieldMetadata[] = [];

  if (typeof jsonContent !== 'object' || jsonContent === null) {
    return fields;
  }

  if (Array.isArray(jsonContent)) {
    const arrayPath = prefix || 'root';
    const arrayField: FieldMetadata = {
      field_full_path: `${arrayPath}[]`,
      field_name: arrayPath.split('.').pop() || 'root',
      field_type: 'array',
      parent_full_path: parentPath,
      depth_level: depth,
      is_array: true,
      is_array_element: isArrayElement,
      array_parent_path: arrayParentPath,
      sample_values: jsonContent.slice(0, 3),
      nested_fields: []
    };
    fields.push(arrayField);

    if (jsonContent.length > 0) {
      const firstElement = jsonContent[0];
      const elementType = inferType(firstElement);

      if (elementType === 'object') {
        const elementFields = extractFieldsWithMetadata(
          firstElement,
          `${arrayPath}[]`,
          arrayPath,
          depth + 1,
          true,
          `${arrayPath}[]`
        );
        arrayField.nested_fields = elementFields;
        fields.push(...elementFields);
      }
    }

    return fields;
  }

  Object.keys(jsonContent).forEach(key => {
    const value = jsonContent[key];
    const currentPath = prefix ? `${prefix}.${key}` : key;
    const fieldType = inferType(value);

    if (Array.isArray(value)) {
      const arrayFields = extractFieldsWithMetadata(
        value,
        currentPath,
        prefix || 'root',
        depth + 1,
        isArrayElement,
        arrayParentPath
      );
      fields.push(...arrayFields);
    } else if (fieldType === 'object') {
      const objectField: FieldMetadata = {
        field_full_path: currentPath,
        field_name: key,
        field_type: 'object',
        parent_full_path: prefix || 'root',
        depth_level: depth,
        is_array: false,
        is_array_element: isArrayElement,
        array_parent_path: arrayParentPath,
        sample_values: [value],
        nested_fields: []
      };
      fields.push(objectField);

      const nestedFields = extractFieldsWithMetadata(
        value,
        currentPath,
        prefix || 'root',
        depth + 1,
        isArrayElement,
        arrayParentPath
      );
      objectField.nested_fields = nestedFields;
      fields.push(...nestedFields);
    } else {
      const primitiveField: FieldMetadata = {
        field_full_path: currentPath,
        field_name: key,
        field_type: fieldType,
        parent_full_path: prefix || 'root',
        depth_level: depth,
        is_array: false,
        is_array_element: isArrayElement,
        array_parent_path: arrayParentPath,
        sample_values: [value]
      };
      fields.push(primitiveField);
    }
  });

  return fields;
}

export function buildFieldCatalog(fields: FieldMetadata[]): FieldCatalog {
  const catalog: FieldCatalog = {};
  fields.forEach(field => {
    catalog[field.field_full_path] = field;
  });
  return catalog;
}

export function findFieldsByType(catalog: FieldCatalog, type: string): FieldMetadata[] {
  return Object.values(catalog).filter(field => field.field_type === type);
}

export function findArrayFields(catalog: FieldCatalog): FieldMetadata[] {
  return Object.values(catalog).filter(field => field.is_array);
}

export function findPrimitiveFields(catalog: FieldCatalog): FieldMetadata[] {
  return Object.values(catalog).filter(field =>
    !field.is_array && field.field_type !== 'object'
  );
}

export function getFieldByPath(catalog: FieldCatalog, path: string): FieldMetadata | undefined {
  return catalog[path];
}

export function calculateFieldSimilarity(field1: FieldMetadata, field2: FieldMetadata): number {
  const name1 = field1.field_name.toLowerCase().replace(/[^a-z0-9]/g, '');
  const name2 = field2.field_name.toLowerCase().replace(/[^a-z0-9]/g, '');

  if (name1 === name2) return 1.0;
  if (name1.includes(name2) || name2.includes(name1)) return 0.9;

  const path1 = field1.field_full_path.toLowerCase().replace(/[^a-z0-9]/g, '');
  const path2 = field2.field_full_path.toLowerCase().replace(/[^a-z0-9]/g, '');

  if (path1.includes(path2) || path2.includes(path1)) return 0.85;

  const maxLen = Math.max(name1.length, name2.length);
  if (maxLen === 0) return 1.0;

  let matches = 0;
  for (let i = 0; i < Math.min(name1.length, name2.length); i++) {
    if (name1[i] === name2[i]) matches++;
  }

  return matches / maxLen;
}

export function buildFieldHierarchy(fields: FieldMetadata[]): FieldMetadata[] {
  const rootFields = fields.filter(f => f.parent_full_path === 'root' || f.parent_full_path === '');
  return rootFields;
}

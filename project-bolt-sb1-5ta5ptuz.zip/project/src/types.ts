export interface Message {
  role: 'user' | 'assistant';
  content: string;
  sources?: Source[];
  charts?: any[];
  attachments?: Attachment[];
}

export interface Attachment {
  filename: string;
  url: string;
}

export interface Source {
  filename: string;
  page_number: number;
  text_preview: string;
}

export interface ChatHistory {
  id: string;
  chat_id: string;
  user_query: string;
  model_response: string;
  created_at: string;
}

export interface FieldDefinition {
  name: string;
  type: string;
  length: number;
}

export interface ReconSpec {
  id: string;
  name: string;
  json_content: any;
  created_at: number;
  updated_at: number;
}

export interface AutoMapper {
  mapper_uuid: string;
  spec_mapper_uuid: string;
  recon_mapper_uuid: string;
  mapping_json: any;
  created_at: number;
  updated_at: number;
}

export interface SpecMapper {
  file_id: string;
  chat_id: string;
  spec_id: string;
  transaction_layout: string;
  filename: string;
  json_content: any;
  created_at: number;
  updated_at: number;
}

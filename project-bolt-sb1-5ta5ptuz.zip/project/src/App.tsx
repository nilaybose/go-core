import { useState } from 'react';
import { MessageSquare, FileText, Layers, Database, GitMerge } from 'lucide-react';
import ChatTab from './components/ChatTab';
import { DocumentsTab } from './components/DocumentsTab';
import { SystemPromptsTab } from './components/SystemPromptsTab';
import { ReconSpecsTab } from './components/ReconSpecsTab';
import { AutoMapperTab } from './components/AutoMapperTab';

type Tab = 'chat' | 'documents' | 'prompts' | 'recon' | 'automapper';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('chat');

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-gray-800">Spec-Talk</h1>
          <p className="text-sm text-gray-500 mt-1">
            Retrieval Augmented Generation powered by Milvus
          </p>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-6">
          <div className="flex gap-1">
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex items-center gap-2 px-6 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'chat'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-600 border-transparent hover:text-gray-800'
              }`}
            >
              <MessageSquare className="w-5 h-5" />
              Chat
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`flex items-center gap-2 px-6 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'documents'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-600 border-transparent hover:text-gray-800'
              }`}
            >
              <FileText className="w-5 h-5" />
              Specs
            </button>
            <button
              onClick={() => setActiveTab('prompts')}
              className={`flex items-center gap-2 px-6 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'prompts'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-600 border-transparent hover:text-gray-800'
              }`}
            >
              <Layers className="w-5 h-5" />
              System Prompts
            </button>
            <button
              onClick={() => setActiveTab('recon')}
              className={`flex items-center gap-2 px-6 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'recon'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-600 border-transparent hover:text-gray-800'
              }`}
            >
              <Database className="w-5 h-5" />
              Recon Specs
            </button>
            <button
              onClick={() => setActiveTab('automapper')}
              className={`flex items-center gap-2 px-6 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'automapper'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-600 border-transparent hover:text-gray-800'
              }`}
            >
              <GitMerge className="w-5 h-5" />
              Auto Mapper
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 container mx-auto bg-gray-50">
        <div className="h-[calc(100vh-180px)] bg-white shadow-sm">
          {activeTab === 'chat' && <ChatTab />}
          {activeTab === 'documents' && <DocumentsTab />}
          {activeTab === 'prompts' && <SystemPromptsTab />}
          {activeTab === 'recon' && <ReconSpecsTab />}
          {activeTab === 'automapper' && <AutoMapperTab />}
        </div>
      </main>
    </div>
  );
}

export default App;

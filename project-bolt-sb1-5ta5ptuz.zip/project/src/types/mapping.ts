export interface FieldMapping {
  mapping_id: string;
  mapping_type: 'direct' | 'list' | 'calculated';
  source_full_path: string;
  target_full_path: string;
  source_type: string;
  target_type: string;
  nlp_transformation_text?: string;
  transformation_config?: any;
  is_required: boolean;
  default_value?: any;
  execution_order: number;
  confidence?: number;
}

export interface SubFieldMapping {
  mapping_id: string;
  source_full_path: string;
  target_full_path: string;
  source_type: string;
  target_type: string;
  nlp_transformation_text?: string;
}

export interface ListMapping {
  mapping_id: string;
  source_list_paths: string[];
  target_list_path: string;
  merge_strategy: 'replace' | 'append' | 'merge_by_key';
  merge_key_source?: string;
  merge_key_target?: string;
  sub_field_mappings: SubFieldMapping[];
  array_transformation_nlp?: string;
  filter_condition_nlp?: string;
}

export interface GlobalTransformations {
  pre_processing_transformations: {
    transformation_id: string;
    nlp_text: string;
    execution_order: number;
  }[];
  post_processing_transformations: {
    transformation_id: string;
    nlp_text: string;
    execution_order: number;
  }[];
  document_level_nlp?: string;
  validation_rules: {
    rule_id: string;
    target_path: string;
    validation_type: string;
    nlp_text: string;
  }[];
}

export interface MappingMetadata {
  version: string;
  created_at: string;
  updated_at: string;
  created_by?: string;
  description?: string;
}

export interface SourceSchemaInfo {
  mapper_uuid: string;
  transaction_layout: string;
  full_field_catalog: {
    [path: string]: {
      field_type: string;
      sample_values: any[];
      is_array: boolean;
      parent_path: string;
    };
  };
}

export interface DestinationSchemaInfo {
  mapper_uuid: string;
  name: string;
  full_field_catalog: {
    [path: string]: {
      field_type: string;
      is_required: boolean;
      is_array: boolean;
      parent_path: string;
    };
  };
}

export interface CompleteMappingJSON {
  version: string;
  metadata: MappingMetadata;
  source_schema_info: SourceSchemaInfo;
  destination_schema_info: DestinationSchemaInfo;
  field_mappings: FieldMapping[];
  list_mappings: ListMapping[];
  global_transformations: GlobalTransformations;
}

from typing import TypedDict, Optional, List, Dict, Any, Annotated
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
import operator
import json
from ai.custom_llm_wrapper import CustomLLM
from db.pg_client import PgClient
from json_schema_generator import JSONSchemaGenerator


class AgentState(TypedDict):
    """State for the spec-parser agent workflow"""
    chat_id: str
    spec_id: str
    transaction_layout: Optional[str]
    full_document: Optional[str]
    discovered_structure: Optional[Dict[str, Any]]
    header_fields: Optional[List[Dict[str, Any]]]
    detail_fields: Optional[List[Dict[str, Any]]]
    trailer_fields: Optional[List[Dict[str, Any]]]
    generated_schema: Optional[str]
    json_schema_object: Optional[Dict[str, Any]]
    save_confirmed: Optional[bool]
    file_id: Optional[str]
    storage_path: Optional[str]
    save_status: Optional[str]
    confidence_scores: Dict[str, float]
    pending_questions: List[str]
    user_feedback: Optional[str]
    messages: Annotated[List[Dict[str, str]], operator.add]
    workflow_stage: str
    error: Optional[str]


class SpecParserAgent:
    """
    Intelligent spec-parser agent using LangGraph for workflow orchestration.
    Dynamically discovers file structure and generates JSON Schema.
    """

    def __init__(self, llm: CustomLLM, pg_client: PgClient):
        """
        Initialize the spec-parser agent.

        Args:
            llm: Custom LLM instance for analysis
            pg_client: PostgreSQL client for document retrieval and storage
        """
        self.llm = llm
        self.pg_client = pg_client
        self.schema_generator = JSONSchemaGenerator()
        self.checkpointer = MemorySaver()
        self.graph = self._build_graph()

    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow"""
        workflow = StateGraph(AgentState)

        workflow.add_node("check_transaction_layout", self.check_transaction_layout)
        workflow.add_node("retrieve_document", self.retrieve_document)
        workflow.add_node("discover_structure", self.discover_structure)
        workflow.add_node("confirm_structure", self.confirm_structure)
        workflow.add_node("extract_header_fields", self.extract_header_fields)
        workflow.add_node("extract_detail_fields", self.extract_detail_fields)
        workflow.add_node("extract_trailer_fields", self.extract_trailer_fields)
        workflow.add_node("generate_schema", self.generate_schema)
        workflow.add_node("present_schema", self.present_schema)
        workflow.add_node("handle_error", self.handle_error)

        workflow.set_entry_point("check_transaction_layout")

        workflow.add_conditional_edges(
            "check_transaction_layout",
            self.route_after_layout_check,
            {
                "need_layout": END,
                "has_layout": "retrieve_document",
                "error": "handle_error"
            }
        )

        workflow.add_conditional_edges(
            "retrieve_document",
            self.route_after_retrieval,
            {
                "success": "discover_structure",
                "error": "handle_error"
            }
        )

        workflow.add_conditional_edges(
            "discover_structure",
            self.route_after_discovery,
            {
                "high_confidence": "extract_header_fields",
                "low_confidence": "confirm_structure",
                "error": "handle_error"
            }
        )

        workflow.add_edge("confirm_structure", END)

        workflow.add_conditional_edges(
            "extract_header_fields",
            self.route_after_header_extraction,
            {
                "has_header": "extract_detail_fields",
                "no_header": "extract_detail_fields",
                "error": "handle_error"
            }
        )

        workflow.add_conditional_edges(
            "extract_detail_fields",
            self.route_after_detail_extraction,
            {
                "success": "extract_trailer_fields",
                "error": "handle_error"
            }
        )

        workflow.add_conditional_edges(
            "extract_trailer_fields",
            self.route_after_trailer_extraction,
            {
                "has_trailer": "generate_schema",
                "no_trailer": "generate_schema",
                "error": "handle_error"
            }
        )

        workflow.add_edge("generate_schema", "present_schema")
        workflow.add_edge("present_schema", END)
        workflow.add_edge("handle_error", END)

        return workflow.compile(checkpointer=self.checkpointer)

    def check_transaction_layout(self, state: AgentState) -> AgentState:
        """Check if transaction layout has been specified"""
        state["workflow_stage"] = "checking_layout"

        if not state.get("transaction_layout"):
            state["messages"].append({
                "role": "assistant",
                "content": "Please specify which transaction layout you want me to parse from this specification. For example, you might say 'Parse the Payment Transaction layout' or 'Extract the Refund Transaction structure'."
            })
            state["pending_questions"] = ["transaction_layout_selection"]
        else:
            state["messages"].append({
                "role": "assistant",
                "content": f"Analyzing the **{state['transaction_layout']}** layout from the specification..."
            })

        return state

    def retrieve_document(self, state: AgentState) -> AgentState:
        """Retrieve and reconstruct full document from pgvector"""
        state["workflow_stage"] = "retrieving_document"

        try:
            results = self.pg_client.get_document_chunks_by_uuid(state["spec_id"])

            if not results:
                state["error"] = "No document found for the specified spec ID"
                return state

            chunks = sorted(results, key=lambda x: x.get("page_number", 0))
            full_text = "\n\n".join([chunk.get("text", "") for chunk in chunks])

            state["full_document"] = full_text
            state["messages"].append({
                "role": "assistant",
                "content": f"Retrieved specification document ({len(chunks)} pages). Analyzing structure..."
            })

        except Exception as e:
            state["error"] = f"Error retrieving document: {str(e)}"

        return state

    def discover_structure(self, state: AgentState) -> AgentState:
        """Discover file structure from the full document"""
        state["workflow_stage"] = "discovering_structure"

        prompt = f"""Analyze the following file specification document and identify the structure for the "{state['transaction_layout']}" layout.

Document:
{state['full_document'][:8000]}

Please analyze and respond in JSON format with:
{{
  "has_header": true/false,
  "has_trailer": true/false,
  "detail_record_types": ["list", "of", "record", "types"],
  "file_format": "fixed-length" | "delimited" | "csv" | "positional",
  "record_identifiers": {{"header": "value", "detail": "value", "trailer": "value"}},
  "confidence": 0.0-1.0,
  "notes": "any observations or ambiguities"
}}

Focus only on the "{state['transaction_layout']}" layout. Ignore other transaction types."""

        try:
            response = self.llm._call(prompt)

            response_clean = response.strip()
            if response_clean.startswith("```json"):
                response_clean = response_clean[7:]
            if response_clean.startswith("```"):
                response_clean = response_clean[3:]
            if response_clean.endswith("```"):
                response_clean = response_clean[:-3]
            response_clean = response_clean.strip()

            structure = json.loads(response_clean)
            state["discovered_structure"] = structure
            state["confidence_scores"] = {"structure_discovery": structure.get("confidence", 0.5)}

            summary = f"""**Structure Discovery Complete**

Layout: {state['transaction_layout']}
- File Format: {structure.get('file_format', 'unknown')}
- Has Header: {structure.get('has_header', False)}
- Has Trailer: {structure.get('has_trailer', False)}
- Detail Record Types: {', '.join(structure.get('detail_record_types', []))}
- Confidence: {structure.get('confidence', 0.5):.0%}

{structure.get('notes', '')}"""

            state["messages"].append({
                "role": "assistant",
                "content": summary
            })

        except Exception as e:
            state["error"] = f"Error discovering structure: {str(e)}"

        return state

    def confirm_structure(self, state: AgentState) -> AgentState:
        """Ask user to confirm structure if confidence is low"""
        state["workflow_stage"] = "awaiting_confirmation"

        structure = state.get("discovered_structure", {})
        question = f"""I found the following structure with {structure.get('confidence', 0):.0%} confidence. Please confirm or correct:

- Has Header Record: **{structure.get('has_header', False)}**
- Has Trailer Record: **{structure.get('has_trailer', False)}**
- File Format: **{structure.get('file_format', 'unknown')}**
- Detail Record Types: **{', '.join(structure.get('detail_record_types', []))}**

Reply with "looks good" to proceed, or provide corrections."""

        state["messages"].append({
            "role": "assistant",
            "content": question
        })
        state["pending_questions"] = ["structure_confirmation"]

        return state

    def extract_header_fields(self, state: AgentState) -> AgentState:
        """Extract header fields using RAG"""
        state["workflow_stage"] = "extracting_header"

        structure = state.get("discovered_structure", {})

        if not structure.get("has_header"):
            state["header_fields"] = []
            return state

        try:
            layout_name = state["transaction_layout"]
            query = f"{layout_name} header record layout fields structure"
            query_embedding = self.pg_client.embedding_function([query])[0]

            rag_results = self.pg_client.search_by_content_uuid(
                query_embedding,
                state["spec_id"],
                top_k=3
            )

            context = "\n\n".join([r.get("text", "") for r in rag_results])

            prompt = f"""Extract header record fields from this specification section:

{context}

Return JSON array of fields with structure:
[
  {{"name": "field_name", "position": 1, "length": 10, "type": "string", "format": "", "required": true}},
  ...
]"""

            response = self.llm._call(prompt)
            response_clean = response.strip()
            if response_clean.startswith("```json"):
                response_clean = response_clean[7:]
            if response_clean.startswith("```"):
                response_clean = response_clean[3:]
            if response_clean.endswith("```"):
                response_clean = response_clean[:-3]
            response_clean = response_clean.strip()

            fields = json.loads(response_clean)
            state["header_fields"] = fields

            state["messages"].append({
                "role": "assistant",
                "content": f"Extracted {len(fields)} header fields."
            })

        except Exception as e:
            state["error"] = f"Error extracting header fields: {str(e)}"
            state["header_fields"] = []

        return state

    def extract_detail_fields(self, state: AgentState) -> AgentState:
        """Extract detail/body record fields using RAG"""
        state["workflow_stage"] = "extracting_detail"

        try:
            layout_name = state["transaction_layout"]
            query = f"{layout_name} detail body record layout fields structure"
            query_embedding = self.pg_client.embedding_function([query])[0]

            rag_results = self.pg_client.search_by_content_uuid(
                query_embedding,
                state["spec_id"],
                top_k=5
            )

            context = "\n\n".join([r.get("text", "") for r in rag_results])

            prompt = f"""Extract detail/body record fields from this specification section:

{context}

Return JSON array of fields:
[
  {{"name": "field_name", "position": 1, "length": 10, "type": "string", "format": "", "required": true}},
  ...
]"""

            response = self.llm._call(prompt)
            response_clean = response.strip()
            if response_clean.startswith("```json"):
                response_clean = response_clean[7:]
            if response_clean.startswith("```"):
                response_clean = response_clean[3:]
            if response_clean.endswith("```"):
                response_clean = response_clean[:-3]
            response_clean = response_clean.strip()

            fields = json.loads(response_clean)
            state["detail_fields"] = fields

            state["messages"].append({
                "role": "assistant",
                "content": f"Extracted {len(fields)} detail record fields."
            })

        except Exception as e:
            state["error"] = f"Error extracting detail fields: {str(e)}"
            state["detail_fields"] = []

        return state

    def extract_trailer_fields(self, state: AgentState) -> AgentState:
        """Extract trailer fields using RAG"""
        state["workflow_stage"] = "extracting_trailer"

        structure = state.get("discovered_structure", {})

        if not structure.get("has_trailer"):
            state["trailer_fields"] = []
            return state

        try:
            layout_name = state["transaction_layout"]
            query = f"{layout_name} trailer footer record layout fields structure"
            query_embedding = self.pg_client.embedding_function([query])[0]

            rag_results = self.pg_client.search_by_content_uuid(
                query_embedding,
                state["spec_id"],
                top_k=3
            )

            context = "\n\n".join([r.get("text", "") for r in rag_results])

            prompt = f"""Extract trailer/footer record fields from this specification section:

{context}

Return JSON array of fields:
[
  {{"name": "field_name", "position": 1, "length": 10, "type": "string", "format": "", "required": true}},
  ...
]"""

            response = self.llm._call(prompt)
            response_clean = response.strip()
            if response_clean.startswith("```json"):
                response_clean = response_clean[7:]
            if response_clean.startswith("```"):
                response_clean = response_clean[3:]
            if response_clean.endswith("```"):
                response_clean = response_clean[:-3]
            response_clean = response_clean.strip()

            fields = json.loads(response_clean)
            state["trailer_fields"] = fields

            state["messages"].append({
                "role": "assistant",
                "content": f"Extracted {len(fields)} trailer fields."
            })

        except Exception as e:
            state["error"] = f"Error extracting trailer fields: {str(e)}"
            state["trailer_fields"] = []

        return state

    def generate_schema(self, state: AgentState) -> AgentState:
        """
        Generate JSON Schema from extracted fields.
        """
        state["workflow_stage"] = "generating_schema"

        try:
            structure = state.get("discovered_structure", {})
            header_fields = state.get("header_fields", [])
            detail_fields = state.get("detail_fields", [])
            trailer_fields = state.get("trailer_fields", [])

            json_schema = self.schema_generator.generate_schema(
                layout_name=state["transaction_layout"],
                discovered_structure=structure,
                header_fields=header_fields,
                detail_fields=detail_fields,
                trailer_fields=trailer_fields,
                spec_id=state["spec_id"],
                chat_id=state["chat_id"]
            )

            is_valid, validation_errors = self.schema_generator.validate_schema(json_schema)

            if not is_valid:
                state["error"] = f"Schema validation failed: {', '.join(validation_errors)}"
                return state

            schema_string = self.schema_generator.format_schema_string(json_schema)
            field_counts = self.schema_generator.calculate_field_counts(json_schema)

            state["json_schema_object"] = json_schema
            state["generated_schema"] = schema_string

            preview_length = 1500
            preview = schema_string if len(schema_string) < preview_length else schema_string[:preview_length] + "\n..."

            state["messages"].append({
                "role": "assistant",
                "content": f"""**JSON Schema Generated Successfully**

The system has generated a JSON Schema for your file layout:
- **Layout:** {state["transaction_layout"]}
- **Format:** {structure.get("file_format", "unknown")}
- **Header fields:** {field_counts["header"]}
- **Detail fields:** {field_counts["detail"]}
- **Trailer fields:** {field_counts["trailer"]}
- **Total fields:** {field_counts["total"]}

**Preview:**
```json
{preview}
```
"""
            })

        except Exception as e:
            state["error"] = f"Error generating JSON Schema: {str(e)}"
            state["messages"].append({
                "role": "assistant",
                "content": f"**Error generating JSON Schema:** {str(e)}"
            })

        return state

    def present_schema(self, state: AgentState) -> AgentState:
        """Present the generated JSON Schema to the user"""
        state["workflow_stage"] = "completed"

        json_schema = state.get("json_schema_object", {})
        field_counts = self.schema_generator.calculate_field_counts(json_schema)

        state["messages"].append({
            "role": "assistant",
            "content": f"""**JSON Schema Generation Complete**

Your JSON Schema has been generated successfully:
- **Transaction Layout:** {state.get("transaction_layout", "Unknown")}
- **Total Fields:** {field_counts["total"]} ({field_counts["header"]} header, {field_counts["detail"]} detail, {field_counts["trailer"]} trailer)

The JSON Schema is now available for download or use in your application."""
        })

        return state


    def handle_error(self, state: AgentState) -> AgentState:
        """Handle errors in workflow"""
        error_msg = state.get("error", "Unknown error occurred")
        state["messages"].append({
            "role": "assistant",
            "content": f"**Error:** {error_msg}"
        })
        return state

    def route_after_layout_check(self, state: AgentState) -> str:
        """Route after checking transaction layout"""
        if state.get("error"):
            return "error"
        if not state.get("transaction_layout"):
            return "need_layout"
        return "has_layout"

    def route_after_retrieval(self, state: AgentState) -> str:
        """Route after document retrieval"""
        if state.get("error"):
            return "error"
        return "success"

    def route_after_discovery(self, state: AgentState) -> str:
        """Route after structure discovery"""
        if state.get("error"):
            return "error"
        confidence = state.get("confidence_scores", {}).get("structure_discovery", 0.5)
        if confidence >= 0.7:
            return "high_confidence"
        return "low_confidence"

    def route_after_header_extraction(self, state: AgentState) -> str:
        """Route after header extraction"""
        if state.get("error"):
            return "error"
        structure = state.get("discovered_structure", {})
        if structure.get("has_header"):
            return "has_header"
        return "no_header"

    def route_after_detail_extraction(self, state: AgentState) -> str:
        """Route after detail extraction"""
        if state.get("error"):
            return "error"
        return "success"

    def route_after_trailer_extraction(self, state: AgentState) -> str:
        """Route after trailer extraction"""
        if state.get("error"):
            return "error"
        structure = state.get("discovered_structure", {})
        if structure.get("has_trailer"):
            return "has_trailer"
        return "no_trailer"


    async def run(self, chat_id: str, spec_id: str, transaction_layout: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the spec-parser agent workflow.

        Args:
            chat_id: Chat session ID (used as thread_id)
            spec_id: Content UUID of the specification document
            transaction_layout: Optional transaction layout to parse

        Returns:
            Agent execution result with messages and generated XML
        """
        config = {"configurable": {"thread_id": chat_id}}

        initial_state = {
            "chat_id": chat_id,
            "spec_id": spec_id,
            "transaction_layout": transaction_layout,
            "full_document": None,
            "discovered_structure": None,
            "header_fields": None,
            "detail_fields": None,
            "trailer_fields": None,
            "generated_schema": None,
            "json_schema_object": None,
            "save_confirmed": None,
            "file_id": None,
            "storage_path": None,
            "save_status": None,
            "confidence_scores": {},
            "pending_questions": [],
            "user_feedback": None,
            "messages": [],
            "workflow_stage": "initialized",
            "error": None
        }

        result = await self.graph.ainvoke(initial_state, config)

        return {
            "messages": result.get("messages", []),
            "generated_schema": result.get("generated_schema"),
            "json_schema_object": result.get("json_schema_object"),
            "file_id": result.get("file_id"),
            "storage_path": result.get("storage_path"),
            "save_status": result.get("save_status"),
            "workflow_stage": result.get("workflow_stage"),
            "pending_questions": result.get("pending_questions", []),
            "error": result.get("error")
        }

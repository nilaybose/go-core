from typing import Dict, Any, List, Optional
from datetime import datetime
import json


class JSONSchemaGenerator:
    """
    Generates JSON Schema from file specification documents.
    Produces standard JSON Schema (draft-07) for validation and documentation.
    """

    def __init__(self):
        self.schema_version = "http://json-schema.org/draft-07/schema#"

    def generate_schema(
        self,
        layout_name: str,
        discovered_structure: Dict[str, Any],
        header_fields: Optional[List[Dict[str, Any]]] = None,
        detail_fields: Optional[List[Dict[str, Any]]] = None,
        trailer_fields: Optional[List[Dict[str, Any]]] = None,
        spec_id: str = "",
        chat_id: str = ""
    ) -> Dict[str, Any]:
        """
        Generate a JSON Schema from extracted fields.

        Args:
            layout_name: Name of the transaction layout
            discovered_structure: Discovered file structure metadata
            header_fields: List of header record fields
            detail_fields: List of detail/body record fields
            trailer_fields: List of trailer record fields
            spec_id: Content UUID of the specification
            chat_id: Chat session ID

        Returns:
            Complete JSON Schema as dictionary
        """
        schema = {
            "$schema": self.schema_version,
            "$id": f"urn:spec:{spec_id}:{layout_name}",
            "title": layout_name,
            "description": f"JSON Schema for {layout_name} file layout",
            "type": "object",
            "properties": {},
            "required": [],
            "x-metadata": {
                "spec_id": spec_id,
                "chat_id": chat_id,
                "file_format": discovered_structure.get("file_format", "fixed-length"),
                "confidence_score": discovered_structure.get("confidence", 0.0),
                "discovery_notes": discovered_structure.get("notes", ""),
                "generated_at": datetime.utcnow().isoformat() + "Z"
            }
        }

        record_identifiers = discovered_structure.get("record_identifiers", {})

        if header_fields and len(header_fields) > 0:
            schema["properties"]["header"] = self._build_record_schema(
                "header",
                header_fields,
                record_identifiers.get("header")
            )
            schema["required"].append("header")

        if detail_fields and len(detail_fields) > 0:
            schema["properties"]["details"] = {
                "type": "array",
                "items": self._build_record_schema(
                    "detail",
                    detail_fields,
                    record_identifiers.get("detail")
                ),
                "minItems": 0
            }
            schema["required"].append("details")

        if trailer_fields and len(trailer_fields) > 0:
            schema["properties"]["trailer"] = self._build_record_schema(
                "trailer",
                trailer_fields,
                record_identifiers.get("trailer")
            )
            schema["required"].append("trailer")

        return schema

    def _build_record_schema(
        self,
        record_type: str,
        fields: List[Dict[str, Any]],
        identifier_value: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Build a JSON Schema for a record type.

        Args:
            record_type: Type of record (header, detail, trailer)
            fields: List of field definitions
            identifier_value: Record identifier value if applicable

        Returns:
            JSON Schema for the record
        """
        record_schema = {
            "type": "object",
            "properties": {},
            "required": [],
            "x-record-type": record_type
        }

        if identifier_value:
            first_field = fields[0] if fields else {}
            record_schema["x-identifier"] = {
                "value": identifier_value,
                "position": first_field.get("position", 1),
                "length": first_field.get("length", len(identifier_value))
            }

        for field in fields:
            field_name = field.get("name", "")
            field_type = field.get("type", "string")

            field_schema = self._map_field_type_to_json_schema(field_type)

            if field.get("format"):
                field_schema["format"] = field["format"]

            if field.get("default"):
                field_schema["default"] = field["default"]

            if field.get("description"):
                field_schema["description"] = field["description"]

            field_schema["x-position"] = field.get("position", 0)
            field_schema["x-length"] = field.get("length", 0)

            if field.get("validation"):
                validation = field["validation"]
                if "pattern" in validation:
                    field_schema["pattern"] = validation["pattern"]
                if "minimum" in validation:
                    field_schema["minimum"] = validation["minimum"]
                if "maximum" in validation:
                    field_schema["maximum"] = validation["maximum"]
                if "minLength" in validation:
                    field_schema["minLength"] = validation["minLength"]
                if "maxLength" in validation:
                    field_schema["maxLength"] = validation["maxLength"]

            record_schema["properties"][field_name] = field_schema

            if field.get("required", False):
                record_schema["required"].append(field_name)

        return record_schema

    def _map_field_type_to_json_schema(self, field_type: str) -> Dict[str, Any]:
        """
        Map field type to JSON Schema type.

        Args:
            field_type: Field type from extraction

        Returns:
            JSON Schema type definition
        """
        type_mapping = {
            "string": {"type": "string"},
            "text": {"type": "string"},
            "integer": {"type": "integer"},
            "int": {"type": "integer"},
            "number": {"type": "number"},
            "decimal": {"type": "number"},
            "boolean": {"type": "boolean"},
            "bool": {"type": "boolean"},
            "date": {"type": "string", "format": "date"},
            "datetime": {"type": "string", "format": "date-time"},
            "timestamp": {"type": "string", "format": "date-time"},
            "time": {"type": "string", "format": "time"}
        }

        return type_mapping.get(field_type.lower(), {"type": "string"})

    def validate_schema(self, schema: Dict[str, Any]) -> tuple[bool, List[str]]:
        """
        Validate a JSON Schema for completeness and correctness.

        Args:
            schema: JSON Schema to validate

        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []

        if not schema.get("$schema"):
            errors.append("Missing required field: $schema")

        if not schema.get("title"):
            errors.append("Missing required field: title")

        if schema.get("type") != "object":
            errors.append("Root type must be 'object'")

        if not schema.get("properties"):
            errors.append("No properties defined in schema")

        for prop_name, prop_schema in schema.get("properties", {}).items():
            if not isinstance(prop_schema, dict):
                errors.append(f"Property '{prop_name}': Invalid schema definition")
                continue

            if "type" not in prop_schema:
                errors.append(f"Property '{prop_name}': Missing type")

            if prop_schema.get("type") == "object" and not prop_schema.get("properties"):
                errors.append(f"Property '{prop_name}': Object type must have properties")

            if prop_schema.get("type") == "array" and not prop_schema.get("items"):
                errors.append(f"Property '{prop_name}': Array type must have items")

        return (len(errors) == 0, errors)

    def format_schema_string(self, schema: Dict[str, Any], indent: int = 2) -> str:
        """
        Format JSON Schema as pretty-printed string.

        Args:
            schema: JSON Schema dictionary
            indent: Number of spaces for indentation

        Returns:
            Formatted JSON string
        """
        return json.dumps(schema, indent=indent, ensure_ascii=False)

    def calculate_field_counts(self, schema: Dict[str, Any]) -> Dict[str, int]:
        """
        Calculate field counts by record type.

        Args:
            schema: JSON Schema dictionary

        Returns:
            Dictionary with field counts
        """
        counts = {
            "header": 0,
            "detail": 0,
            "trailer": 0,
            "total": 0
        }

        properties = schema.get("properties", {})

        if "header" in properties:
            header_props = properties["header"].get("properties", {})
            counts["header"] = len(header_props)
            counts["total"] += counts["header"]

        if "details" in properties:
            detail_items = properties["details"].get("items", {})
            detail_props = detail_items.get("properties", {})
            counts["detail"] = len(detail_props)
            counts["total"] += counts["detail"]

        if "trailer" in properties:
            trailer_props = properties["trailer"].get("properties", {})
            counts["trailer"] = len(trailer_props)
            counts["total"] += counts["trailer"]

        return counts

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    pgvector_connection_string: Optional[str] = None
    gemini_api_key: Optional[str] = None
    custom_llm_endpoint: Optional[str] = None
    custom_llm_api_key: Optional[str] = None
    custom_llm_model_name: str = "custom-model"

    class Config:
        env_file = ".env"


settings = Settings()

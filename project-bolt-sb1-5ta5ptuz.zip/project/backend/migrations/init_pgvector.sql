-- Initialize PostgreSQL database with pgvector support
-- This migration sets up all required tables and indexes for the RAG chatbot

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Table: docs_vector
-- Stores document embeddings with vector similarity search capability
-- ONLY table that contains vector embeddings (768 dimensions)
CREATE TABLE IF NOT EXISTS docs_vector (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    embedding vector(768) NOT NULL,
    text TEXT NOT NULL,
    filename TEXT,
    page_number INTEGER,
    metadata JSONB,
    content_uuid UUID,
    created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE docs_vector IS 'Document embeddings for vector similarity search';
COMMENT ON COLUMN docs_vector.embedding IS '768-dimensional embedding vector';
COMMENT ON COLUMN docs_vector.text IS 'Text chunk content';
COMMENT ON COLUMN docs_vector.metadata IS 'Additional metadata as JSON';

-- Table: chat_history
-- Stores chat conversation history (NO vectors)
CREATE TABLE IF NOT EXISTS chat_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID UNIQUE NOT NULL,
    chat_id UUID NOT NULL,
    user_query TEXT NOT NULL,
    model_response TEXT NOT NULL,
    agent TEXT DEFAULT 'RAG',
    spec_id UUID,
    timestamp BIGINT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE chat_history IS 'Chat conversation history';
COMMENT ON COLUMN chat_history.agent IS 'Agent type: RAG, Analytics, or Spec-Parser';

-- Table: contents
-- Stores uploaded document content and processing status (NO vectors)
CREATE TABLE IF NOT EXISTS contents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_uuid UUID UNIQUE NOT NULL,
    filename TEXT NOT NULL,
    base64_content TEXT,
    status TEXT DEFAULT 'processing',
    created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE contents IS 'Uploaded document content and processing status';
COMMENT ON COLUMN contents.status IS 'Status: processing, completed, or failed';

-- Table: sys_prompts
-- Stores system prompts for chat agents (NO vectors)
CREATE TABLE IF NOT EXISTS sys_prompts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prompt_uuid UUID UNIQUE NOT NULL,
    name TEXT NOT NULL,
    prompt_text TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE sys_prompts IS 'System prompts for chat agents';

-- Table: spec_mappings
-- Stores generated file specification mappings (NO vectors)
-- UNIQUE constraint on chat_id ensures one mapping per chat session
CREATE TABLE IF NOT EXISTS spec_mappings (
    file_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id UUID UNIQUE NOT NULL,
    spec_id UUID,
    transaction_layout TEXT NOT NULL,
    filename TEXT NOT NULL,
    json_content JSONB NOT NULL,
    file_size INTEGER,
    storage_path TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    metadata JSONB
);

COMMENT ON TABLE spec_mappings IS 'Generated file specification mappings in JSON format';
COMMENT ON COLUMN spec_mappings.chat_id IS 'Unique per chat session - UPSERT on conflict';
COMMENT ON COLUMN spec_mappings.json_content IS 'Complete mapping as JSONB for querying';
COMMENT ON COLUMN spec_mappings.storage_path IS 'Storage path identifier';

-- INDEXES for docs_vector table
-- HNSW index for fast vector similarity search with cosine distance
CREATE INDEX IF NOT EXISTS docs_vector_embedding_idx
ON docs_vector USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);

CREATE INDEX IF NOT EXISTS docs_vector_content_uuid_idx ON docs_vector (content_uuid);
CREATE INDEX IF NOT EXISTS docs_vector_filename_idx ON docs_vector (filename);
CREATE INDEX IF NOT EXISTS docs_vector_created_at_idx ON docs_vector (created_at DESC);

COMMENT ON INDEX docs_vector_embedding_idx IS 'HNSW index for fast vector similarity search';

-- INDEXES for chat_history table
CREATE INDEX IF NOT EXISTS chat_history_chat_id_idx ON chat_history (chat_id);
CREATE INDEX IF NOT EXISTS chat_history_timestamp_idx ON chat_history (timestamp DESC);
CREATE INDEX IF NOT EXISTS chat_history_spec_id_idx ON chat_history (spec_id);
CREATE INDEX IF NOT EXISTS chat_history_agent_idx ON chat_history (agent);

-- INDEXES for contents table
CREATE INDEX IF NOT EXISTS contents_content_uuid_idx ON contents (content_uuid);
CREATE INDEX IF NOT EXISTS contents_status_idx ON contents (status);
CREATE INDEX IF NOT EXISTS contents_created_at_idx ON contents (created_at DESC);
CREATE INDEX IF NOT EXISTS contents_filename_idx ON contents (filename);

-- INDEXES for sys_prompts table
CREATE INDEX IF NOT EXISTS sys_prompts_prompt_uuid_idx ON sys_prompts (prompt_uuid);
CREATE INDEX IF NOT EXISTS sys_prompts_created_at_idx ON sys_prompts (created_at DESC);
CREATE INDEX IF NOT EXISTS sys_prompts_name_idx ON sys_prompts (name);

-- INDEXES for spec_mappings table
CREATE INDEX IF NOT EXISTS spec_mappings_chat_id_idx ON spec_mappings (chat_id);
CREATE INDEX IF NOT EXISTS spec_mappings_spec_id_idx ON spec_mappings (spec_id);
CREATE INDEX IF NOT EXISTS spec_mappings_updated_at_idx ON spec_mappings (updated_at DESC);
CREATE INDEX IF NOT EXISTS spec_mappings_transaction_layout_idx ON spec_mappings (transaction_layout);

-- GIN indexes for JSONB columns (efficient querying of JSON fields)
CREATE INDEX IF NOT EXISTS spec_mappings_json_content_idx ON spec_mappings USING gin (json_content);
CREATE INDEX IF NOT EXISTS spec_mappings_metadata_idx ON spec_mappings USING gin (metadata);

COMMENT ON INDEX spec_mappings_json_content_idx IS 'GIN index for efficient JSONB querying';

-- Optional: Create a function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-update updated_at in spec_mappings
DROP TRIGGER IF EXISTS update_spec_mappings_updated_at ON spec_mappings;
CREATE TRIGGER update_spec_mappings_updated_at
    BEFORE UPDATE ON spec_mappings
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Migration complete
-- Verify installation:
-- SELECT * FROM pg_extension WHERE extname = 'vector';
-- SELECT tablename FROM pg_tables WHERE schemaname = 'public';

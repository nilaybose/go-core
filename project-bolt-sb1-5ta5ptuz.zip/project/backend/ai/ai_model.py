from typing import List, Dict, Any, Optional
from abc import ABC, abstractmethod
import google.generativeai as genai


class AIModel(ABC):
    """
    Abstract base class for AI model integration.
    Implement this class with your preferred LLM provider (OpenAI, Anthropic, Gemini, etc.)
    """

    @abstractmethod
    async def embed(self, text: str) -> List[float]:
        """
        Generate embedding for a given text.

        Args:
            text: Input text to embed

        Returns:
            List of floats representing the embedding vector
        """
        pass

    @abstractmethod
    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts in batch.

        Args:
            texts: List of input texts to embed

        Returns:
            List of embedding vectors
        """
        pass

    @abstractmethod
    async def chat(
        self,
        messages: List[Dict[str, str]],
        context: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> str:
        """
        Generate chat response.

        Args:
            messages: List of message dicts with 'role' and 'content'
            context: Optional context from RAG retrieval
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate

        Returns:
            Generated response text
        """
        pass


class GeminiModel(AIModel):
    """
    Google Gemini implementation of AIModel.
    """

    def __init__(self, api_key: str):
        self.api_key = api_key
        genai.configure(api_key=api_key)
        self.embedding_model = "models/embedding-001"
        self.chat_model = "gemini-pro"

    async def embed(self, text: str) -> List[float]:
        """
        Generate embedding using Gemini API.
        """
        result = genai.embed_content(
            model=self.embedding_model,
            content=text,
            task_type="retrieval_document"
        )
        return result['embedding']

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings in batch using Gemini API.
        """
        embeddings = []
        for text in texts:
            result = genai.embed_content(
                model=self.embedding_model,
                content=text,
                task_type="retrieval_document"
            )
            embeddings.append(result['embedding'])
        return embeddings

    async def chat(
        self,
        messages: List[Dict[str, str]],
        context: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> str:
        """
        Generate chat response using Gemini API.
        """
        model = genai.GenerativeModel(self.chat_model)

        # Build prompt from messages and context
        prompt_parts = []

        if context:
            prompt_parts.append(f"Use the following context to answer the user's question:\n\n{context}\n\n")

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "user":
                prompt_parts.append(f"User: {content}\n")
            elif role == "assistant":
                prompt_parts.append(f"Assistant: {content}\n")
            elif role == "system":
                prompt_parts.append(f"{content}\n")

        prompt = "".join(prompt_parts)

        generation_config = genai.types.GenerationConfig(
            temperature=temperature,
            max_output_tokens=max_tokens
        )

        response = model.generate_content(
            prompt,
            generation_config=generation_config
        )

        return response.text


class OpenAIModel(AIModel):
    """
    OpenAI implementation of AIModel.
    To be implemented with actual OpenAI API calls.
    """

    def __init__(self, api_key: str):
        self.api_key = api_key

    async def embed(self, text: str) -> List[float]:
        """
        Generate embedding using OpenAI API.

        Example implementation:
        ```
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=self.api_key)
        response = await client.embeddings.create(
            model="text-embedding-ada-002",
            input=text
        )
        return response.data[0].embedding
        ```
        """
        raise NotImplementedError("OpenAI embedding not yet implemented")

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings in batch using OpenAI API.

        Example implementation:
        ```
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=self.api_key)
        response = await client.embeddings.create(
            model="text-embedding-ada-002",
            input=texts
        )
        return [item.embedding for item in response.data]
        ```
        """
        raise NotImplementedError("OpenAI batch embedding not yet implemented")

    async def chat(
        self,
        messages: List[Dict[str, str]],
        context: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> str:
        """
        Generate chat response using OpenAI API.

        Example implementation:
        ```
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=self.api_key)

        # Add context to system message if provided
        if context:
            system_msg = {
                "role": "system",
                "content": f"Use the following context to answer the user's question:\n\n{context}"
            }
            messages = [system_msg] + messages

        response = await client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens
        )
        return response.choices[0].message.content
        ```
        """
        raise NotImplementedError("OpenAI chat not yet implemented")


def get_ai_model(provider: str = "gemini", api_key: Optional[str] = None) -> AIModel:
    """
    Factory function to instantiate AI model based on provider.

    Args:
        provider: AI provider name ("gemini", "openai", "anthropic", etc.)
        api_key: API key for the provider

    Returns:
        AIModel instance
    """
    if provider == "gemini":
        return GeminiModel(api_key=api_key)
    elif provider == "openai":
        return OpenAIModel(api_key=api_key)
    else:
        raise ValueError(f"Unsupported AI provider: {provider}")

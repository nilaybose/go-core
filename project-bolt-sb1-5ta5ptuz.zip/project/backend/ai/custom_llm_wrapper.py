from typing import Any, List, Optional, Dict, Iterator
from langchain_core.language_models.llms import BaseLLM
from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.outputs import GenerationChunk, LLMResult, Generation
import httpx
import json
from config.settings import settings


class CustomLLM(BaseLLM):
    """
    Custom LLM wrapper compatible with LangChain/LangGraph interface.
    Integrates with a custom API endpoint for LLM operations.
    """

    api_endpoint: str
    api_key: Optional[str] = None
    model_name: str = "custom-model"
    temperature: float = 0.7
    max_tokens: int = 4096
    timeout: int = 120

    @property
    def _llm_type(self) -> str:
        """Return identifier for this LLM type."""
        return "custom"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """
        Call the custom LLM API with the given prompt.

        Args:
            prompt: The input prompt text
            stop: Optional list of stop sequences
            run_manager: Callback manager for tracking
            **kwargs: Additional parameters

        Returns:
            Generated text response
        """
        headers = {
            "Content-Type": "application/json"
        }

        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "prompt": prompt,
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
            "model": self.model_name
        }

        if stop:
            payload["stop"] = stop

        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.post(
                    self.api_endpoint,
                    headers=headers,
                    json=payload
                )
                response.raise_for_status()

                result = response.json()

                generated_text = result.get("text") or result.get("response") or result.get("output", "")

                return generated_text

        except httpx.HTTPError as e:
            raise Exception(f"Custom LLM API error: {str(e)}")
        except Exception as e:
            raise Exception(f"Error calling custom LLM: {str(e)}")

    def _generate(
        self,
        prompts: List[str],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> LLMResult:
        """
        Generate responses for multiple prompts.

        Args:
            prompts: List of input prompts
            stop: Optional stop sequences
            run_manager: Callback manager
            **kwargs: Additional parameters

        Returns:
            LLMResult containing generations
        """
        generations = []

        for prompt in prompts:
            text = self._call(prompt, stop=stop, run_manager=run_manager, **kwargs)
            generations.append([Generation(text=text)])

        return LLMResult(generations=generations)

    async def _agenerate(
        self,
        prompts: List[str],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> LLMResult:
        """
        Async version of generate for multiple prompts.
        """
        headers = {
            "Content-Type": "application/json"
        }

        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        generations = []

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            for prompt in prompts:
                payload = {
                    "prompt": prompt,
                    "temperature": kwargs.get("temperature", self.temperature),
                    "max_tokens": kwargs.get("max_tokens", self.max_tokens),
                    "model": self.model_name
                }

                if stop:
                    payload["stop"] = stop

                try:
                    response = await client.post(
                        self.api_endpoint,
                        headers=headers,
                        json=payload
                    )
                    response.raise_for_status()

                    result = response.json()
                    generated_text = result.get("text") or result.get("response") or result.get("output", "")

                    generations.append([Generation(text=generated_text)])

                except httpx.HTTPError as e:
                    raise Exception(f"Custom LLM API error: {str(e)}")

        return LLMResult(generations=generations)

    def _stream(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[GenerationChunk]:
        """
        Stream response from custom LLM API (if supported).
        Falls back to non-streaming if not available.
        """
        text = self._call(prompt, stop=stop, run_manager=run_manager, **kwargs)
        yield GenerationChunk(text=text)


def get_custom_llm(
    api_endpoint: str,
    api_key: Optional[str] = None,
    model_name: str = "custom-model",
    temperature: float = 0.7,
    max_tokens: int = 4096
) -> CustomLLM:
    """
    Factory function to create a CustomLLM instance.

    Args:
        api_endpoint: URL endpoint for the custom LLM API
        api_key: Optional API key for authentication
        model_name: Model identifier
        temperature: Sampling temperature (0.0 to 1.0)
        max_tokens: Maximum tokens to generate

    Returns:
        Configured CustomLLM instance
    """
    return CustomLLM(
        api_endpoint=api_endpoint,
        api_key=api_key,
        model_name=model_name,
        temperature=temperature,
        max_tokens=max_tokens
    )

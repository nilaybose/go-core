# RAG Chatbot Backend

Python FastAPI backend for the RAG Chatbot application with PostgreSQL + pgvector.

## Setup

### 1. Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Environment Variables

Create a `.env` file in the backend directory with the following:

```
PGVECTOR_CONNECTION_STRING=postgresql://user:password@localhost:5432/dbname
GEMINI_API_KEY=your_gemini_api_key
CUSTOM_LLM_ENDPOINT=your_custom_llm_endpoint (optional)
CUSTOM_LLM_API_KEY=your_custom_llm_key (optional)
CUSTOM_LLM_MODEL_NAME=your_model_name (optional)
```

**Required Credentials:**
- PostgreSQL connection string with pgvector extension enabled
- Get Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)

### 3. Initialize PostgreSQL Database

Run the SQL migration to create all required tables and indexes:

```bash
psql $PGVECTOR_CONNECTION_STRING -f migrations/init_pgvector.sql
```

The migration will:
- Enable pgvector extension
- Create all required tables (docs_vector, chat_history, contents, sys_prompts, spec_mappings)
- Create HNSW index on vector embeddings for fast similarity search
- Create indexes on all foreign keys and frequently queried columns

## Run the Server

```bash
cd backend
python main.py
```

The API will be available at `http://localhost:8000`

## API Endpoints

### Chat Endpoints
- `POST /chat/new` - Create a new chat session
- `POST /chat` - Send a message and get RAG response
- `GET /chat/{chat_id}/history` - Get chat history for a session
- `GET /chat/sessions` - List all chat sessions

### Document Management
- `POST /upload` - Upload a PDF document (returns immediately with UUID and processing status)
- `GET /content/{content_uuid}/status` - Get status of uploaded content
- `GET /contents` - List all uploaded contents with optional filtering
- `DELETE /content/{content_uuid}` - Delete content and all associated embeddings

### System Prompts
- `POST /system-prompts` - Create a new system prompt
- `GET /system-prompts` - List all system prompts
- `GET /system-prompts/{prompt_uuid}` - Get a specific system prompt
- `PUT /system-prompts/{prompt_uuid}` - Update a system prompt
- `DELETE /system-prompts/{prompt_uuid}` - Delete a system prompt

### Spec Mapping Management (New)
- `GET /mappings` - List all saved spec mappings with pagination
- `GET /mappings/chat/{chat_id}` - Get mapping for a specific chat session
- `GET /mappings/{file_id}` - Get mapping by file ID
- `GET /mappings/{file_id}/download` - Get fresh signed download URL
- `DELETE /mappings/{file_id}` - Delete mapping from database and storage

### Utility
- `GET /download/{filename}` - Download temporary generated files

## Architecture

### Components

1. **ai_model.py** - Abstract AI model wrapper class
   - `embed(text)` - Generate embeddings for text
   - `embed_batch(texts)` - Batch embedding generation
   - `chat(messages, context)` - Generate chat responses with context
   - Includes GeminiModel (fully implemented) and OpenAIModel template

2. **pg_client.py** - PostgreSQL + pgvector wrapper
   - Database connection management
   - Vector operations (insert, search with HNSW index)
   - Table management (docs_vector, chat_history, contents, sys_prompts, spec_mappings)
   - All CRUD operations with proper PostgreSQL transactions

3. **normalized_json_generator.py** - JSON mapping generator
   - Generate normalized JSON format for file specifications
   - Validate JSON mappings for completeness
   - Calculate field counts and statistics
   - Format JSON with proper indentation

4. **spec_parser_agent.py** - LangGraph-based spec parsing agent
   - Intelligent workflow for parsing file specifications
   - Multi-step extraction (header, detail, trailer fields)
   - User confirmation workflow before saving to database
   - JSON mapping generation from extracted fields
   - Saves to PostgreSQL database

5. **document_processor.py** - PDF processing pipeline
   - Text extraction from PDFs
   - Text chunking with overlap
   - Async batch embedding and storage

6. **main.py** - FastAPI application
   - Chat endpoints with RAG
   - Document upload with background processing
   - Spec-Parser agent integration
   - Mapping management endpoints
   - CORS configuration

## Implementation Notes

### AI Model Integration

The `ai_model.py` file contains:

1. **GeminiModel** - Fully implemented Google Gemini integration (default)
   - Uses `models/embedding-001` for embeddings (768 dimensions)
   - Uses `gemini-pro` for chat completions
   - Embeddings configured for retrieval tasks

2. **OpenAIModel** - Template implementation for OpenAI
   - Can be implemented if you prefer OpenAI over Gemini

### RAG Pipeline

1. User sends a message
2. Message is embedded using AI model
3. PostgreSQL searches for similar document chunks using pgvector
4. Top results are formatted as context
5. Context + chat history sent to AI model
6. Response saved to chat_history table
7. Response returned with sources

### Document Processing

**Upload Flow:**
1. User uploads PDF via multipart form with optional metadata JSON
2. Backend immediately saves PDF to `contents` table with status "processing"
3. Returns response with content UUID and status to user
4. Background async task starts:
   - Extracts text from PDF pages
   - Chunks text with overlap
   - Generates embeddings for all chunks
   - Stores vectors in `docs_vector` table with content UUID
   - Updates content status to "completed" (or "failed" on error)

**Status Tracking:**
- User receives immediate confirmation with UUID
- Can query `/content/{uuid}/status` to check processing status
- All vectors linked to original content via content_uuid

### Spec-Parser Agent Workflow

**Multi-Step Workflow:**
1. Check transaction layout is specified
2. Retrieve full document from database
3. Discover file structure (header, detail, trailer)
4. Extract header fields using RAG
5. Extract detail fields using RAG
6. Extract trailer fields using RAG
7. Generate normalized JSON mapping
8. **Ask user for confirmation to save**
9. If confirmed: Save to database
10. Generate download identifier

**User Confirmation:**
- After JSON generation, agent asks: "Would you like to save this mapping permanently?"
- User responds with "yes" or "no"
- If "yes": Mapping saved with UPSERT on chat_id (overwrites previous mapping for same chat)
- If "no": Workflow ends, temporary download link provided
- One mapping per chat_id (UNIQUE constraint)

### Database Tables

The system uses five PostgreSQL tables:

1. **docs_vector** - Document vectors (ONLY table with vector embeddings)
   - `embedding` - vector(768) - 768-dimensional embeddings
   - `text` - TEXT - Chunk text content
   - `filename` - TEXT - Source filename
   - `page_number` - INTEGER - PDF page number
   - `metadata` - JSONB - Additional metadata
   - `content_uuid` - UUID - Reference to contents table
   - Index: HNSW with cosine distance for fast similarity search

2. **chat_history** - Chat conversation history (NO vectors)
   - `message_id` - UUID - Unique message identifier
   - `chat_id` - UUID - Chat session identifier
   - `user_query` - TEXT - User's question
   - `model_response` - TEXT - AI's response
   - `agent` - TEXT - Agent type (RAG, Analytics, Spec-Parser)
   - `spec_id` - UUID - Reference to specification document
   - `timestamp` - BIGINT - Unix timestamp in milliseconds

3. **contents** - Uploaded file storage (NO vectors)
   - `content_uuid` - UUID - Unique content identifier
   - `filename` - TEXT - Original filename
   - `base64_content` - TEXT - Base64-encoded PDF file
   - `status` - TEXT - Processing status (processing, completed, failed)
   - `created_at` - TIMESTAMPTZ - Creation timestamp

4. **sys_prompts** - System prompts (NO vectors)
   - `prompt_uuid` - UUID - Unique prompt identifier
   - `name` - TEXT - Prompt name
   - `prompt_text` - TEXT - Full prompt text
   - `created_at` - TIMESTAMPTZ - Creation timestamp

5. **spec_mappings** - File specification mappings (NO vectors)
   - `file_id` - UUID - Primary key
   - `chat_id` - UUID - UNIQUE - One mapping per chat
   - `spec_id` - UUID - Reference to specification document
   - `transaction_layout` - TEXT - Layout name
   - `filename` - TEXT - JSON filename
   - `json_content` - JSONB - Complete mapping for querying
   - `file_size` - INTEGER - Size in bytes
   - `storage_path` - TEXT - Storage path identifier
   - `created_at` - TIMESTAMPTZ - Creation timestamp
   - `updated_at` - TIMESTAMPTZ - Last update timestamp
   - `metadata` - JSONB - Additional metadata (field counts, confidence)

### Vector Indexing

The system uses HNSW (Hierarchical Navigable Small World) index for vector similarity search:

- **Index Type**: HNSW (pgvector)
- **Metric**: Cosine distance (vector_cosine_ops)
- **Parameters**:
  - m=16: Maximum number of connections per layer
  - ef_construction=64: Size of dynamic candidate list during construction
  - ef_search: Configurable at query time

HNSW provides excellent query performance with high recall rates, making it ideal for production RAG systems.

### JSON Mapping Format

Normalized JSON format for file specifications:

```json
{
  "layout_name": "Payment Transaction",
  "file_format": "fixed-length",
  "version": "1.0",
  "created_at": "2024-01-15T10:30:00Z",
  "metadata": {
    "spec_id": "uuid",
    "chat_id": "uuid",
    "confidence_score": 0.85
  },
  "records": [
    {
      "record_type": "header",
      "identifier": {"value": "HDR", "position": 1, "length": 3},
      "fields": [
        {
          "name": "record_type",
          "position": 1,
          "length": 3,
          "type": "string",
          "required": true
        }
      ]
    }
  ]
}
```

## Troubleshooting

### Common Issues

1. **pgvector extension not found**
   - Run the init_pgvector.sql migration
   - Verify: `SELECT * FROM pg_extension WHERE extname = 'vector';`

2. **Connection refused to PostgreSQL**
   - Check PGVECTOR_CONNECTION_STRING in .env
   - Verify network connectivity to PostgreSQL server

3. **Vector search returns no results**
   - Check that documents have been processed (status = 'completed')
   - Verify embeddings exist: `SELECT COUNT(*) FROM docs_vector;`

4. **Spec-Parser agent not available**
   - Set CUSTOM_LLM_ENDPOINT in .env
   - Agent requires a custom LLM endpoint for analysis

## Performance Tips

1. **Vector Search Optimization**
   - Tune HNSW parameters (m, ef_construction) for your data size
   - Use appropriate ef_search values at query time
   - Consider creating partial indexes for frequently queried subsets

2. **Connection Pooling**
   - psycopg2 uses connection pooling automatically
   - Adjust pool size in pg_client.py if needed

3. **JSONB Queries**
   - Use GIN indexes for complex JSONB queries
   - Query specific JSON paths for better performance

4. **Batch Operations**
   - Use batch embedding generation for multiple documents
   - Batch insert vectors for better throughput

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
import json

from config.settings import settings
from db.pg_client import PgClient
from ai.ai_model import get_ai_model
from db.document_processor import process_document_async
from ai.custom_llm_wrapper import get_custom_llm
from spec_parser_agent import SpecParserAgent

app = FastAPI(title="RAG Chatbot API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize clients
pg_client = PgClient()
ai_model = get_ai_model("gemini", api_key=settings.gemini_api_key)

custom_llm = None
spec_parser_agent = None

if settings.custom_llm_endpoint:
    custom_llm = get_custom_llm(
        api_endpoint=settings.custom_llm_endpoint,
        api_key=settings.custom_llm_api_key,
        model_name=settings.custom_llm_model_name
    )
    spec_parser_agent = SpecParserAgent(llm=custom_llm, pg_client=pg_client)


# Request/Response Models
class ChatRequest(BaseModel):
    chat_id: str
    message: str
    system_prompt_uuid: Optional[str] = None
    agent: str = "RAG"
    spec_id: Optional[str] = None


class Chart(BaseModel):
    chart: Dict[str, Any]
    title: Dict[str, str]
    xAxis: Optional[Dict[str, Any]] = None
    yAxis: Optional[Dict[str, Any]] = None
    series: List[Dict[str, Any]]
    plotOptions: Optional[Dict[str, Any]] = None
    legend: Optional[Dict[str, Any]] = None
    tooltip: Optional[Dict[str, Any]] = None


class Attachment(BaseModel):
    filename: str
    url: str


class ChatResponse(BaseModel):
    chat_id: str
    response: str
    sources: list[Dict[str, Any]]
    charts: List[Dict[str, Any]] = Field(default_factory=list)
    attachments: List[Dict[str, str]] = Field(default_factory=list)


class NewChatResponse(BaseModel):
    chat_id: str


class UploadResponse(BaseModel):
    success: bool
    message: str
    filename: str
    content_uuid: str
    status: str


class SystemPromptRequest(BaseModel):
    name: str
    prompt_text: str


class SystemPromptResponse(BaseModel):
    prompt_uuid: str
    name: str
    prompt_text: str
    created_at: int


class ReconSpecRequest(BaseModel):
    name: str
    json_content: Dict[str, Any]


class ReconSpecResponse(BaseModel):
    id: str
    name: str
    json_content: Dict[str, Any]
    created_at: int
    updated_at: int


class AutoMapperRequest(BaseModel):
    spec_mapper_uuid: str
    recon_mapper_uuid: str
    mapping_json: Dict[str, Any]


class AutoMapperResponse(BaseModel):
    mapper_uuid: str
    spec_mapper_uuid: str
    recon_mapper_uuid: str
    mapping_json: Dict[str, Any]
    created_at: int
    updated_at: int


# Startup/Shutdown Events
@app.on_event("startup")
async def startup_event():
    """Initialize PostgreSQL connection and tables on startup"""
    pg_client.connect()
    pg_client.enable_pgvector()
    pg_client.create_tables()
    pg_client.create_indexes()


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    pg_client.disconnect()


# API Endpoints
@app.get("/")
async def root():
    return {"message": "RAG Chatbot API is running"}


@app.post("/chat/new", response_model=NewChatResponse)
async def create_new_chat():
    """
    Create a new chat session and return a unique chat ID.
    """
    chat_id = pg_client.generate_chat_id()
    return NewChatResponse(chat_id=chat_id)


@app.post("/chat", response_model=ChatResponse, response_model_exclude_unset=False)
async def chat(request: ChatRequest):
    """
    Handle chat request with RAG, Analytics, or Spec-Parser agent.

    1. Embed the user query
    2. Search pgvector for relevant context
    3. Generate response using AI model with context
    4. Save to chat history
    5. Return response with sources

    Example Analytics Response with Multiple Highcharts:
    {
        "text": "## Sales Analysis\n\nHere's the breakdown of sales by region and monthly trends:",
        "charts": [
            {
                "chart": {"type": "pie"},
                "title": {"text": "Sales Distribution by Region"},
                "series": [{
                    "name": "Sales",
                    "data": [
                        {"name": "North", "y": 45.5},
                        {"name": "South", "y": 28.3},
                        {"name": "East", "y": 16.2},
                        {"name": "West", "y": 10.0}
                    ]
                }]
            },
            {
                "chart": {"type": "column"},
                "title": {"text": "Monthly Revenue"},
                "xAxis": {"categories": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]},
                "series": [{
                    "name": "Revenue",
                    "data": [29.9, 71.5, 106.4, 129.2, 144.0, 176.0]
                }]
            }
        ],
        "attachments": [
            {"filename": "report.pdf", "url": "https://example.com/files/report.pdf"},
            {"filename": "data.xlsx", "url": "https://example.com/files/data.xlsx"}
        ]
    }
    """
    try:
        if request.agent == "Spec-Parser":
            if not spec_parser_agent:
                raise HTTPException(
                    status_code=400,
                    detail="Spec-Parser agent not configured. Please set CUSTOM_LLM_ENDPOINT in .env"
                )

            if not request.spec_id:
                return ChatResponse(
                    chat_id=request.chat_id,
                    response="Please select a specification document from the dropdown to begin parsing.",
                    sources=[],
                    charts=[],
                    attachments=[]
                )

            chat_history = pg_client.get_chat_history(request.chat_id)
            last_message = chat_history[-1] if chat_history else None

            transaction_layout = None
            if last_message and last_message.get("agent") == "Spec-Parser":
                try:
                    last_response = json.loads(last_message.get("model_response", "{}"))
                    if "transaction_layout" in last_response:
                        transaction_layout = last_response.get("transaction_layout")
                except:
                    pass

            if not transaction_layout:
                message_lower = request.message.lower()
                if any(word in message_lower for word in ["parse", "extract", "layout", "transaction"]):
                    transaction_layout = request.message.strip()

            result = await spec_parser_agent.run(
                chat_id=request.chat_id,
                spec_id=request.spec_id,
                transaction_layout=transaction_layout
            )

            response_text = "\n\n".join([msg["content"] for msg in result.get("messages", []) if msg["role"] == "assistant"])

            attachments = []
            if result.get("generated_json"):
                import tempfile
                import os

                if result.get("save_status") == "saved" and result.get("storage_path"):
                    download_url = pg_client.get_signed_download_url(
                        result.get("storage_path"),
                        expires_in=3600
                    )
                    json_filename = f"spec_mapping_{request.chat_id[:8]}.json"
                    attachments.append({
                        "filename": json_filename,
                        "url": download_url,
                        "file_id": result.get("file_id")
                    })
                else:
                    temp_dir = tempfile.gettempdir()
                    json_filename = f"spec_mapping_{request.chat_id[:8]}.json"
                    json_path = os.path.join(temp_dir, json_filename)

                    with open(json_path, 'w') as f:
                        f.write(result.get("generated_json"))

                    attachments.append({
                        "filename": json_filename,
                        "url": f"/download/{json_filename}"
                    })

            full_response_for_history = {
                "text": response_text,
                "transaction_layout": transaction_layout,
                "workflow_stage": result.get("workflow_stage"),
                "attachments": attachments
            }

            pg_client.save_chat_message(
                chat_id=request.chat_id,
                user_query=request.message,
                model_response=json.dumps(full_response_for_history),
                agent=request.agent,
                spec_id=request.spec_id or ""
            )

            return ChatResponse(
                chat_id=request.chat_id,
                response=response_text,
                sources=[],
                charts=[],
                attachments=attachments
            )
        # Embed the user query
        query_embedding = await ai_model.embed(request.message)

        # Search for relevant context
        search_results = pg_client.vector_search(query_embedding, top_k=5)

        # Prepare context from search results
        context = "\n\n".join([
            f"Source: {result['filename']} (Page {result['page_number']})\n{result['text']}"
            for result in search_results
        ])

        # Get chat history for context
        chat_history = pg_client.get_chat_history(request.chat_id)
        messages = []

        # Add system prompt if provided
        if request.system_prompt_uuid:
            system_prompt_data = pg_client.get_system_prompt(request.system_prompt_uuid)
            if system_prompt_data:
                messages.append({"role": "system", "content": system_prompt_data["prompt_text"]})

        # Add previous messages to context (last 5 exchanges)
        for msg in chat_history[-10:]:
            messages.append({"role": "user", "content": msg["user_query"]})
            messages.append({"role": "assistant", "content": msg["model_response"]})

        # Add current message
        messages.append({"role": "user", "content": request.message})

        # Create complete dummy response with all fields populated
        dummy_sources = [
            {
                "filename": "product_specifications.pdf",
                "page_number": 15,
                "text_preview": "The system architecture is designed to handle high-volume transactions with a distributed microservices approach. Each service is independently scalable and communicates via REST APIs..."
            },
            {
                "filename": "technical_requirements.pdf",
                "page_number": 8,
                "text_preview": "Performance metrics indicate that the application must support at least 10,000 concurrent users with response times under 200ms for 95% of requests. Database optimization is critical..."
            },
            {
                "filename": "user_manual.pdf",
                "page_number": 42,
                "text_preview": "Authentication follows OAuth 2.0 standards with JWT tokens. Session management includes automatic refresh mechanisms and secure token storage. Multi-factor authentication is supported..."
            }
        ]

        dummy_charts = [
            {
                "chart": {"type": "pie"},
                "title": {"text": "Sales Distribution by Region"},
                "tooltip": {
                    "pointFormat": "{series.name}: <b>{point.percentage:.1f}%</b>"
                },
                "plotOptions": {
                    "pie": {
                        "allowPointSelect": True,
                        "cursor": "pointer",
                        "dataLabels": {
                            "enabled": True,
                            "format": "<b>{point.name}</b>: {point.percentage:.1f} %"
                        }
                    }
                },
                "series": [{
                    "name": "Sales",
                    "colorByPoint": True,
                    "data": [
                        {"name": "North America", "y": 45.5},
                        {"name": "Europe", "y": 28.3},
                        {"name": "Asia Pacific", "y": 16.2},
                        {"name": "Latin America", "y": 10.0}
                    ]
                }]
            },
            {
                "chart": {"type": "column"},
                "title": {"text": "Monthly Revenue Trend"},
                "xAxis": {
                    "categories": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"],
                    "crosshair": True
                },
                "yAxis": {
                    "min": 0,
                    "title": {
                        "text": "Revenue ($1000s)"
                    }
                },
                "tooltip": {
                    "headerFormat": "<span style='font-size:10px'>{point.key}</span><table>",
                    "pointFormat": "<tr><td style='color:{series.color};padding:0'>{series.name}: </td><td style='padding:0'><b>${point.y:.1f}k</b></td></tr>",
                    "footerFormat": "</table>",
                    "shared": True,
                    "useHTML": True
                },
                "plotOptions": {
                    "column": {
                        "pointPadding": 0.2,
                        "borderWidth": 0
                    }
                },
                "series": [
                    {
                        "name": "2024",
                        "data": [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5]
                    },
                    {
                        "name": "2023",
                        "data": [38.4, 52.3, 86.2, 98.7, 115.3, 142.8, 120.4, 130.2]
                    }
                ]
            }
        ]

        dummy_attachments = [
            {"filename": "sales_report_q3.pdf", "url": "https://example.com/files/sales_report_q3.pdf"},
            {"filename": "revenue_data.xlsx", "url": "https://example.com/files/revenue_data.xlsx"},
            {"filename": "market_analysis.docx", "url": "https://example.com/files/market_analysis.docx"}
        ]

        # Generate dummy response text with markdown formatting
        dummy_response_text = """## Analysis Results

Based on the analysis of your query, here are the key findings:

### Executive Summary
The data indicates strong performance across all regions with North America leading at 45.5% of total sales. Revenue trends show consistent growth year-over-year, with 2024 outperforming 2023 by an average of 18.3%.

### Key Insights

1. **Regional Performance**
- North America continues to dominate with 45.5% market share
- Europe shows steady growth at 28.3%
- Asia Pacific represents emerging opportunities at 16.2%
- Latin America has potential for expansion at 10.0%

2. **Revenue Trends**
- Q2 2024 shows exceptional growth (176.0k in June)
- Seasonal patterns indicate strong mid-year performance
- Year-over-year comparison reveals 15-20% growth across most months

3. **Strategic Recommendations**
- Maintain investment in North American operations
- Explore expansion opportunities in Asia Pacific
- Develop targeted campaigns for Latin American markets
- Continue monitoring monthly trends for early indicators

### Supporting Documentation
Please refer to the attached reports and source documents for detailed analysis and raw data.

**Note:** All metrics are based on the latest available data and have been validated against multiple sources."""

        # Create full response structure for saving to history
        full_response_for_history = {
            "text": dummy_response_text,
            "charts": dummy_charts,
            "attachments": dummy_attachments
        }

        # Save complete response to chat history as JSON
        pg_client.save_chat_message(
            chat_id=request.chat_id,
            user_query=request.message,
            model_response=json.dumps(full_response_for_history),
            agent=request.agent,
            spec_id=request.spec_id or ""
        )

        response_obj = ChatResponse(
            chat_id=request.chat_id,
            response=dummy_response_text,
            sources=dummy_sources,
            charts=dummy_charts,
            attachments=dummy_attachments
        )

        print("=" * 80)
        print("BACKEND RESPONSE OBJECT:")
        print(f"Charts length: {len(response_obj.charts) if response_obj.charts else 'None'}")
        print(f"Attachments length: {len(response_obj.attachments) if response_obj.attachments else 'None'}")
        print(f"Charts type: {type(response_obj.charts)}")
        print(f"First chart: {response_obj.charts[0] if response_obj.charts else 'Empty'}")
        print("=" * 80)

        # Convert to dict and return as JSON to ensure all fields are included
        response_dict = response_obj.model_dump()
        print("Response dict keys:", response_dict.keys())
        print("Charts in dict:", "charts" in response_dict and len(response_dict.get("charts", [])))
        print("Attachments in dict:", "attachments" in response_dict and len(response_dict.get("attachments", [])))

        return JSONResponse(content=response_dict)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/upload", response_model=UploadResponse)
async def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    metadata: str = Form("{}")
):
    """
    Upload and process a PDF document.

    Flow:
    1. Validate and read file
    2. Save to contents collection with 'processing' status
    3. Return immediately with UUID and status
    4. Process in background (chunk, embed, store vectors)
    5. Update status to 'completed' when done

    Args:
        file: PDF file to upload
        metadata: JSON string with metadata key-value pairs
    """
    try:
        if not file.filename.endswith('.pdf'):
            raise HTTPException(status_code=400, detail="Only PDF files are supported")

        try:
            metadata_dict = json.loads(metadata)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON metadata")

        file_content = await file.read()

        content_uuid = pg_client.save_content(file.filename, file_content)

        background_tasks.add_task(
            process_document_async,
            file_content=file_content,
            filename=file.filename,
            metadata=metadata_dict,
            content_uuid=content_uuid,
            ai_model=ai_model,
            pg_client=pg_client
        )

        return UploadResponse(
            success=True,
            message=f"File uploaded successfully. Processing started.",
            filename=file.filename,
            content_uuid=content_uuid,
            status="processing"
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/chat/{chat_id}/history")
async def get_history(chat_id: str):
    """
    Retrieve chat history for a specific chat session.
    Returns array of all user queries and model responses with their structure
    (markdown text, charts array, and attachments).
    """
    try:
        history = pg_client.get_chat_history(chat_id)

        messages = []
        for msg in history:
            response_content = msg["model_response"]

            try:
                response_json = json.loads(response_content)
                if isinstance(response_json, dict):
                    messages.append({
                        "role": "user",
                        "content": msg["user_query"],
                        "timestamp": msg["timestamp"]
                    })
                    messages.append({
                        "role": "assistant",
                        "content": response_json.get("text", response_content),
                        "charts": response_json.get("charts", []),
                        "attachments": response_json.get("attachments"),
                        "timestamp": msg["timestamp"]
                    })
                else:
                    messages.append({
                        "role": "user",
                        "content": msg["user_query"],
                        "timestamp": msg["timestamp"]
                    })
                    messages.append({
                        "role": "assistant",
                        "content": response_content,
                        "timestamp": msg["timestamp"]
                    })
            except json.JSONDecodeError:
                messages.append({
                    "role": "user",
                    "content": msg["user_query"],
                    "timestamp": msg["timestamp"]
                })
                messages.append({
                    "role": "assistant",
                    "content": response_content,
                    "timestamp": msg["timestamp"]
                })

        return {"chat_id": chat_id, "messages": messages}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/chat/sessions")
async def get_chat_sessions(limit: int = 10):
    """
    Retrieve list of chat sessions with their names and timestamps.
    Returns latest 10 sessions by default.
    """
    try:
        sessions = pg_client.get_all_chat_sessions(limit=limit)
        return {"sessions": sessions, "total": len(sessions)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/content/{content_uuid}/status")
async def get_content_status(content_uuid: str):
    """
    Get the status of an uploaded content by UUID.
    """
    try:
        content = pg_client.get_content_by_uuid(content_uuid)
        if not content:
            raise HTTPException(status_code=404, detail="Content not found")
        return content
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/contents")
async def list_contents(status: Optional[str] = None, search: Optional[str] = None):
    """
    List all contents with optional filtering.

    Query parameters:
    - status: Filter by status (processing, completed, failed, all)
    - search: Search by filename
    """
    try:
        contents = pg_client.list_contents(status_filter=status, search_query=search)
        return {"contents": contents, "total": len(contents)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/content/{content_uuid}")
async def delete_content(content_uuid: str):
    """
    Delete content and all associated embeddings.

    This will:
    1. Delete all embeddings from docs_vector collection
    2. Delete the content record from contents collection
    """
    try:
        success = pg_client.delete_content(content_uuid)
        if not success:
            raise HTTPException(status_code=404, detail="Content not found or deletion failed")
        return {"success": True, "message": "Content deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/system-prompts")
async def create_system_prompt(request: SystemPromptRequest):
    """
    Create a new system prompt.
    """
    try:
        prompt_uuid = pg_client.create_system_prompt(request.name, request.prompt_text)
        return {"success": True, "prompt_uuid": prompt_uuid, "message": "System prompt created successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/system-prompts")
async def list_system_prompts(search: Optional[str] = None):
    """
    List all system prompts with optional search.

    Query parameters:
    - search: Search by name
    """
    try:
        prompts = pg_client.list_system_prompts(search_query=search)
        return {"prompts": prompts, "total": len(prompts)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/system-prompts/{prompt_uuid}")
async def get_system_prompt(prompt_uuid: str):
    """
    Get a system prompt by UUID.
    """
    try:
        prompt = pg_client.get_system_prompt(prompt_uuid)
        if not prompt:
            raise HTTPException(status_code=404, detail="System prompt not found")
        return prompt
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/system-prompts/{prompt_uuid}")
async def update_system_prompt(prompt_uuid: str, request: SystemPromptRequest):
    """
    Update a system prompt by UUID.
    """
    try:
        success = pg_client.update_system_prompt(prompt_uuid, request.name, request.prompt_text)
        if not success:
            raise HTTPException(status_code=404, detail="System prompt not found or update failed")
        return {"success": True, "message": "System prompt updated successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/system-prompts/{prompt_uuid}")
async def delete_system_prompt(prompt_uuid: str):
    """
    Delete a system prompt.
    """
    try:
        success = pg_client.delete_system_prompt(prompt_uuid)
        if not success:
            raise HTTPException(status_code=404, detail="System prompt not found or deletion failed")
        return {"success": True, "message": "System prompt deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/recon-specs")
async def create_recon_spec(request: ReconSpecRequest):
    """
    Create a new recon spec with JSON schema.
    """
    try:
        spec_id = pg_client.create_recon_spec(
            request.name, request.json_content
        )
        return {"success": True, "spec_id": spec_id, "message": "Recon spec created successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/recon-specs")
async def list_recon_specs(search: Optional[str] = None):
    """
    List all recon specs with optional search.

    Query parameters:
    - search: Search by name
    """
    try:
        specs = pg_client.list_recon_specs(search_query=search)
        return {"specs": specs, "total": len(specs)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/recon-specs/{spec_id}")
async def get_recon_spec(spec_id: str):
    """
    Get a recon spec by ID.
    """
    try:
        spec = pg_client.get_recon_spec(spec_id)
        if not spec:
            raise HTTPException(status_code=404, detail="Recon spec not found")
        return spec
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/recon-specs/{spec_id}")
async def update_recon_spec(spec_id: str, request: ReconSpecRequest):
    """
    Update a recon spec by ID.
    """
    try:
        success = pg_client.update_recon_spec(
            spec_id, request.name, request.json_content
        )
        if not success:
            raise HTTPException(status_code=404, detail="Recon spec not found or update failed")
        return {"success": True, "message": "Recon spec updated successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/recon-specs/{spec_id}")
async def delete_recon_spec(spec_id: str):
    """
    Delete a recon spec.
    """
    try:
        success = pg_client.delete_recon_spec(spec_id)
        if not success:
            raise HTTPException(status_code=404, detail="Recon spec not found or deletion failed")
        return {"success": True, "message": "Recon spec deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/mappings")
async def list_mappings(spec_id: Optional[str] = None, search: Optional[str] = None, limit: int = 100, offset: int = 0):
    """
    List all saved spec mappings with optional filtering.

    Query parameters:
    - spec_id: Filter by specification document UUID
    - search: Search by transaction layout name
    - limit: Maximum number of results (default 100)
    - offset: Pagination offset (default 0)
    """
    try:
        mappings = pg_client.list_mappings(
            spec_id_filter=spec_id,
            search_query=search,
            limit=limit,
            offset=offset
        )
        return {"mappings": mappings, "total": len(mappings)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/mappings/chat/{chat_id}")
async def get_mapping_by_chat(chat_id: str):
    """
    Retrieve saved mapping for a specific chat session.
    Returns full mapping including JSON content and generates fresh download URL.
    """
    try:
        mapping = pg_client.get_mapping_by_chat_id(chat_id)
        if not mapping:
            raise HTTPException(status_code=404, detail="Mapping not found for this chat")

        if mapping.get("storage_path"):
            download_url = pg_client.get_signed_download_url(
                mapping["storage_path"],
                expires_in=3600
            )
            mapping["download_url"] = download_url

        return mapping
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/mappings/{file_id}")
async def get_mapping_by_id(file_id: str):
    """
    Retrieve mapping by file_id.
    Returns full mapping including JSON content and generates fresh download URL.
    """
    try:
        mapping = pg_client.get_mapping_by_file_id(file_id)
        if not mapping:
            raise HTTPException(status_code=404, detail="Mapping not found")

        if mapping.get("storage_path"):
            download_url = pg_client.get_signed_download_url(
                mapping["storage_path"],
                expires_in=3600
            )
            mapping["download_url"] = download_url

        return mapping
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/mappings/{file_id}/download")
async def get_mapping_download_url(file_id: str):
    """
    Generate fresh signed download URL for a mapping.
    URL is valid for 1 hour.
    """
    try:
        mapping = pg_client.get_mapping_by_file_id(file_id)
        if not mapping:
            raise HTTPException(status_code=404, detail="Mapping not found")

        if not mapping.get("storage_path"):
            raise HTTPException(status_code=404, detail="Storage path not found")

        download_url = pg_client.get_signed_download_url(
            mapping["storage_path"],
            expires_in=3600
        )

        return {"download_url": download_url, "expires_in": 3600}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/mappings/{file_id}")
async def delete_mapping(file_id: str):
    """
    Delete a mapping from database.
    """
    try:
        mapping = pg_client.get_mapping_by_file_id(file_id)
        if not mapping:
            raise HTTPException(status_code=404, detail="Mapping not found")

        if mapping.get("storage_path"):
            pg_client.delete_json_from_storage(mapping["storage_path"])

        success = pg_client.delete_mapping(file_id)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to delete mapping")

        return {"success": True, "message": "Mapping deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/download/{filename}")
async def download_file(filename: str):
    """
    Download temporary generated files (e.g., unsaved JSON mappings).
    """
    import tempfile
    import os

    temp_dir = tempfile.gettempdir()
    file_path = os.path.join(temp_dir, filename)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    media_type = "application/json" if filename.endswith('.json') else "application/xml"

    return FileResponse(
        path=file_path,
        filename=filename,
        media_type=media_type
    )


@app.post("/auto-mappers")
async def create_auto_mapper(request: AutoMapperRequest):
    """
    Create a new auto mapper for spec and recon mapper pair.
    """
    try:
        mapper_uuid = pg_client.create_auto_mapper(
            request.spec_mapper_uuid,
            request.recon_mapper_uuid,
            request.mapping_json
        )
        return {"success": True, "mapper_uuid": mapper_uuid, "message": "Auto mapper created successfully"}
    except Exception as e:
        error_msg = str(e)
        if "unique constraint" in error_msg.lower():
            raise HTTPException(status_code=400, detail="A mapping already exists for this spec and recon pair")
        raise HTTPException(status_code=500, detail=error_msg)


@app.get("/auto-mappers")
async def list_auto_mappers(limit: int = 100):
    """
    List all auto mappers.
    """
    try:
        mappers = pg_client.list_auto_mappers(limit=limit)
        return {"mappers": mappers, "total": len(mappers)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/auto-mappers/{mapper_uuid}")
async def get_auto_mapper(mapper_uuid: str):
    """
    Get an auto mapper by UUID.
    """
    try:
        mapper = pg_client.get_auto_mapper_by_uuid(mapper_uuid)
        if not mapper:
            raise HTTPException(status_code=404, detail="Auto mapper not found")
        return mapper
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/auto-mappers/by-pair/{spec_mapper_uuid}/{recon_mapper_uuid}")
async def get_auto_mapper_by_pair(spec_mapper_uuid: str, recon_mapper_uuid: str):
    """
    Get an auto mapper by spec and recon mapper pair.
    """
    try:
        mapper = pg_client.get_auto_mapper_by_pair(spec_mapper_uuid, recon_mapper_uuid)
        if not mapper:
            return {"mapper": None}
        return {"mapper": mapper}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/auto-mappers/{mapper_uuid}")
async def update_auto_mapper(mapper_uuid: str, mapping_json: Dict[str, Any]):
    """
    Update an auto mapper by UUID.
    """
    try:
        success = pg_client.update_auto_mapper(mapper_uuid, mapping_json)
        if not success:
            raise HTTPException(status_code=404, detail="Auto mapper not found or update failed")
        return {"success": True, "message": "Auto mapper updated successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/auto-mappers/{mapper_uuid}")
async def delete_auto_mapper(mapper_uuid: str):
    """
    Delete an auto mapper.
    """
    try:
        success = pg_client.delete_auto_mapper(mapper_uuid)
        if not success:
            raise HTTPException(status_code=404, detail="Auto mapper not found or deletion failed")
        return {"success": True, "message": "Auto mapper deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

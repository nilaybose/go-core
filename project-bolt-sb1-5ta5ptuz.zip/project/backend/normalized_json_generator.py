from typing import Dict, Any, List, Optional
from datetime import datetime
import json


class JSONMappingGenerator:
    """
    Generates normalized JSON file specification mappings.
    Provides a flexible, structured format for file layout definitions.
    """

    def __init__(self):
        self.version = "1.0"

    def generate_mapping(
        self,
        layout_name: str,
        discovered_structure: Dict[str, Any],
        header_fields: Optional[List[Dict[str, Any]]] = None,
        detail_fields: Optional[List[Dict[str, Any]]] = None,
        trailer_fields: Optional[List[Dict[str, Any]]] = None,
        spec_id: str = "",
        chat_id: str = ""
    ) -> Dict[str, Any]:
        """
        Generate a complete normalized JSON mapping.

        Args:
            layout_name: Name of the transaction layout
            discovered_structure: Discovered file structure metadata
            header_fields: List of header record fields
            detail_fields: List of detail/body record fields
            trailer_fields: List of trailer record fields
            spec_id: Content UUID of the specification
            chat_id: Chat session ID

        Returns:
            Complete JSON mapping as dictionary
        """
        mapping = {
            "layout_name": layout_name,
            "file_format": discovered_structure.get("file_format", "fixed-length"),
            "version": self.version,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "metadata": {
                "spec_id": spec_id,
                "chat_id": chat_id,
                "confidence_score": discovered_structure.get("confidence", 0.0),
                "discovery_notes": discovered_structure.get("notes", "")
            },
            "records": []
        }

        record_identifiers = discovered_structure.get("record_identifiers", {})

        if header_fields and len(header_fields) > 0:
            header_record = self._build_record(
                "header",
                header_fields,
                record_identifiers.get("header")
            )
            mapping["records"].append(header_record)

        if detail_fields and len(detail_fields) > 0:
            detail_record = self._build_record(
                "detail",
                detail_fields,
                record_identifiers.get("detail")
            )
            mapping["records"].append(detail_record)

        if trailer_fields and len(trailer_fields) > 0:
            trailer_record = self._build_record(
                "trailer",
                trailer_fields,
                record_identifiers.get("trailer")
            )
            mapping["records"].append(trailer_record)

        return mapping

    def _build_record(
        self,
        record_type: str,
        fields: List[Dict[str, Any]],
        identifier_value: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Build a record definition with fields.

        Args:
            record_type: Type of record (header, detail, trailer)
            fields: List of field definitions
            identifier_value: Record identifier value if applicable

        Returns:
            Record definition dictionary
        """
        record = {
            "record_type": record_type,
            "fields": []
        }

        if identifier_value:
            first_field = fields[0] if fields else {}
            record["identifier"] = {
                "value": identifier_value,
                "position": first_field.get("position", 1),
                "length": first_field.get("length", len(identifier_value))
            }

        for field in fields:
            normalized_field = {
                "name": field.get("name", ""),
                "position": field.get("position", 0),
                "length": field.get("length", 0),
                "type": field.get("type", "string"),
                "required": field.get("required", False)
            }

            if field.get("format"):
                normalized_field["format"] = field["format"]

            if field.get("default"):
                normalized_field["default_value"] = field["default"]

            if field.get("description"):
                normalized_field["description"] = field["description"]

            if field.get("validation"):
                normalized_field["validation"] = field["validation"]

            record["fields"].append(normalized_field)

        return record

    def validate_json_mapping(self, mapping: Dict[str, Any]) -> tuple[bool, List[str]]:
        """
        Validate a JSON mapping for completeness and correctness.

        Args:
            mapping: JSON mapping to validate

        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []

        if not mapping.get("layout_name"):
            errors.append("Missing required field: layout_name")

        if not mapping.get("file_format"):
            errors.append("Missing required field: file_format")

        if not mapping.get("records") or len(mapping["records"]) == 0:
            errors.append("No records defined in mapping")

        for idx, record in enumerate(mapping.get("records", [])):
            if not record.get("record_type"):
                errors.append(f"Record {idx}: Missing record_type")

            if not record.get("fields") or len(record["fields"]) == 0:
                errors.append(f"Record {idx}: No fields defined")

            for field_idx, field in enumerate(record.get("fields", [])):
                if not field.get("name"):
                    errors.append(f"Record {idx}, Field {field_idx}: Missing name")

                if "position" not in field:
                    errors.append(f"Record {idx}, Field {field_idx}: Missing position")

                if "length" not in field:
                    errors.append(f"Record {idx}, Field {field_idx}: Missing length")

            self._validate_field_positions(record.get("fields", []), errors, idx)

        return (len(errors) == 0, errors)

    def _validate_field_positions(self, fields: List[Dict[str, Any]], errors: List[str], record_idx: int):
        """Check for overlapping field positions"""
        positions = []
        for field in fields:
            pos = field.get("position", 0)
            length = field.get("length", 0)
            if pos > 0 and length > 0:
                positions.append((pos, pos + length - 1, field.get("name", "unknown")))

        positions.sort()
        for i in range(len(positions) - 1):
            if positions[i][1] >= positions[i + 1][0]:
                errors.append(
                    f"Record {record_idx}: Overlapping fields '{positions[i][2]}' "
                    f"and '{positions[i + 1][2]}'"
                )

    def format_json_string(self, mapping: Dict[str, Any], indent: int = 2) -> str:
        """
        Format JSON mapping as pretty-printed string.

        Args:
            mapping: JSON mapping dictionary
            indent: Number of spaces for indentation

        Returns:
            Formatted JSON string
        """
        return json.dumps(mapping, indent=indent, ensure_ascii=False)

    def calculate_field_counts(self, mapping: Dict[str, Any]) -> Dict[str, int]:
        """
        Calculate field counts by record type.

        Args:
            mapping: JSON mapping dictionary

        Returns:
            Dictionary with field counts
        """
        counts = {
            "header": 0,
            "detail": 0,
            "trailer": 0,
            "total": 0
        }

        for record in mapping.get("records", []):
            record_type = record.get("record_type", "")
            field_count = len(record.get("fields", []))

            if record_type in counts:
                counts[record_type] = field_count

            counts["total"] += field_count

        return counts

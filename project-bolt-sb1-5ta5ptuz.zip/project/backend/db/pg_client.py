import psycopg2
from psycopg2.extras import RealDictCursor, execute_values
from pgvector.psycopg2 import register_vector
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
import base64
import json
from config.settings import settings


class PgClient:
    def __init__(self):
        self.connection_string = settings.pgvector_connection_string
        self.pg_conn = None
        self.dim = 768

    def connect(self):
        """Connect to PostgreSQL with pgvector extension"""
        if not self.connection_string:
            raise ValueError("PGVECTOR_CONNECTION_STRING must be set in environment")

        self.pg_conn = psycopg2.connect(self.connection_string)
        register_vector(self.pg_conn)

    def disconnect(self):
        """Disconnect from PostgreSQL"""
        if self.pg_conn:
            self.pg_conn.close()

    def enable_pgvector(self):
        """Enable pgvector extension"""
        with self.pg_conn.cursor() as cur:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            self.pg_conn.commit()

    def create_tables(self):
        """Create all required tables"""
        with self.pg_conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS docs_vector (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    embedding vector(768) NOT NULL,
                    text TEXT NOT NULL,
                    filename TEXT,
                    page_number INTEGER,
                    metadata JSONB,
                    content_uuid UUID,
                    created_at TIMESTAMPTZ DEFAULT now()
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS chat_history (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    message_id UUID UNIQUE NOT NULL,
                    chat_id UUID NOT NULL,
                    user_query TEXT NOT NULL,
                    model_response TEXT NOT NULL,
                    agent TEXT DEFAULT 'RAG',
                    spec_id UUID,
                    timestamp BIGINT NOT NULL,
                    created_at TIMESTAMPTZ DEFAULT now()
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS contents (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    content_uuid UUID UNIQUE NOT NULL,
                    filename TEXT NOT NULL,
                    base64_content TEXT,
                    status TEXT DEFAULT 'processing',
                    created_at TIMESTAMPTZ DEFAULT now()
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS sys_prompts (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    prompt_uuid UUID UNIQUE NOT NULL,
                    name TEXT NOT NULL,
                    prompt_text TEXT NOT NULL,
                    created_at TIMESTAMPTZ DEFAULT now()
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS spec_mappings (
                    file_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    chat_id UUID UNIQUE NOT NULL,
                    spec_id UUID,
                    transaction_layout TEXT NOT NULL,
                    filename TEXT NOT NULL,
                    json_content JSONB NOT NULL,
                    file_size INTEGER,
                    storage_path TEXT,
                    created_at TIMESTAMPTZ DEFAULT now(),
                    updated_at TIMESTAMPTZ DEFAULT now(),
                    metadata JSONB
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS recon_specs (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    name TEXT NOT NULL,
                    json_content JSONB NOT NULL,
                    created_at TIMESTAMPTZ DEFAULT now(),
                    updated_at TIMESTAMPTZ DEFAULT now()
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS auto_mappers (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    mapper_uuid UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
                    spec_mapper_uuid UUID NOT NULL,
                    recon_mapper_uuid UUID NOT NULL,
                    mapping_json JSONB NOT NULL,
                    created_at TIMESTAMPTZ DEFAULT now(),
                    updated_at TIMESTAMPTZ DEFAULT now(),
                    UNIQUE(spec_mapper_uuid, recon_mapper_uuid)
                );
            """)

            self.pg_conn.commit()

    def create_indexes(self):
        """Create indexes including HNSW for vector search"""
        with self.pg_conn.cursor() as cur:
            cur.execute("""
                CREATE INDEX IF NOT EXISTS docs_vector_embedding_idx
                ON docs_vector USING hnsw (embedding vector_cosine_ops)
                WITH (m = 16, ef_construction = 64);
            """)

            cur.execute("CREATE INDEX IF NOT EXISTS docs_vector_content_uuid_idx ON docs_vector (content_uuid);")
            cur.execute("CREATE INDEX IF NOT EXISTS docs_vector_filename_idx ON docs_vector (filename);")

            cur.execute("CREATE INDEX IF NOT EXISTS chat_history_chat_id_idx ON chat_history (chat_id);")
            cur.execute("CREATE INDEX IF NOT EXISTS chat_history_timestamp_idx ON chat_history (timestamp DESC);")
            cur.execute("CREATE INDEX IF NOT EXISTS chat_history_spec_id_idx ON chat_history (spec_id);")

            cur.execute("CREATE INDEX IF NOT EXISTS contents_content_uuid_idx ON contents (content_uuid);")
            cur.execute("CREATE INDEX IF NOT EXISTS contents_status_idx ON contents (status);")
            cur.execute("CREATE INDEX IF NOT EXISTS contents_created_at_idx ON contents (created_at DESC);")

            cur.execute("CREATE INDEX IF NOT EXISTS sys_prompts_prompt_uuid_idx ON sys_prompts (prompt_uuid);")
            cur.execute("CREATE INDEX IF NOT EXISTS sys_prompts_created_at_idx ON sys_prompts (created_at DESC);")

            cur.execute("CREATE INDEX IF NOT EXISTS spec_mappings_chat_id_idx ON spec_mappings (chat_id);")
            cur.execute("CREATE INDEX IF NOT EXISTS spec_mappings_spec_id_idx ON spec_mappings (spec_id);")
            cur.execute("CREATE INDEX IF NOT EXISTS spec_mappings_updated_at_idx ON spec_mappings (updated_at DESC);")
            cur.execute("CREATE INDEX IF NOT EXISTS spec_mappings_json_content_idx ON spec_mappings USING gin (json_content);")
            cur.execute("CREATE INDEX IF NOT EXISTS spec_mappings_metadata_idx ON spec_mappings USING gin (metadata);")

            cur.execute("CREATE INDEX IF NOT EXISTS recon_specs_created_at_idx ON recon_specs (created_at DESC);")
            cur.execute("CREATE INDEX IF NOT EXISTS recon_specs_json_content_idx ON recon_specs USING gin (json_content);")

            cur.execute("CREATE INDEX IF NOT EXISTS auto_mappers_mapper_uuid_idx ON auto_mappers (mapper_uuid);")
            cur.execute("CREATE INDEX IF NOT EXISTS auto_mappers_spec_mapper_uuid_idx ON auto_mappers (spec_mapper_uuid);")
            cur.execute("CREATE INDEX IF NOT EXISTS auto_mappers_recon_mapper_uuid_idx ON auto_mappers (recon_mapper_uuid);")
            cur.execute("CREATE INDEX IF NOT EXISTS auto_mappers_mapping_json_idx ON auto_mappers USING gin (mapping_json);")

            self.pg_conn.commit()

    def insert_vectors(self, embeddings: List[List[float]], texts: List[str],
                      filenames: List[str], page_numbers: List[int],
                      metadata: List[str], content_uuids: List[str]):
        """Insert vectors and metadata into docs_vector table"""
        with self.pg_conn.cursor() as cur:
            data = []
            for i in range(len(embeddings)):
                data.append((
                    embeddings[i],
                    texts[i],
                    filenames[i],
                    page_numbers[i],
                    metadata[i],
                    content_uuids[i]
                ))

            execute_values(
                cur,
                """
                INSERT INTO docs_vector (embedding, text, filename, page_number, metadata, content_uuid)
                VALUES %s
                """,
                data,
                template="(%s, %s, %s, %s, %s::jsonb, %s::uuid)"
            )
            self.pg_conn.commit()

    def vector_search(self, query_embedding: List[float], top_k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar vectors using cosine distance"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT text, filename, page_number, metadata, content_uuid,
                       1 - (embedding <=> %s::vector) as similarity
                FROM docs_vector
                ORDER BY embedding <=> %s::vector
                LIMIT %s
            """, (query_embedding, query_embedding, top_k))

            results = cur.fetchall()
            return [dict(row) for row in results]

    def search_by_content_uuid(self, query_embedding: List[float], content_uuid: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar vectors within a specific document"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT text, filename, page_number, metadata,
                       1 - (embedding <=> %s::vector) as similarity
                FROM docs_vector
                WHERE content_uuid = %s::uuid
                ORDER BY embedding <=> %s::vector
                LIMIT %s
            """, (query_embedding, content_uuid, query_embedding, top_k))

            results = cur.fetchall()
            return [dict(row) for row in results]

    def get_document_chunks_by_uuid(self, content_uuid: str) -> List[Dict[str, Any]]:
        """Retrieve all document chunks for a given content UUID"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT text, filename, page_number, metadata
                FROM docs_vector
                WHERE content_uuid = %s::uuid
                ORDER BY page_number, id
            """, (content_uuid,))

            results = cur.fetchall()
            return [dict(row) for row in results]

    def delete_vectors_by_content_uuid(self, content_uuid: str) -> bool:
        """Delete all vectors for a specific content UUID"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("DELETE FROM docs_vector WHERE content_uuid = %s::uuid", (content_uuid,))
                self.pg_conn.commit()
                return True
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error deleting vectors: {e}")
            return False

    def save_chat_message(self, chat_id: str, user_query: str, model_response: str, agent: str = "RAG", spec_id: str = "") -> Dict[str, Any]:
        """Save a chat message to chat history"""
        message_id = str(uuid.uuid4())
        timestamp = int(datetime.utcnow().timestamp() * 1000)

        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                INSERT INTO chat_history (message_id, chat_id, user_query, model_response, agent, spec_id, timestamp)
                VALUES (%s::uuid, %s::uuid, %s, %s, %s, %s::uuid, %s)
                RETURNING *
            """, (message_id, chat_id, user_query, model_response, agent, spec_id or None, timestamp))

            self.pg_conn.commit()
            result = cur.fetchone()
            return dict(result) if result else {}

    def get_chat_history(self, chat_id: str) -> List[Dict[str, Any]]:
        """Retrieve chat history for a specific chat session"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT message_id, chat_id, user_query, model_response, agent, spec_id, timestamp
                FROM chat_history
                WHERE chat_id = %s::uuid
                ORDER BY timestamp ASC
            """, (chat_id,))

            results = cur.fetchall()
            return [dict(row) for row in results]

    def get_all_chat_sessions(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve list of unique chat sessions"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                WITH chat_summary AS (
                    SELECT
                        chat_id,
                        MIN(user_query) as first_query,
                        MIN(timestamp) as first_timestamp,
                        MAX(timestamp) as last_timestamp
                    FROM chat_history
                    GROUP BY chat_id
                )
                SELECT
                    chat_id::text,
                    CASE
                        WHEN LENGTH(first_query) > 30
                        THEN SUBSTRING(first_query, 1, 30) || '...'
                        ELSE first_query
                    END as chat_name,
                    first_timestamp,
                    last_timestamp
                FROM chat_summary
                ORDER BY last_timestamp DESC
                LIMIT %s
            """, (limit,))

            results = cur.fetchall()
            return [dict(row) for row in results]

    def generate_chat_id(self) -> str:
        """Generate a new unique chat ID"""
        return str(uuid.uuid4())

    def save_content(self, filename: str, file_content: bytes) -> str:
        """Save file content to contents table and return UUID"""
        content_uuid = str(uuid.uuid4())
        base64_content = base64.b64encode(file_content).decode('utf-8')

        with self.pg_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO contents (content_uuid, filename, base64_content, status)
                VALUES (%s::uuid, %s, %s, 'processing')
            """, (content_uuid, filename, base64_content))

            self.pg_conn.commit()

        return content_uuid

    def update_content_status(self, content_uuid: str, status: str) -> bool:
        """Update the status of a content by UUID"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("""
                    UPDATE contents
                    SET status = %s
                    WHERE content_uuid = %s::uuid
                """, (status, content_uuid))

                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error updating content status: {e}")
            return False

    def get_content_by_uuid(self, content_uuid: str) -> Optional[Dict[str, Any]]:
        """Retrieve content by UUID"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT content_uuid::text, filename, status, created_at
                FROM contents
                WHERE content_uuid = %s::uuid
            """, (content_uuid,))

            result = cur.fetchone()
            return dict(result) if result else None

    def list_contents(self, status_filter: Optional[str] = None, search_query: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all contents with optional filtering"""
        query = "SELECT content_uuid::text, filename, status, created_at FROM contents WHERE 1=1"
        params = []

        if status_filter and status_filter != "all":
            query += " AND status = %s"
            params.append(status_filter)

        if search_query:
            query += " AND filename ILIKE %s"
            params.append(f"%{search_query}%")

        query += " ORDER BY created_at DESC LIMIT 1000"

        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            results = cur.fetchall()
            return [dict(row) for row in results]

    def delete_content(self, content_uuid: str) -> bool:
        """Delete content and all associated embeddings"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("DELETE FROM docs_vector WHERE content_uuid = %s::uuid", (content_uuid,))
                cur.execute("DELETE FROM contents WHERE content_uuid = %s::uuid", (content_uuid,))
                self.pg_conn.commit()
                return True
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error deleting content: {e}")
            return False

    def create_system_prompt(self, name: str, prompt_text: str) -> str:
        """Create a new system prompt"""
        prompt_uuid = str(uuid.uuid4())

        with self.pg_conn.cursor() as cur:
            cur.execute("""
                INSERT INTO sys_prompts (prompt_uuid, name, prompt_text)
                VALUES (%s::uuid, %s, %s)
            """, (prompt_uuid, name, prompt_text))

            self.pg_conn.commit()

        return prompt_uuid

    def list_system_prompts(self, search_query: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all system prompts with optional search"""
        query = "SELECT prompt_uuid::text, name, prompt_text, created_at FROM sys_prompts WHERE 1=1"
        params = []

        if search_query:
            query += " AND name ILIKE %s"
            params.append(f"%{search_query}%")

        query += " ORDER BY created_at DESC LIMIT 1000"

        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            results = cur.fetchall()
            return [dict(row) for row in results]

    def get_system_prompt(self, prompt_uuid: str) -> Optional[Dict[str, Any]]:
        """Get a system prompt by UUID"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT prompt_uuid::text, name, prompt_text, created_at
                FROM sys_prompts
                WHERE prompt_uuid = %s::uuid
            """, (prompt_uuid,))

            result = cur.fetchone()
            return dict(result) if result else None

    def update_system_prompt(self, prompt_uuid: str, name: str, prompt_text: str) -> bool:
        """Update a system prompt by UUID"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("""
                    UPDATE sys_prompts
                    SET name = %s, prompt_text = %s
                    WHERE prompt_uuid = %s::uuid
                """, (name, prompt_text, prompt_uuid))

                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error updating system prompt: {e}")
            return False

    def delete_system_prompt(self, prompt_uuid: str) -> bool:
        """Delete a system prompt"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("DELETE FROM sys_prompts WHERE prompt_uuid = %s::uuid", (prompt_uuid,))
                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error deleting system prompt: {e}")
            return False

    def save_mapping(self, chat_id: str, spec_id: str, transaction_layout: str,
                    filename: str, json_content: Dict[str, Any], file_size: int,
                    storage_path: str, metadata: Dict[str, Any]) -> str:
        """Save or update a mapping (UPSERT on chat_id)"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                INSERT INTO spec_mappings
                (chat_id, spec_id, transaction_layout, filename, json_content, file_size, storage_path, metadata)
                VALUES (%s::uuid, %s::uuid, %s, %s, %s::jsonb, %s, %s, %s::jsonb)
                ON CONFLICT (chat_id)
                DO UPDATE SET
                    spec_id = EXCLUDED.spec_id,
                    transaction_layout = EXCLUDED.transaction_layout,
                    filename = EXCLUDED.filename,
                    json_content = EXCLUDED.json_content,
                    file_size = EXCLUDED.file_size,
                    storage_path = EXCLUDED.storage_path,
                    metadata = EXCLUDED.metadata,
                    updated_at = now()
                RETURNING file_id::text
            """, (chat_id, spec_id or None, transaction_layout, filename,
                  json.dumps(json_content), file_size, storage_path, json.dumps(metadata)))

            self.pg_conn.commit()
            result = cur.fetchone()
            return result['file_id'] if result else ""

    def get_mapping_by_chat_id(self, chat_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve mapping by chat_id"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT file_id::text, chat_id::text, spec_id::text, transaction_layout,
                       filename, json_content, file_size, storage_path,
                       created_at, updated_at, metadata
                FROM spec_mappings
                WHERE chat_id = %s::uuid
            """, (chat_id,))

            result = cur.fetchone()
            return dict(result) if result else None

    def get_mapping_by_file_id(self, file_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve mapping by file_id"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT file_id::text, chat_id::text, spec_id::text, transaction_layout,
                       filename, json_content, file_size, storage_path,
                       created_at, updated_at, metadata
                FROM spec_mappings
                WHERE file_id = %s::uuid
            """, (file_id,))

            result = cur.fetchone()
            return dict(result) if result else None

    def list_mappings(self, spec_id_filter: Optional[str] = None,
                     search_query: Optional[str] = None,
                     limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all mappings with optional filtering"""
        query = """
            SELECT file_id::text, chat_id::text, spec_id::text, transaction_layout,
                   filename, file_size, created_at, updated_at
            FROM spec_mappings
            WHERE 1=1
        """
        params = []

        if spec_id_filter:
            query += " AND spec_id = %s::uuid"
            params.append(spec_id_filter)

        if search_query:
            query += " AND transaction_layout ILIKE %s"
            params.append(f"%{search_query}%")

        query += " ORDER BY updated_at DESC LIMIT %s OFFSET %s"
        params.extend([limit, offset])

        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            results = cur.fetchall()
            return [dict(row) for row in results]

    def delete_mapping(self, file_id: str) -> bool:
        """Delete a mapping by file_id"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("DELETE FROM spec_mappings WHERE file_id = %s::uuid", (file_id,))
                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error deleting mapping: {e}")
            return False

    def upload_json_to_storage(self, chat_id: str, json_content: str, filename: str) -> str:
        """Store JSON content path (no external storage)"""
        path = f"{chat_id}/{filename}"
        return path

    def get_signed_download_url(self, storage_path: str, expires_in: int = 3600) -> str:
        """Return storage path as download identifier"""
        return storage_path

    def delete_json_from_storage(self, storage_path: str) -> bool:
        """No-op for storage deletion"""
        return True

    def embedding_function(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for texts using AI model"""
        from ai.ai_model import get_ai_model

        ai_model = get_ai_model("gemini", api_key=settings.gemini_api_key)

        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        embeddings = loop.run_until_complete(ai_model.embed_batch(texts))
        loop.close()

        return embeddings

    def create_recon_spec(self, name: str, json_content: Dict[str, Any]) -> str:
        """Create a new recon spec with JSON schema"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                INSERT INTO recon_specs (name, json_content)
                VALUES (%s, %s::jsonb)
                RETURNING id::text
            """, (name, json.dumps(json_content)))

            self.pg_conn.commit()
            result = cur.fetchone()
            return result['id'] if result else ""

    def list_recon_specs(self, search_query: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all recon specs with optional search"""
        query = "SELECT id::text, name, json_content, created_at, updated_at FROM recon_specs WHERE 1=1"
        params = []

        if search_query:
            query += " AND name ILIKE %s"
            params.append(f"%{search_query}%")

        query += " ORDER BY created_at DESC LIMIT 1000"

        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            results = cur.fetchall()
            return [dict(row) for row in results]

    def get_recon_spec(self, spec_id: str) -> Optional[Dict[str, Any]]:
        """Get a recon spec by ID"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT id::text, name, json_content, created_at, updated_at
                FROM recon_specs
                WHERE id = %s::uuid
            """, (spec_id,))

            result = cur.fetchone()
            return dict(result) if result else None

    def update_recon_spec(self, spec_id: str, name: str, json_content: Dict[str, Any]) -> bool:
        """Update a recon spec by ID"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("""
                    UPDATE recon_specs
                    SET name = %s, json_content = %s::jsonb, updated_at = now()
                    WHERE id = %s::uuid
                """, (name, json.dumps(json_content), spec_id))

                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error updating recon spec: {e}")
            return False

    def delete_recon_spec(self, spec_id: str) -> bool:
        """Delete a recon spec"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("DELETE FROM recon_specs WHERE id = %s::uuid", (spec_id,))
                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error deleting recon spec: {e}")
            return False

    def create_auto_mapper(self, spec_mapper_uuid: str, recon_mapper_uuid: str, mapping_json: Dict[str, Any]) -> str:
        """Create a new auto mapper"""
        mapper_uuid = str(uuid.uuid4())
        try:
            with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    INSERT INTO auto_mappers (mapper_uuid, spec_mapper_uuid, recon_mapper_uuid, mapping_json)
                    VALUES (%s::uuid, %s::uuid, %s::uuid, %s::jsonb)
                    RETURNING mapper_uuid::text
                """, (mapper_uuid, spec_mapper_uuid, recon_mapper_uuid, json.dumps(mapping_json)))

                self.pg_conn.commit()
                result = cur.fetchone()
                return result['mapper_uuid'] if result else ""
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error creating auto mapper: {e}")
            raise e

    def get_auto_mapper_by_uuid(self, mapper_uuid: str) -> Optional[Dict[str, Any]]:
        """Get an auto mapper by UUID"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT mapper_uuid::text, spec_mapper_uuid::text, recon_mapper_uuid::text,
                       mapping_json, created_at, updated_at
                FROM auto_mappers
                WHERE mapper_uuid = %s::uuid
            """, (mapper_uuid,))

            result = cur.fetchone()
            return dict(result) if result else None

    def get_auto_mapper_by_pair(self, spec_mapper_uuid: str, recon_mapper_uuid: str) -> Optional[Dict[str, Any]]:
        """Get an auto mapper by spec and recon mapper pair"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT mapper_uuid::text, spec_mapper_uuid::text, recon_mapper_uuid::text,
                       mapping_json, created_at, updated_at
                FROM auto_mappers
                WHERE spec_mapper_uuid = %s::uuid AND recon_mapper_uuid = %s::uuid
            """, (spec_mapper_uuid, recon_mapper_uuid))

            result = cur.fetchone()
            return dict(result) if result else None

    def list_auto_mappers(self, limit: int = 100) -> List[Dict[str, Any]]:
        """List all auto mappers"""
        with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT mapper_uuid::text, spec_mapper_uuid::text, recon_mapper_uuid::text,
                       created_at, updated_at
                FROM auto_mappers
                ORDER BY created_at DESC
                LIMIT %s
            """, (limit,))

            results = cur.fetchall()
            return [dict(row) for row in results]

    def update_auto_mapper(self, mapper_uuid: str, mapping_json: Dict[str, Any]) -> bool:
        """Update an auto mapper by UUID"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("""
                    UPDATE auto_mappers
                    SET mapping_json = %s::jsonb, updated_at = now()
                    WHERE mapper_uuid = %s::uuid
                """, (json.dumps(mapping_json), mapper_uuid))

                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error updating auto mapper: {e}")
            return False

    def delete_auto_mapper(self, mapper_uuid: str) -> bool:
        """Delete an auto mapper"""
        try:
            with self.pg_conn.cursor() as cur:
                cur.execute("DELETE FROM auto_mappers WHERE mapper_uuid = %s::uuid", (mapper_uuid,))
                self.pg_conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            self.pg_conn.rollback()
            print(f"Error deleting auto mapper: {e}")
            return False

import asyncio
import json
from typing import List, Dict, Any
from pypdf import PdfReader
from io import BytesIO
from db.pg_client import PgClient
from ai.ai_model import AIModel


class DocumentProcessor:
    def __init__(self, ai_model: AIModel, pg_client: PgClient):
        self.ai_model = ai_model
        self.pg_client = pg_client
        self.chunk_size = 1000
        self.chunk_overlap = 200

    def chunk_text(self, text: str) -> List[str]:
        """
        Split text into chunks with overlap.

        Args:
            text: Input text to chunk

        Returns:
            List of text chunks
        """
        chunks = []
        start = 0

        while start < len(text):
            end = start + self.chunk_size
            chunk = text[start:end]

            if end < len(text):
                last_period = chunk.rfind('.')
                last_space = chunk.rfind(' ')

                if last_period > self.chunk_size * 0.7:
                    end = start + last_period + 1
                    chunk = text[start:end]
                elif last_space > self.chunk_size * 0.7:
                    end = start + last_space
                    chunk = text[start:end]

            chunks.append(chunk.strip())
            start = end - self.chunk_overlap

        return chunks

    async def process_pdf(
        self,
        file_content: bytes,
        filename: str,
        metadata: Dict[str, Any],
        content_uuid: str
    ) -> Dict[str, Any]:
        """
        Process PDF file: extract text, chunk, embed, and store in pgvector.

        Args:
            file_content: PDF file content as bytes
            filename: Name of the PDF file
            metadata: Additional metadata as key-value pairs
            content_uuid: UUID of the content in contents collection

        Returns:
            Dictionary with processing results
        """
        try:
            pdf_reader = PdfReader(BytesIO(file_content))
            total_pages = len(pdf_reader.pages)

            all_chunks = []
            all_filenames = []
            all_page_numbers = []
            all_metadata = []
            all_content_uuids = []

            for page_num, page in enumerate(pdf_reader.pages, start=1):
                text = page.extract_text()

                if not text.strip():
                    continue

                chunks = self.chunk_text(text)

                chunk_metadata = {
                    **metadata,
                    "total_pages": total_pages
                }
                metadata_str = json.dumps(chunk_metadata)

                for chunk in chunks:
                    all_chunks.append(chunk)
                    all_filenames.append(filename)
                    all_page_numbers.append(page_num)
                    all_metadata.append(metadata_str)
                    all_content_uuids.append(content_uuid)

            embeddings = await self.ai_model.embed_batch(all_chunks)

            self.pg_client.insert_vectors(
                embeddings=embeddings,
                texts=all_chunks,
                filenames=all_filenames,
                page_numbers=all_page_numbers,
                metadata=all_metadata,
                content_uuids=all_content_uuids
            )

            return {
                "success": True,
                "filename": filename,
                "content_uuid": content_uuid,
                "total_pages": total_pages,
                "total_chunks": len(all_chunks),
                "message": f"Successfully processed {filename}"
            }

        except Exception as e:
            return {
                "success": False,
                "filename": filename,
                "content_uuid": content_uuid,
                "error": str(e),
                "message": f"Error processing {filename}: {str(e)}"
            }


async def process_document_async(
    file_content: bytes,
    filename: str,
    metadata: Dict[str, Any],
    content_uuid: str,
    ai_model: AIModel,
    pg_client: PgClient
) -> Dict[str, Any]:
    """
    Async function to process document in background and update status.

    Args:
        file_content: File content as bytes
        filename: Name of the file
        metadata: Additional metadata
        content_uuid: UUID of the content
        ai_model: AI model instance
        pg_client: PostgreSQL client instance

    Returns:
        Processing result dictionary
    """
    processor = DocumentProcessor(ai_model, pg_client)
    result = await processor.process_pdf(file_content, filename, metadata, content_uuid)

    if result["success"]:
        pg_client.update_content_status(content_uuid, "completed")
    else:
        pg_client.update_content_status(content_uuid, "failed")

    return result

# Spec-Parser Agent

An intelligent specification parsing agent that uses LangGraph and a custom LLM to dynamically discover file structures and generate JSON Schema from specification documents.

## Overview

The Spec-Parser agent is **fully LLM-powered**. It:

1. Accepts user-specified transaction layout names from specification documents
2. Retrieves and analyzes complete specification documents from pgvector
3. Uses LLM to intelligently discover file structure (header, detail, trailer records)
4. Extracts field definitions using targeted RAG queries
5. **Generates standard JSON Schema (draft-07)** for validation and documentation
6. Does NOT save schemas to database - only generates and returns them

**Key Principle:** The agent understands file layouts and generates appropriate JSON Schema through LLM intelligence.

## Architecture

### Components

- **CustomLLM**: LangChain-compatible wrapper for custom LLM API endpoints
- **SpecParserAgent**: LangGraph-based agent orchestrating the parsing workflow
- **PgClient**: PostgreSQL client with pgvector for document retrieval and RAG searches
- **JSONSchemaGenerator**: Generates standard JSON Schema (draft-07) format
- **Chat Endpoint**: Integrated with existing chat API for conversational interaction

### Workflow

```
User Specifies Transaction Layout
    ↓
Retrieve Full Document from pgvector
    ↓
Discover File Structure (LLM Analysis)
    ↓
[High Confidence?] → Yes → Extract Fields
    ↓ No
Confirm with User
    ↓
Extract Header Fields (RAG)
    ↓
Extract Detail Fields (RAG)
    ↓
Extract Trailer Fields (RAG)
    ↓
Generate JSON Schema
    ↓
Present Schema to User
```

## Setup

### 1. Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Environment Variables

Copy `.env.example` to `.env` and configure:

```env
# PostgreSQL/pgvector Configuration
PGVECTOR_CONNECTION_STRING=postgresql://user:password@localhost:5432/dbname

# Gemini API (for embeddings)
GEMINI_API_KEY=your_gemini_api_key

# Custom LLM Configuration (for Spec-Parser agent)
CUSTOM_LLM_ENDPOINT=https://your-custom-llm-api.com/v1/generate
CUSTOM_LLM_API_KEY=your_custom_llm_api_key
CUSTOM_LLM_MODEL_NAME=custom-model
```

### 3. Custom LLM API Requirements

Your custom LLM API should accept requests in the following format:

**Request:**
```json
{
  "prompt": "Your prompt text here...",
  "temperature": 0.7,
  "max_tokens": 4096,
  "model": "custom-model"
}
```

**Response:**
```json
{
  "text": "Generated response text...",
  // OR
  "response": "Generated response text...",
  // OR
  "output": "Generated response text..."
}
```

The CustomLLM wrapper will check for `text`, `response`, or `output` fields in the response.

## Usage

### 1. Start the Backend

```bash
cd backend
python main.py
```

### 2. Upload a Specification Document

Use the Documents tab in the frontend to upload a PDF specification file. Wait for processing to complete.

### 3. Start a New Chat

In the Chat tab:
1. Select **Spec-Parser** from the Agent dropdown
2. Select your uploaded specification from the Specs dropdown
3. Specify which transaction layout you want to parse

### 4. Example Conversation

**User:** Parse the Payment Transaction layout

**Agent:** Analyzing the **Payment Transaction** layout from the specification...

**Agent:** Retrieved specification document (45 pages). Analyzing structure...

**Agent:** **Structure Discovery Complete**

Layout: Payment Transaction
- File Format: fixed-length
- Has Header: True
- Has Trailer: True
- Detail Record Types: payment_detail
- Confidence: 85%

**Agent:** Extracted 8 header fields.

**Agent:** Extracted 24 detail record fields.

**Agent:** Extracted 5 trailer fields.

**Agent:** **JSON Schema Generated Successfully**

The system has generated a JSON Schema for your file layout:
- Layout: Payment Transaction
- Format: fixed-length
- Header fields: 8
- Detail fields: 24
- Trailer fields: 5
- Total fields: 37

**Preview:**
```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "urn:spec:...:Payment Transaction",
  "title": "Payment Transaction",
  ...
}
```

**Agent:** JSON Schema Generation Complete

Your JSON Schema has been generated successfully and is available for download.

## Features

### Dynamic Structure Discovery

The agent doesn't use predefined templates. It analyzes each specification document to discover:

- Whether the file has header records
- Whether the file has trailer records
- What types of detail/body records exist
- File format (fixed-length, delimited, CSV, positional)
- Record identifiers and delimiters

### Targeted RAG Retrieval

After discovering the overall structure, the agent performs targeted vector searches:

- **Header fields:** Searches for "header record layout fields structure"
- **Detail fields:** Searches for "detail body record layout fields structure"
- **Trailer fields:** Searches for "trailer footer record layout fields structure"

All searches are filtered to the selected specification document and include the user-specified transaction layout name.

### Human-in-the-Loop

When confidence scores are below 70%, the agent pauses to ask for confirmation:

- Structure confirmation (has header? has trailer?)
- Field validation
- Format clarifications

Users can provide corrections through natural language responses.

### JSON Schema Generation

The `generate_schema` node produces standard JSON Schema (draft-07) format from extracted fields.

**Generated schemas include:**
- Standard JSON Schema structure with `$schema` and `$id` fields
- Proper type definitions (string, integer, number, boolean, date, etc.)
- Format specifications for dates, times, and timestamps
- Validation constraints (pattern, minLength, maxLength, minimum, maximum)
- Required field declarations
- Position and length metadata for fixed-width fields (in x- custom properties)
- Record type identification and identifiers
- Nested object structures for header, details array, and trailer

**Schema structure:**
```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "properties": {
    "header": { "type": "object", "properties": {...} },
    "details": { "type": "array", "items": {...} },
    "trailer": { "type": "object", "properties": {...} }
  },
  "x-metadata": {
    "file_format": "fixed-length",
    "spec_id": "...",
    "confidence_score": 0.85
  }
}
```

Schemas can be used for validation, documentation, or code generation.

## State Management

The agent uses LangGraph's `MemorySaver` for in-memory checkpoint storage:

- State is indexed by `chat_id` (used as `thread_id`)
- Supports pause/resume for human intervention
- State persists for the duration of the session
- Automatically cleaned up after completion or timeout

**Note:** State is stored in memory and will be lost on server restart.

## API Integration

### Chat Endpoint

**POST /chat**

```json
{
  "chat_id": "uuid",
  "message": "Parse the Payment Transaction layout",
  "agent": "Spec-Parser",
  "spec_id": "content_uuid_of_uploaded_spec"
}
```

**Response:**

```json
{
  "chat_id": "uuid",
  "response": "Markdown formatted response with analysis and JSON Schema preview",
  "sources": [],
  "charts": []
}
```

The generated JSON Schema is returned inline in the response. No files are saved to the database.

## Extending the Agent

### Adding Custom Nodes

To add new workflow nodes:

1. Define the node function in `SpecParserAgent`
2. Add the node to the graph in `_build_graph()`
3. Define routing logic for the node
4. Update the state type if needed

### Customizing Prompts

LLM prompts are defined inline in each node method. To customize:

1. Locate the relevant node method (e.g., `discover_structure`)
2. Modify the prompt string
3. Adjust JSON parsing if you change the response format

### Supporting Additional File Formats

The agent currently supports:
- Fixed-length
- Delimited
- CSV
- Positional

To add new formats, update the structure discovery prompt and schema generation logic.

## Troubleshooting

### Agent Not Available

**Error:** "Spec-Parser agent not configured"

**Solution:** Ensure `CUSTOM_LLM_ENDPOINT` is set in `.env`

### Empty Responses

**Issue:** Agent returns no messages

**Solution:** Check custom LLM API connectivity and response format

### Missing Fields

**Issue:** Agent doesn't extract all fields

**Solution:**
- Check RAG query results (may need more specific queries)
- Ensure document was properly chunked during upload
- Try with different transaction layout specification

### State Lost

**Issue:** Agent loses context between messages

**Solution:**
- Check that `chat_id` is consistent across requests
- Verify MemorySaver is initialized
- Note that state is lost on server restart

## Performance Considerations

- **Document Size:** Large specifications (>100 pages) may take longer to analyze
- **RAG Queries:** Each record type requires a separate RAG search
- **LLM Calls:** The agent makes multiple LLM API calls per workflow
- **Timeout:** Default timeout is 120 seconds per LLM call

## Security

- Custom LLM API keys are stored securely in `.env`
- No data is saved to database automatically
- Generated schemas are returned inline only
- No sensitive data is logged

## Future Enhancements

- [ ] Support for nested record structures
- [ ] Multi-record type parsing in single session
- [ ] Persistent state storage (database-backed)
- [ ] Batch processing of multiple layouts
- [ ] Interactive field editor
- [ ] Schema versioning and comparison
- [ ] Export to additional formats (OpenAPI, GraphQL schemas)

## License

See main project LICENSE file.

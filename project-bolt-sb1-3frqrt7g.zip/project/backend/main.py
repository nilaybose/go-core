from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio
from auth.routes import router as auth_router
from admin.system_prompts_routes import router as system_prompts_router
from admin.content_routes import router as content_router
from admin.recon_specs_routes import router as recon_specs_router
from workflows.workflow_routes import router as workflow_router
from workflows.task_routes import router as task_router
from tasks.schema_mapping.routes import router as schema_mapping_router
from tasks.auto_mapping.routes import router as auto_mapping_router
from tasks.commit_mapping.routes import router as commit_mapping_router
from tasks.code_generation.routes import router as code_generation_router
from tasks.ticket_creation.routes import router as ticket_creation_router
from tasks.signoff.routes import router as signoff_router
from utils.session_manager import session_manager

async def cleanup_sessions():
    while True:
        await asyncio.sleep(300)
        session_manager.cleanup_expired_sessions()

@asynccontextmanager
async def lifespan(app: FastAPI):
    cleanup_task = asyncio.create_task(cleanup_sessions())
    yield
    cleanup_task.cancel()

app = FastAPI(title="Codeless Workflow API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(system_prompts_router)
app.include_router(content_router)
app.include_router(recon_specs_router)
app.include_router(workflow_router)
app.include_router(task_router)
app.include_router(schema_mapping_router)
app.include_router(auto_mapping_router)
app.include_router(commit_mapping_router)
app.include_router(code_generation_router)
app.include_router(ticket_creation_router)
app.include_router(signoff_router)

@app.get("/")
async def root():
    return {"message": "Codeless Workflow API"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

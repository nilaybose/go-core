import uuid
from datetime import datetime, timedelta
from typing import Dict, Optional
from threading import Lock
from config.settings import settings

class SessionManager:
    def __init__(self):
        self._sessions: Dict[str, dict] = {}
        self._lock = Lock()

    def create_session(self, user_id: str) -> str:
        session_id = str(uuid.uuid4())
        now = datetime.utcnow()
        expires_at = now + timedelta(minutes=settings.session_timeout_minutes)

        with self._lock:
            self._sessions[session_id] = {
                'user_id': user_id,
                'last_activity': now,
                'expires_at': expires_at
            }

        return session_id

    def validate_session(self, session_id: str) -> Optional[str]:
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return None

            now = datetime.utcnow()
            if now > session['expires_at']:
                del self._sessions[session_id]
                return None

            return session['user_id']

    def update_activity(self, session_id: str) -> bool:
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return False

            now = datetime.utcnow()
            if now > session['expires_at']:
                del self._sessions[session_id]
                return False

            session['last_activity'] = now
            session['expires_at'] = now + timedelta(minutes=settings.session_timeout_minutes)
            return True

    def remove_session(self, session_id: str) -> bool:
        with self._lock:
            if session_id in self._sessions:
                del self._sessions[session_id]
                return True
            return False

    def cleanup_expired_sessions(self):
        with self._lock:
            now = datetime.utcnow()
            expired_sessions = [
                sid for sid, session in self._sessions.items()
                if now > session['expires_at']
            ]
            for sid in expired_sessions:
                del self._sessions[sid]

session_manager = SessionManager()

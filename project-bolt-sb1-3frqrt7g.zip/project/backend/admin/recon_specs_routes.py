from fastapi import APIRouter, HTTPException, Depends, Query, Response
from typing import List, Optional
from uuid import UUID
from models.recon_spec import ReconSpecCreate, ReconSpecUpdate, ReconSpecResponse
from middleware.role_middleware import get_current_user_from_session
from db.connection import get_db_connection, DatabaseConnection
import psycopg2.extras
import json

router = APIRouter(prefix="/admin/recon-specs", tags=["admin", "recon-specs"])

@router.get("", response_model=List[ReconSpecResponse])
async def get_all_recon_specs(
    search: Optional[str] = Query(None, description="Search by spec name"),
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get all recon specs with optional search filter - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        if search:
            cursor.execute("""
                SELECT id, name, json_content, date_created, date_modified, last_updated_by
                FROM recon_specs
                WHERE name ILIKE %s
                ORDER BY date_modified DESC
            """, (f'%{search}%',))
        else:
            cursor.execute("""
                SELECT id, name, json_content, date_created, date_modified, last_updated_by
                FROM recon_specs
                ORDER BY date_modified DESC
            """)

        specs = cursor.fetchall()
        cursor.close()

        return [dict(spec) for spec in specs]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/{spec_id}", response_model=ReconSpecResponse)
async def get_recon_spec(
    spec_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get a specific recon spec by ID - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT id, name, json_content, date_created, date_modified, last_updated_by
            FROM recon_specs
            WHERE id = %s
        """, (str(spec_id),))
        spec = cursor.fetchone()
        cursor.close()

        if not spec:
            raise HTTPException(status_code=404, detail="Recon spec not found")

        return dict(spec)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/{spec_id}/download")
async def download_recon_spec(
    spec_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Download a recon spec as JSON file - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT name, json_content
            FROM recon_specs
            WHERE id = %s
        """, (str(spec_id),))
        spec = cursor.fetchone()
        cursor.close()

        if not spec:
            raise HTTPException(status_code=404, detail="Recon spec not found")

        json_str = json.dumps(spec['json_content'], indent=2)

        return Response(
            content=json_str,
            media_type="application/json",
            headers={
                "Content-Disposition": f"attachment; filename={spec['name']}.json"
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.post("", response_model=ReconSpecResponse, status_code=201)
async def create_recon_spec(
    spec_data: ReconSpecCreate,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Create a new recon spec - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            INSERT INTO recon_specs (name, json_content, last_updated_by)
            VALUES (%s, %s, %s)
            RETURNING id, name, json_content, date_created, date_modified, last_updated_by
        """, (
            spec_data.name,
            json.dumps(spec_data.json_content),
            current_user['user_id']
        ))

        conn.commit()
        created_spec = cursor.fetchone()
        cursor.close()

        return dict(created_spec)
    except psycopg2.errors.UniqueViolation:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=400, detail="A recon spec with this name already exists")
    except psycopg2.errors.CheckViolation:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=400, detail="Invalid name format. Use only alphanumeric characters and underscores")
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.put("/{spec_id}", response_model=ReconSpecResponse)
async def update_recon_spec(
    spec_id: UUID,
    spec_data: ReconSpecUpdate,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Update an existing recon spec - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("SELECT id FROM recon_specs WHERE id = %s", (str(spec_id),))
        if not cursor.fetchone():
            cursor.close()
            raise HTTPException(status_code=404, detail="Recon spec not found")

        update_fields = []
        update_values = []

        if spec_data.name is not None:
            update_fields.append("name = %s")
            update_values.append(spec_data.name)

        if spec_data.json_content is not None:
            update_fields.append("json_content = %s")
            update_values.append(json.dumps(spec_data.json_content))

        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")

        update_fields.append("last_updated_by = %s")
        update_values.append(current_user['user_id'])
        update_values.append(str(spec_id))

        update_query = f"""
            UPDATE recon_specs
            SET {', '.join(update_fields)}
            WHERE id = %s
            RETURNING id, name, json_content, date_created, date_modified, last_updated_by
        """

        cursor.execute(update_query, update_values)
        conn.commit()
        updated_spec = cursor.fetchone()
        cursor.close()

        return dict(updated_spec)
    except HTTPException:
        raise
    except psycopg2.errors.UniqueViolation:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=400, detail="A recon spec with this name already exists")
    except psycopg2.errors.CheckViolation:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=400, detail="Invalid name format. Use only alphanumeric characters and underscores")
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.delete("/{spec_id}", status_code=204)
async def delete_recon_spec(
    spec_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Delete a recon spec - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM recon_specs WHERE id = %s RETURNING id", (str(spec_id),))
        deleted = cursor.fetchone()

        if not deleted:
            cursor.close()
            raise HTTPException(status_code=404, detail="Recon spec not found")

        conn.commit()
        cursor.close()
        return None
    except HTTPException:
        raise
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

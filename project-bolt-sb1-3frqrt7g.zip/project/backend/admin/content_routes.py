from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from uuid import UUID
from models.content import ContentCreate, ContentUpdate, ContentResponse, ContentDetailResponse, ContentStatusUpdate
from middleware.role_middleware import get_current_user_from_session, require_pm_role
from db.connection import get_db_connection, DatabaseConnection
import psycopg2.extras
import json

router = APIRouter(prefix="/admin/contents", tags=["admin", "contents"])

@router.get("", response_model=List[ContentResponse])
async def get_all_contents(
    search: Optional[str] = Query(None, description="Search by content name"),
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get all contents with optional search filter - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        if search:
            cursor.execute("""
                SELECT content_id, content_name, file_name, metadata, date_created, user_uploaded, status
                FROM contents
                WHERE content_name ILIKE %s
                ORDER BY date_created DESC
            """, (f'%{search}%',))
        else:
            cursor.execute("""
                SELECT content_id, content_name, file_name, metadata, date_created, user_uploaded, status
                FROM contents
                ORDER BY date_created DESC
            """)

        contents = cursor.fetchall()
        cursor.close()

        return [dict(content) for content in contents]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/{content_id}", response_model=ContentDetailResponse)
async def get_content_by_id(
    content_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get a specific content by ID including blob data - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT content_id, content_name, file_name, blob_data, metadata, date_created, user_uploaded, status
            FROM contents
            WHERE content_id = %s
        """, (str(content_id),))
        content = cursor.fetchone()
        cursor.close()

        if not content:
            raise HTTPException(status_code=404, detail="Content not found")

        return dict(content)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/{content_id}/metadata", response_model=dict)
async def get_content_metadata(
    content_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get only metadata for a specific content - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT content_name, file_name, metadata, date_created, user_uploaded, status
            FROM contents
            WHERE content_id = %s
        """, (str(content_id),))
        content = cursor.fetchone()
        cursor.close()

        if not content:
            raise HTTPException(status_code=404, detail="Content not found")

        return dict(content)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.post("", response_model=ContentResponse, status_code=201)
async def create_content(
    content_data: ContentCreate,
    current_user: dict = Depends(require_pm_role)
):
    """Create a new content - PM role only"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            INSERT INTO contents (content_name, file_name, blob_data, metadata, user_uploaded, status)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING content_id, content_name, file_name, metadata, date_created, user_uploaded, status
        """, (
            content_data.content_name,
            content_data.file_name,
            content_data.blob_data,
            json.dumps(content_data.metadata),
            current_user['user_id'],
            content_data.status
        ))

        conn.commit()
        created_content = cursor.fetchone()
        cursor.close()

        return dict(created_content)
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.patch("/{content_id}/status", response_model=ContentResponse)
async def update_content_status(
    content_id: UUID,
    status_update: ContentStatusUpdate,
    current_user: dict = Depends(require_pm_role)
):
    """Update content status - PM role only"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            UPDATE contents
            SET status = %s
            WHERE content_id = %s
            RETURNING content_id, content_name, file_name, metadata, date_created, user_uploaded, status
        """, (status_update.status, str(content_id)))

        updated_content = cursor.fetchone()

        if not updated_content:
            cursor.close()
            raise HTTPException(status_code=404, detail="Content not found")

        conn.commit()
        cursor.close()
        return dict(updated_content)
    except HTTPException:
        raise
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.delete("/{content_id}", status_code=204)
async def delete_content(
    content_id: UUID,
    current_user: dict = Depends(require_pm_role)
):
    """Delete a content - PM role only"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM contents WHERE content_id = %s RETURNING content_id", (str(content_id),))
        deleted = cursor.fetchone()

        if not deleted:
            cursor.close()
            raise HTTPException(status_code=404, detail="Content not found")

        conn.commit()
        cursor.close()
        return None
    except HTTPException:
        raise
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

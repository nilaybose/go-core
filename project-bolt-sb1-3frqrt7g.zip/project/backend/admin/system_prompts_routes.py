from fastapi import APIRouter, HTTPException, Depends
from typing import List
from uuid import UUID
from models.system_prompt import SystemPromptCreate, SystemPromptUpdate, SystemPromptResponse
from middleware.role_middleware import get_current_user_from_session, require_pm_role
from db.connection import get_db_connection, DatabaseConnection
import psycopg2.extras

router = APIRouter(prefix="/admin/system-prompts", tags=["admin", "system-prompts"])

@router.get("", response_model=List[SystemPromptResponse])
async def get_all_system_prompts(current_user: dict = Depends(get_current_user_from_session)):
    """Get all system prompts - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT id, name, prompt, created_by, created_at, updated_at, updated_by
            FROM system_prompts
            ORDER BY created_at DESC
        """)
        prompts = cursor.fetchall()
        cursor.close()

        return [dict(prompt) for prompt in prompts]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/{prompt_id}", response_model=SystemPromptResponse)
async def get_system_prompt(
    prompt_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get a specific system prompt by ID - accessible to both PD and PM roles"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT id, name, prompt, created_by, created_at, updated_at, updated_by
            FROM system_prompts
            WHERE id = %s
        """, (str(prompt_id),))
        prompt = cursor.fetchone()
        cursor.close()

        if not prompt:
            raise HTTPException(status_code=404, detail="System prompt not found")

        return dict(prompt)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.post("", response_model=SystemPromptResponse, status_code=201)
async def create_system_prompt(
    prompt_data: SystemPromptCreate,
    current_user: dict = Depends(require_pm_role)
):
    """Create a new system prompt - PM role only"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            INSERT INTO system_prompts (name, prompt, created_by)
            VALUES (%s, %s, %s)
            RETURNING id, name, prompt, created_by, created_at, updated_at, updated_by
        """, (prompt_data.name, prompt_data.prompt, current_user['user_id']))

        conn.commit()
        created_prompt = cursor.fetchone()
        cursor.close()

        return dict(created_prompt)
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.put("/{prompt_id}", response_model=SystemPromptResponse)
async def update_system_prompt(
    prompt_id: UUID,
    prompt_data: SystemPromptUpdate,
    current_user: dict = Depends(require_pm_role)
):
    """Update an existing system prompt - PM role only"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        # Check if prompt exists
        cursor.execute("SELECT id FROM system_prompts WHERE id = %s", (str(prompt_id),))
        if not cursor.fetchone():
            cursor.close()
            raise HTTPException(status_code=404, detail="System prompt not found")

        # Build update query dynamically based on provided fields
        update_fields = []
        update_values = []

        if prompt_data.name is not None:
            update_fields.append("name = %s")
            update_values.append(prompt_data.name)

        if prompt_data.prompt is not None:
            update_fields.append("prompt = %s")
            update_values.append(prompt_data.prompt)

        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")

        update_fields.append("updated_by = %s")
        update_values.append(current_user['user_id'])
        update_values.append(str(prompt_id))
        update_query = f"""
            UPDATE system_prompts
            SET {', '.join(update_fields)}
            WHERE id = %s
            RETURNING id, name, prompt, created_by, created_at, updated_at, updated_by
        """

        cursor.execute(update_query, update_values)
        conn.commit()
        updated_prompt = cursor.fetchone()
        cursor.close()

        return dict(updated_prompt)
    except HTTPException:
        raise
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.delete("/{prompt_id}", status_code=204)
async def delete_system_prompt(
    prompt_id: UUID,
    current_user: dict = Depends(require_pm_role)
):
    """Delete a system prompt - PM role only"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM system_prompts WHERE id = %s RETURNING id", (str(prompt_id),))
        deleted = cursor.fetchone()

        if not deleted:
            cursor.close()
            raise HTTPException(status_code=404, detail="System prompt not found")

        conn.commit()
        cursor.close()
        return None
    except HTTPException:
        raise
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

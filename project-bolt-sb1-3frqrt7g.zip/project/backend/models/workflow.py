from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Literal
from uuid import UUID

WorkflowStatusType = Literal['pending', 'in_progress', 'completed', 'cancelled']
TaskStatusType = Literal['pending', 'in_process', 'completed']

class WorkflowBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    processor_name: str = Field(..., min_length=1, max_length=255)

class WorkflowCreate(WorkflowBase):
    pass

class WorkflowStatusUpdate(BaseModel):
    status: WorkflowStatusType
    status_note: str = Field(..., min_length=5)

class TaskResponse(BaseModel):
    id: UUID
    workflow_id: UUID
    task_name: str
    seq_order: int
    status: TaskStatusType
    artifact_mandatory: bool
    role_assigned: str
    start_datetime: Optional[datetime]
    end_datetime: Optional[datetime]
    remarks: Optional[str]
    status_note: Optional[str]
    last_modified_by: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class WorkflowResponse(BaseModel):
    id: UUID
    name: str
    processor_name: str
    status: WorkflowStatusType
    start_datetime: datetime
    end_datetime: Optional[datetime]
    initiated_user: str
    status_note: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class WorkflowDetailResponse(WorkflowResponse):
    tasks: List[TaskResponse] = []
    can_complete: bool = False

class TaskStatusUpdate(BaseModel):
    status: TaskStatusType
    status_note: str = Field(..., min_length=5)

class TaskUpdate(BaseModel):
    remarks: Optional[str] = None

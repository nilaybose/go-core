from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class Session(BaseModel):
    session_id: str
    user_id: str
    last_activity: datetime
    expires_at: datetime

class SessionResponse(BaseModel):
    session_id: str
    user_id: str
    valid: bool

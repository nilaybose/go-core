from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
from uuid import UUID

class SystemPromptBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    prompt: str = Field(..., min_length=1)

class SystemPromptCreate(SystemPromptBase):
    pass

class SystemPromptUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    prompt: Optional[str] = Field(None, min_length=1)

class SystemPromptResponse(SystemPromptBase):
    id: UUID
    created_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    updated_by: Optional[str]

    class Config:
        from_attributes = True

class SystemPrompt(SystemPromptResponse):
    pass

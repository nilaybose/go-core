from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Literal

class User(BaseModel):
    user_id: str
    firstname: str
    lastname: str
    email: EmailStr
    role: Literal['PD', 'PM']
    created_date: datetime

class UserLogin(BaseModel):
    user_id: str
    password: str

class UserResponse(BaseModel):
    user_id: str
    firstname: str
    lastname: str
    email: str
    role: Literal['PD', 'PM']

from pydantic import BaseModel, Field, field_validator
from datetime import datetime
from typing import Optional, Dict, Any
from uuid import UUID
import json
import re

class ReconSpecBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=50, description="Spec name (alphanumeric and underscore only)")
    json_content: Dict[str, Any] = Field(..., description="JSON schema content")

    @field_validator('name')
    @classmethod
    def validate_name_format(cls, v: str) -> str:
        if not re.match(r'^[a-zA-Z0-9_]+$', v):
            raise ValueError('Name must contain only alphanumeric characters and underscores')
        return v

    @field_validator('json_content')
    @classmethod
    def validate_json_content(cls, v: Dict[str, Any]) -> Dict[str, Any]:
        if not v:
            raise ValueError('JSON content cannot be empty')
        try:
            json.dumps(v)
        except (TypeError, ValueError) as e:
            raise ValueError(f'Invalid JSON format: {str(e)}')
        return v

class ReconSpecCreate(ReconSpecBase):
    pass

class ReconSpecUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=50, description="Spec name (alphanumeric and underscore only)")
    json_content: Optional[Dict[str, Any]] = Field(None, description="JSON schema content")

    @field_validator('name')
    @classmethod
    def validate_name_format(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and not re.match(r'^[a-zA-Z0-9_]+$', v):
            raise ValueError('Name must contain only alphanumeric characters and underscores')
        return v

    @field_validator('json_content')
    @classmethod
    def validate_json_content(cls, v: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if v is not None:
            if not v:
                raise ValueError('JSON content cannot be empty')
            try:
                json.dumps(v)
            except (TypeError, ValueError) as e:
                raise ValueError(f'Invalid JSON format: {str(e)}')
        return v

class ReconSpecResponse(BaseModel):
    id: UUID
    name: str
    json_content: Dict[str, Any]
    date_created: datetime
    date_modified: datetime
    last_updated_by: str

    class Config:
        from_attributes = True

class ReconSpec(ReconSpecResponse):
    pass

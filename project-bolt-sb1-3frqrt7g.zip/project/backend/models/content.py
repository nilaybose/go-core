from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, Dict, Any, Literal
from uuid import UUID

ContentStatusType = Literal['in_process', 'completed', 'failed']

class ContentBase(BaseModel):
    content_name: str = Field(..., min_length=1, max_length=255)
    file_name: str = Field(..., min_length=1, max_length=255)
    blob_data: str = Field(..., min_length=1)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    status: ContentStatusType = 'in_process'

class ContentCreate(ContentBase):
    pass

class ContentUpdate(BaseModel):
    content_name: Optional[str] = Field(None, min_length=1, max_length=255)
    file_name: Optional[str] = Field(None, min_length=1, max_length=255)
    blob_data: Optional[str] = Field(None, min_length=1)
    metadata: Optional[Dict[str, Any]] = None
    status: Optional[ContentStatusType] = None

class ContentResponse(BaseModel):
    content_id: UUID
    content_name: str
    file_name: str
    date_created: datetime
    user_uploaded: str
    metadata: Dict[str, Any]
    status: ContentStatusType

    class Config:
        from_attributes = True

class ContentDetailResponse(ContentResponse):
    blob_data: str

class ContentStatusUpdate(BaseModel):
    status: ContentStatusType

class Content(ContentDetailResponse):
    pass

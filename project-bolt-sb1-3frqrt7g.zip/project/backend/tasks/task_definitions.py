from typing import List, Optional, Dict, Any

class TaskDefinition:
    def __init__(
        self,
        name: str,
        seq_order: int,
        role_assigned: str,
        artifact_mandatory: bool,
        description: str
    ):
        self.name = name
        self.seq_order = seq_order
        self.role_assigned = role_assigned
        self.artifact_mandatory = artifact_mandatory
        self.description = description

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "seq_order": self.seq_order,
            "role_assigned": self.role_assigned,
            "artifact_mandatory": self.artifact_mandatory,
            "description": self.description
        }

TASK_DEFINITIONS = [
    TaskDefinition(
        name="Schema Mapping",
        seq_order=1,
        role_assigned="PM",
        artifact_mandatory=True,
        description="Map source data schema to target schema format. Review and define field mappings, data transformations, and validation rules."
    ),
    TaskDefinition(
        name="Auto Mapping",
        seq_order=2,
        role_assigned="PM",
        artifact_mandatory=True,
        description="Automated mapping process using AI/ML algorithms to suggest field mappings based on schema analysis and historical patterns."
    ),
    TaskDefinition(
        name="Commit Mapping",
        seq_order=3,
        role_assigned="PM",
        artifact_mandatory=True,
        description="Review and finalize all mapping configurations. Commit approved mappings to the system for code generation."
    ),
    TaskDefinition(
        name="Code Generation",
        seq_order=4,
        role_assigned="PD",
        artifact_mandatory=False,
        description="Generate transformation code based on committed mappings. Create ETL scripts, data pipelines, and validation logic."
    ),
    TaskDefinition(
        name="Ticket Creation",
        seq_order=5,
        role_assigned="PM",
        artifact_mandatory=False,
        description="Create implementation tickets in project management system. Assign tasks, set priorities, and define acceptance criteria."
    ),
    TaskDefinition(
        name="Signoff",
        seq_order=6,
        role_assigned="PM",
        artifact_mandatory=False,
        description="Final review and approval of the workflow. Verify all deliverables, documentation, and sign off on completion."
    )
]

def get_all_task_definitions() -> List[TaskDefinition]:
    """Get all task definitions in sequential order"""
    return TASK_DEFINITIONS

def get_task_definition_by_name(name: str) -> Optional[TaskDefinition]:
    """Get a task definition by name"""
    for task in TASK_DEFINITIONS:
        if task.name == name:
            return task
    return None

def get_task_definition_by_order(seq_order: int) -> Optional[TaskDefinition]:
    """Get a task definition by sequence order"""
    for task in TASK_DEFINITIONS:
        if task.seq_order == seq_order:
            return task
    return None

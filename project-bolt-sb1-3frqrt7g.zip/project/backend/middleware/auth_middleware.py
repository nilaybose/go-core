from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from utils.session_manager import session_manager

class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path.startswith("/auth/login") or request.url.path.startswith("/docs") or request.url.path.startswith("/openapi.json"):
            return await call_next(request)

        session_id = request.headers.get("Authorization")
        if session_id and session_id.startswith("Bearer "):
            session_id = session_id[7:]

        if not session_id and not request.url.path.startswith("/auth/"):
            user_id = session_manager.validate_session(session_id)
            if not user_id:
                raise HTTPException(status_code=401, detail="Invalid or expired session")

            session_manager.update_activity(session_id)

        response = await call_next(request)
        return response

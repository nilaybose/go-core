from fastapi import HTTPException, Depends, Header
from typing import Optional
from utils.session_manager import session_manager
from db.connection import get_db_connection, DatabaseConnection
import psycopg2.extras

async def get_current_user_from_session(session_id: Optional[str] = Header(None, alias="X-Session-ID")):
    if not session_id:
        raise HTTPException(status_code=401, detail="Session ID is required")

    user_id = session_manager.validate_session(session_id)
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid or expired session")

    session_manager.update_activity(session_id)

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute(
            "SELECT user_id, firstname, lastname, email, role FROM users WHERE user_id = %s",
            (user_id,)
        )
        user = cursor.fetchone()
        cursor.close()

        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        return dict(user)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

async def require_pm_role(current_user: dict = Depends(get_current_user_from_session)):
    if current_user.get('role') != 'PM':
        raise HTTPException(
            status_code=403,
            detail="Access denied. Only PM users can perform this operation."
        )
    return current_user

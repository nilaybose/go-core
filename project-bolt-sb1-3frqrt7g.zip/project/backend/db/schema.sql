/*
  # Complete Database Schema for Codeless Workflow System

  This file contains all table definitions, enums, indexes, and RLS policies
  for the Codeless Workflow application.

  Tables:
  1. users - User accounts with roles (PM/PD)
  2. system_prompts - System prompts for AI operations
  3. contents - File/content uploads with status tracking
  4. recon_specs - Reconciliation specifications (JSON configurations)
  5. workflow_instance - Workflow instances with lifecycle tracking
  6. workflow_task - Individual tasks within workflows

  Enums:
  - user_role: PM, PD
  - content_status: in_process, completed, failed
  - workflow_status: pending, in_progress, completed, cancelled
  - task_status: pending, in_process, completed
*/

-- =====================================================
-- ENUMS
-- =====================================================

-- User roles
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('PM', 'PD');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Content status
DO $$ BEGIN
  CREATE TYPE content_status AS ENUM ('in_process', 'completed', 'failed');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Workflow status
DO $$ BEGIN
  CREATE TYPE workflow_status AS ENUM ('pending', 'in_progress', 'completed', 'cancelled');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Task status
DO $$ BEGIN
  CREATE TYPE task_status AS ENUM ('pending', 'in_process', 'completed');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- =====================================================
-- TABLE: users
-- =====================================================

CREATE TABLE IF NOT EXISTS users (
  user_id text PRIMARY KEY,
  firstname text NOT NULL,
  lastname text NOT NULL,
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  role user_role NOT NULL DEFAULT 'PD',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Indexes for users
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- RLS for users
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read all user profiles"
  ON users
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  TO authenticated
  USING (user_id = current_user)
  WITH CHECK (user_id = current_user);

-- =====================================================
-- TABLE: system_prompts
-- =====================================================

CREATE TABLE IF NOT EXISTS system_prompts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  prompt text NOT NULL,
  created_by text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  updated_by text,
  CONSTRAINT fk_system_prompts_created_by FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_system_prompts_updated_by FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Indexes for system_prompts
CREATE INDEX IF NOT EXISTS idx_system_prompts_name ON system_prompts(name);
CREATE INDEX IF NOT EXISTS idx_system_prompts_created_by ON system_prompts(created_by);

-- RLS for system_prompts
ALTER TABLE system_prompts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read system prompts"
  ON system_prompts
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "PM users can create system prompts"
  ON system_prompts
  FOR INSERT
  TO authenticated
  WITH CHECK (
    created_by IN (
      SELECT user_id FROM users WHERE role = 'PM'
    )
  );

CREATE POLICY "PM users can update system prompts"
  ON system_prompts
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (
    updated_by IN (
      SELECT user_id FROM users WHERE role = 'PM'
    )
  );

CREATE POLICY "PM users can delete system prompts"
  ON system_prompts
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users WHERE user_id = current_user AND role = 'PM'
    )
  );

-- =====================================================
-- TABLE: contents
-- =====================================================

CREATE TABLE IF NOT EXISTS contents (
  content_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_name text NOT NULL,
  file_name text NOT NULL,
  blob_data text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  date_created timestamptz DEFAULT now(),
  user_uploaded text NOT NULL,
  status content_status NOT NULL DEFAULT 'in_process',
  CONSTRAINT fk_contents_user_uploaded FOREIGN KEY (user_uploaded) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Indexes for contents
CREATE INDEX IF NOT EXISTS idx_contents_content_name ON contents(content_name);
CREATE INDEX IF NOT EXISTS idx_contents_user_uploaded ON contents(user_uploaded);
CREATE INDEX IF NOT EXISTS idx_contents_date_created ON contents(date_created DESC);
CREATE INDEX IF NOT EXISTS idx_contents_status ON contents(status);

-- RLS for contents
ALTER TABLE contents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read contents"
  ON contents
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "PM users can create contents"
  ON contents
  FOR INSERT
  TO authenticated
  WITH CHECK (
    user_uploaded IN (
      SELECT user_id FROM users WHERE role = 'PM'
    )
  );

CREATE POLICY "PM users can update contents"
  ON contents
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE user_id = user_uploaded
      AND role = 'PM'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE user_id = user_uploaded
      AND role = 'PM'
    )
  );

CREATE POLICY "PM users can delete contents"
  ON contents
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users WHERE user_id = current_user AND role = 'PM'
    )
  );

-- =====================================================
-- TABLE: recon_specs
-- =====================================================

CREATE TABLE IF NOT EXISTS recon_specs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  json_content jsonb NOT NULL,
  date_created timestamptz DEFAULT now(),
  date_modified timestamptz DEFAULT now(),
  last_updated_by text NOT NULL,
  CONSTRAINT fk_recon_specs_last_updated_by FOREIGN KEY (last_updated_by) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Indexes for recon_specs
CREATE INDEX IF NOT EXISTS idx_recon_specs_name ON recon_specs(name);
CREATE INDEX IF NOT EXISTS idx_recon_specs_date_modified ON recon_specs(date_modified DESC);
CREATE INDEX IF NOT EXISTS idx_recon_specs_last_updated_by ON recon_specs(last_updated_by);

-- RLS for recon_specs
ALTER TABLE recon_specs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read recon specs"
  ON recon_specs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "PM users can create recon specs"
  ON recon_specs
  FOR INSERT
  TO authenticated
  WITH CHECK (
    last_updated_by IN (
      SELECT user_id FROM users WHERE role = 'PM'
    )
  );

CREATE POLICY "PM users can update recon specs"
  ON recon_specs
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (
    last_updated_by IN (
      SELECT user_id FROM users WHERE role = 'PM'
    )
  );

CREATE POLICY "PM users can delete recon specs"
  ON recon_specs
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users WHERE user_id = current_user AND role = 'PM'
    )
  );

-- =====================================================
-- TABLE: workflow_instance
-- =====================================================

CREATE TABLE IF NOT EXISTS workflow_instance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  processor_name text NOT NULL,
  status workflow_status NOT NULL DEFAULT 'pending',
  start_datetime timestamptz DEFAULT now(),
  end_datetime timestamptz,
  initiated_user text NOT NULL,
  status_note text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT fk_initiated_user FOREIGN KEY (initiated_user) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Indexes for workflow_instance
CREATE INDEX IF NOT EXISTS idx_workflow_status ON workflow_instance(status);
CREATE INDEX IF NOT EXISTS idx_workflow_initiated_user ON workflow_instance(initiated_user);
CREATE INDEX IF NOT EXISTS idx_workflow_name ON workflow_instance(name);
CREATE INDEX IF NOT EXISTS idx_workflow_processor_name ON workflow_instance(processor_name);
CREATE INDEX IF NOT EXISTS idx_workflow_created_at ON workflow_instance(created_at DESC);

-- RLS for workflow_instance
ALTER TABLE workflow_instance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read workflows"
  ON workflow_instance
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "PM users can create workflows"
  ON workflow_instance
  FOR INSERT
  TO authenticated
  WITH CHECK (
    initiated_user IN (
      SELECT user_id::text FROM users
      WHERE role = 'PM'
    )
  );

CREATE POLICY "Authenticated users can update workflows"
  ON workflow_instance
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- TABLE: workflow_task
-- =====================================================

CREATE TABLE IF NOT EXISTS workflow_task (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL,
  task_name text NOT NULL,
  seq_order integer NOT NULL,
  status task_status NOT NULL DEFAULT 'pending',
  artifact_mandatory boolean DEFAULT false,
  role_assigned text NOT NULL,
  start_datetime timestamptz,
  end_datetime timestamptz,
  remarks text,
  status_note text,
  last_modified_by text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT fk_workflow_id FOREIGN KEY (workflow_id) REFERENCES workflow_instance(id) ON DELETE CASCADE,
  CONSTRAINT fk_last_modified_by FOREIGN KEY (last_modified_by) REFERENCES users(user_id) ON DELETE SET NULL,
  CONSTRAINT unique_workflow_task UNIQUE (workflow_id, task_name)
);

-- Indexes for workflow_task
CREATE INDEX IF NOT EXISTS idx_task_workflow_id ON workflow_task(workflow_id);
CREATE INDEX IF NOT EXISTS idx_task_status ON workflow_task(status);
CREATE INDEX IF NOT EXISTS idx_task_role_assigned ON workflow_task(role_assigned);
CREATE INDEX IF NOT EXISTS idx_task_seq_order ON workflow_task(seq_order);
CREATE INDEX IF NOT EXISTS idx_task_workflow_status ON workflow_task(workflow_id, status);
CREATE INDEX IF NOT EXISTS idx_task_role_status ON workflow_task(role_assigned, status);

-- RLS for workflow_task
ALTER TABLE workflow_task ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read tasks"
  ON workflow_task
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update tasks"
  ON workflow_task
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "System can insert tasks"
  ON workflow_task
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- =====================================================
-- FUNCTIONS (Optional - for triggers, etc.)
-- =====================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_system_prompts_updated_at ON system_prompts;
CREATE TRIGGER update_system_prompts_updated_at
  BEFORE UPDATE ON system_prompts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_recon_specs_date_modified ON recon_specs;
CREATE TRIGGER update_recon_specs_date_modified
  BEFORE UPDATE ON recon_specs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_workflow_instance_updated_at ON workflow_instance;
CREATE TRIGGER update_workflow_instance_updated_at
  BEFORE UPDATE ON workflow_instance
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_workflow_task_updated_at ON workflow_task;
CREATE TRIGGER update_workflow_task_updated_at
  BEFORE UPDATE ON workflow_task
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- COMMENTS (Optional - for documentation)
-- =====================================================

COMMENT ON TABLE users IS 'User accounts with role-based access (PM/PD)';
COMMENT ON TABLE system_prompts IS 'System prompts for AI/ML operations';
COMMENT ON TABLE contents IS 'File uploads and content storage with processing status';
COMMENT ON TABLE recon_specs IS 'Reconciliation specifications stored as JSON';
COMMENT ON TABLE workflow_instance IS 'Workflow instances with lifecycle tracking';
COMMENT ON TABLE workflow_task IS 'Individual tasks within workflow instances';

COMMENT ON COLUMN workflow_instance.status IS 'pending, in_progress, completed, cancelled';
COMMENT ON COLUMN workflow_task.status IS 'pending, in_process, completed';
COMMENT ON COLUMN workflow_task.artifact_mandatory IS 'Whether an artifact is required for this task';
COMMENT ON COLUMN workflow_task.role_assigned IS 'Role responsible for this task (PM or PD)';

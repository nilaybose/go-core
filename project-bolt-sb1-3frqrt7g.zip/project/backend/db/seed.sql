-- Reset database (for development only)
TRUNCATE TABLE users CASCADE;

-- Insert test users
-- Password for all users: password123
INSERT INTO users (user_id, firstname, lastname, email, password_hash, role)
VALUES
    ('pd001', 'John', 'Doe', 'john.doe@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PD'),
    ('pm001', 'Jane', 'Smith', 'jane.smith@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PM'),
    ('pd002', 'Michael', 'Johnson', 'michael.johnson@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PD'),
    ('pm002', 'Emily', 'Davis', 'emily.davis@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PM');

SELECT * FROM users;

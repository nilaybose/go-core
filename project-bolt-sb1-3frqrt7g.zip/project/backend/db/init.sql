-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Create user roles enum type
CREATE TYPE user_role AS ENUM ('PD', 'PM');

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(50) PRIMARY KEY,
    firstname VARCHAR(100) NOT NULL,
    lastname VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for efficient lookups
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Insert test users (password for both is 'password123')
INSERT INTO users (user_id, firstname, lastname, email, password_hash, role)
VALUES
    ('pd001', 'John', 'Doe', 'john.doe@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PD'),
    ('pm001', 'Jane', 'Smith', 'jane.smith@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PM')
ON CONFLICT (user_id) DO NOTHING;

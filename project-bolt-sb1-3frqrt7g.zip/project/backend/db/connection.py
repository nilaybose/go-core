import psycopg2
from psycopg2 import pool
from config.settings import settings
from typing import Optional

class DatabaseConnection:
    _connection_pool: Optional[pool.SimpleConnectionPool] = None

    @classmethod
    def get_pool(cls):
        if cls._connection_pool is None:
            cls._connection_pool = psycopg2.pool.SimpleConnectionPool(
                1,
                20,
                settings.database_url
            )
        return cls._connection_pool

    @classmethod
    def get_connection(cls):
        pool = cls.get_pool()
        return pool.getconn()

    @classmethod
    def return_connection(cls, connection):
        pool = cls.get_pool()
        pool.putconn(connection)

    @classmethod
    def close_all_connections(cls):
        if cls._connection_pool is not None:
            cls._connection_pool.closeall()

def get_db_connection():
    return DatabaseConnection.get_connection()

/*
  # Demo Data for Codeless Workflow System

  This file contains comprehensive test/demo data for all tables.
  Run this after schema.sql to populate the database with realistic demo data.

  Contents:
  1. Demo Users (PM and PD roles)
  2. System Prompts (for AI operations)
  3. Contents (sample file uploads)
  4. Recon Specs (reconciliation configurations)
  5. Workflow Instances (multiple workflows in different states)
  6. Workflow Tasks (tasks for all workflows)
*/

-- =====================================================
-- 1. DEMO USERS
-- =====================================================

-- Password for all demo users: "password123"
-- Hash generated with bcrypt (rounds=10)

INSERT INTO users (user_id, firstname, lastname, email, password_hash, role, created_at, updated_at)
VALUES
  ('admin', 'Admin', 'User', 'admin@codeless.com', '$2b$10$rZ5N5H5vK7xO8pZGJ5mYXOqKqH8hFqxK1h5vZ5N5H5vK7xO8pZGJ5', 'PM', now() - interval '90 days', now()),
  ('john_pm', 'John', 'Smith', 'john.smith@codeless.com', '$2b$10$rZ5N5H5vK7xO8pZGJ5mYXOqKqH8hFqxK1h5vZ5N5H5vK7xO8pZGJ5', 'PM', now() - interval '60 days', now()),
  ('sarah_pm', 'Sarah', 'Johnson', 'sarah.johnson@codeless.com', '$2b$10$rZ5N5H5vK7xO8pZGJ5mYXOqKqH8hFqxK1h5vZ5N5H5vK7xO8pZGJ5', 'PM', now() - interval '45 days', now()),
  ('mike_pd', 'Mike', 'Chen', 'mike.chen@codeless.com', '$2b$10$rZ5N5H5vK7xO8pZGJ5mYXOqKqH8hFqxK1h5vZ5N5H5vK7xO8pZGJ5', 'PD', now() - interval '30 days', now()),
  ('emma_pd', 'Emma', 'Davis', 'emma.davis@codeless.com', '$2b$10$rZ5N5H5vK7xO8pZGJ5mYXOqKqH8hFqxK1h5vZ5N5H5vK7xO8pZGJ5', 'PD', now() - interval '25 days', now())
ON CONFLICT (user_id) DO NOTHING;

-- =====================================================
-- 2. SYSTEM PROMPTS
-- =====================================================

INSERT INTO system_prompts (id, name, prompt, created_by, created_at, updated_at, updated_by)
VALUES
  (
    '10000000-0000-0000-0000-000000000001',
    'Schema Mapping Assistant',
    'You are an expert data migration specialist. Analyze the source and target schemas provided and create accurate field mappings. Consider data types, null constraints, and business logic requirements. Provide detailed mapping recommendations with justification for each field.',
    'admin',
    now() - interval '60 days',
    now() - interval '60 days',
    'admin'
  ),
  (
    '10000000-0000-0000-0000-000000000002',
    'Auto Mapping Generator',
    'Generate automated data mappings based on field names, data types, and semantic similarity. Use fuzzy matching to identify corresponding fields across schemas. Highlight fields requiring manual review and provide confidence scores for each mapping.',
    'admin',
    now() - interval '55 days',
    now() - interval '30 days',
    'john_pm'
  ),
  (
    '10000000-0000-0000-0000-000000000003',
    'Code Generation Assistant',
    'Generate production-ready ETL code based on approved data mappings. Include error handling, logging, data validation, and transformation logic. Follow best practices for performance and maintainability. Support multiple output formats: Python, SQL, and Spark.',
    'john_pm',
    now() - interval '50 days',
    now() - interval '50 days',
    'john_pm'
  ),
  (
    '10000000-0000-0000-0000-000000000004',
    'Data Quality Validator',
    'Validate data quality across source and target systems. Check for completeness, accuracy, consistency, and timeliness. Generate comprehensive data quality reports with actionable recommendations.',
    'sarah_pm',
    now() - interval '40 days',
    now() - interval '15 days',
    'sarah_pm'
  ),
  (
    '10000000-0000-0000-0000-000000000005',
    'Ticket Documentation Generator',
    'Create detailed JIRA tickets for data migration tasks. Include acceptance criteria, test cases, dependencies, and rollback procedures. Format output in markdown with clear sections and prioritization.',
    'sarah_pm',
    now() - interval '35 days',
    now() - interval '35 days',
    'sarah_pm'
  )
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- 3. CONTENTS (File Uploads)
-- =====================================================

INSERT INTO contents (content_id, content_name, file_name, blob_data, metadata, date_created, user_uploaded, status)
VALUES
  (
    '20000000-0000-0000-0000-000000000001',
    'Customer Database Schema',
    'customer_schema_v2.xlsx',
    'BASE64_ENCODED_FILE_DATA_PLACEHOLDER',
    '{"file_size": "2.3 MB", "sheet_count": 5, "total_fields": 127, "source_system": "Oracle DB"}'::jsonb,
    now() - interval '10 days',
    'john_pm',
    'completed'
  ),
  (
    '20000000-0000-0000-0000-000000000002',
    'Product Catalog Schema',
    'product_catalog_schema.csv',
    'BASE64_ENCODED_FILE_DATA_PLACEHOLDER',
    '{"file_size": "1.1 MB", "row_count": 5420, "columns": 23, "source_system": "PostgreSQL"}'::jsonb,
    now() - interval '8 days',
    'john_pm',
    'completed'
  ),
  (
    '20000000-0000-0000-0000-000000000003',
    'Order History Schema',
    'order_history_dump.json',
    'BASE64_ENCODED_FILE_DATA_PLACEHOLDER',
    '{"file_size": "5.7 MB", "record_count": 12500, "date_range": "2020-2024", "source_system": "MongoDB"}'::jsonb,
    now() - interval '5 days',
    'sarah_pm',
    'in_process'
  ),
  (
    '20000000-0000-0000-0000-000000000004',
    'Legacy User Data',
    'legacy_users_export.xlsx',
    'BASE64_ENCODED_FILE_DATA_PLACEHOLDER',
    '{"file_size": "3.2 MB", "user_count": 45000, "last_updated": "2024-09-15", "source_system": "SQL Server"}'::jsonb,
    now() - interval '3 days',
    'sarah_pm',
    'in_process'
  ),
  (
    '20000000-0000-0000-0000-000000000005',
    'Transaction Logs',
    'transaction_logs_2024.csv',
    'BASE64_ENCODED_FILE_DATA_PLACEHOLDER',
    '{"file_size": "12.4 MB", "transaction_count": 250000, "date_range": "2024-01 to 2024-10", "source_system": "MySQL"}'::jsonb,
    now() - interval '1 day',
    'john_pm',
    'in_process'
  )
ON CONFLICT (content_id) DO NOTHING;

-- =====================================================
-- 4. RECON SPECS (Reconciliation Configurations)
-- =====================================================

INSERT INTO recon_specs (id, name, json_content, date_created, date_modified, last_updated_by)
VALUES
  (
    '30000000-0000-0000-0000-000000000001',
    'Customer Data Recon Spec',
    '{
      "source": {"system": "Oracle", "table": "CUSTOMERS", "key_fields": ["customer_id"]},
      "target": {"system": "PostgreSQL", "table": "customers", "key_fields": ["id"]},
      "rules": [
        {"field": "customer_id", "validation": "not_null", "transform": "uppercase"},
        {"field": "email", "validation": "email_format", "transform": "lowercase"},
        {"field": "created_date", "validation": "date_range", "params": {"min": "2010-01-01"}}
      ],
      "thresholds": {"error_rate": 0.01, "null_rate": 0.05}
    }'::jsonb,
    now() - interval '15 days',
    now() - interval '10 days',
    'john_pm'
  ),
  (
    '30000000-0000-0000-0000-000000000002',
    'Product Catalog Recon Spec',
    '{
      "source": {"system": "PostgreSQL", "table": "products", "key_fields": ["product_code"]},
      "target": {"system": "Snowflake", "table": "dim_products", "key_fields": ["product_key"]},
      "rules": [
        {"field": "price", "validation": "positive_number", "transform": "round_2_decimals"},
        {"field": "category", "validation": "in_list", "params": {"values": ["electronics", "clothing", "home", "sports"]}},
        {"field": "status", "validation": "not_null", "transform": "uppercase"}
      ],
      "thresholds": {"error_rate": 0.005, "null_rate": 0.02}
    }'::jsonb,
    now() - interval '12 days',
    now() - interval '8 days',
    'sarah_pm'
  ),
  (
    '30000000-0000-0000-0000-000000000003',
    'Order History Recon Spec',
    '{
      "source": {"system": "MongoDB", "collection": "orders", "key_fields": ["order_id"]},
      "target": {"system": "BigQuery", "table": "fact_orders", "key_fields": ["order_key"]},
      "rules": [
        {"field": "order_total", "validation": "positive_number", "transform": "round_2_decimals"},
        {"field": "order_date", "validation": "date_format", "params": {"format": "YYYY-MM-DD"}},
        {"field": "customer_id", "validation": "foreign_key", "params": {"ref_table": "customers"}}
      ],
      "thresholds": {"error_rate": 0.001, "null_rate": 0.01}
    }'::jsonb,
    now() - interval '8 days',
    now() - interval '5 days',
    'sarah_pm'
  )
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- 5. WORKFLOW INSTANCES
-- =====================================================

-- Workflow 1: Customer Data Migration (In Progress - Demo)
INSERT INTO workflow_instance (id, name, processor_name, status, start_datetime, end_datetime, initiated_user, status_note, created_at, updated_at)
VALUES
  (
    '11111111-1111-1111-1111-111111111111',
    'Customer Data Migration',
    'ETL_Processor_v2',
    'in_progress',
    now() - interval '2 days',
    NULL,
    'admin',
    'Initial workflow created for customer data migration project',
    now() - interval '2 days',
    now()
  ),
  (
    '11111111-1111-1111-1111-111111111112',
    'Product Catalog Migration',
    'ETL_Processor_v2',
    'completed',
    now() - interval '15 days',
    now() - interval '8 days',
    'john_pm',
    'Successfully migrated 5,420 product records with 99.8% accuracy',
    now() - interval '15 days',
    now() - interval '8 days'
  ),
  (
    '11111111-1111-1111-1111-111111111113',
    'Order History Archive',
    'Data_Archive_v1',
    'in_progress',
    now() - interval '5 days',
    NULL,
    'sarah_pm',
    'Archiving historical order data to cold storage',
    now() - interval '5 days',
    now() - interval '1 day'
  ),
  (
    '11111111-1111-1111-1111-111111111114',
    'Legacy User Migration',
    'User_Migration_v3',
    'pending',
    now() - interval '1 day',
    NULL,
    'sarah_pm',
    'Awaiting approval from compliance team before proceeding',
    now() - interval '1 day',
    now() - interval '1 day'
  )
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- 6. WORKFLOW TASKS
-- =====================================================

-- Tasks for Workflow 1: Customer Data Migration (Demo Workflow - Mixed States)
INSERT INTO workflow_task (id, workflow_id, task_name, seq_order, status, artifact_mandatory, role_assigned, start_datetime, end_datetime, remarks, status_note, last_modified_by, created_at, updated_at)
VALUES
  -- Completed tasks
  (
    '22222222-2222-2222-2222-222222222221',
    '11111111-1111-1111-1111-111111111111',
    'Schema Mapping',
    1,
    'completed',
    true,
    'PM',
    now() - interval '2 days',
    now() - interval '1 day 18 hours',
    'Mapped all customer fields from legacy Oracle system to new PostgreSQL schema. Identified 127 source fields mapping to 98 target fields.',
    'Schema mapping completed successfully. All fields validated and documented in mapping spreadsheet.',
    'admin',
    now() - interval '2 days',
    now() - interval '1 day 18 hours'
  ),
  (
    '22222222-2222-2222-2222-222222222222',
    '11111111-1111-1111-1111-111111111111',
    'Auto Mapping',
    2,
    'completed',
    true,
    'PM',
    now() - interval '1 day 18 hours',
    now() - interval '1 day 12 hours',
    'AI-generated mappings achieved 95% confidence match rate. Manual review completed for 12 edge cases with custom transformation logic.',
    'Auto mapping completed. Generated transformation rules validated and approved by data team.',
    'admin',
    now() - interval '2 days',
    now() - interval '1 day 12 hours'
  ),
  -- Current task (in_process)
  (
    '22222222-2222-2222-2222-222222222223',
    '11111111-1111-1111-1111-111111111111',
    'Commit Mapping',
    3,
    'in_process',
    true,
    'PM',
    now() - interval '1 day 12 hours',
    NULL,
    'Currently reviewing final mapping configurations before commit to version control. Conducting peer review with senior data architects.',
    'Started review process. Expected completion within 24 hours pending final approval from lead architect.',
    'admin',
    now() - interval '2 days',
    now() - interval '1 day 12 hours'
  ),
  -- Pending tasks
  (
    '22222222-2222-2222-2222-222222222224',
    '11111111-1111-1111-1111-111111111111',
    'Code Generation',
    4,
    'pending',
    false,
    'PD',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '2 days',
    now() - interval '2 days'
  ),
  (
    '22222222-2222-2222-2222-222222222225',
    '11111111-1111-1111-1111-111111111111',
    'Ticket Creation',
    5,
    'pending',
    false,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '2 days',
    now() - interval '2 days'
  ),
  (
    '22222222-2222-2222-2222-222222222226',
    '11111111-1111-1111-1111-111111111111',
    'Signoff',
    6,
    'pending',
    false,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '2 days',
    now() - interval '2 days'
  )
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Tasks for Workflow 2: Product Catalog Migration (All Completed)
INSERT INTO workflow_task (id, workflow_id, task_name, seq_order, status, artifact_mandatory, role_assigned, start_datetime, end_datetime, remarks, status_note, last_modified_by, created_at, updated_at)
VALUES
  (
    '22222222-2222-2222-2222-222222222231',
    '11111111-1111-1111-1111-111111111112',
    'Schema Mapping',
    1,
    'completed',
    true,
    'PM',
    now() - interval '15 days',
    now() - interval '14 days',
    'Product schema mapping completed with 23 fields mapped across categories.',
    'Mapping verified against business requirements document.',
    'john_pm',
    now() - interval '15 days',
    now() - interval '14 days'
  ),
  (
    '22222222-2222-2222-2222-222222222232',
    '11111111-1111-1111-1111-111111111112',
    'Auto Mapping',
    2,
    'completed',
    true,
    'PM',
    now() - interval '14 days',
    now() - interval '13 days',
    'Auto mapping performed with 98% accuracy.',
    'High confidence mappings approved. Minimal manual intervention required.',
    'john_pm',
    now() - interval '15 days',
    now() - interval '13 days'
  ),
  (
    '22222222-2222-2222-2222-222222222233',
    '11111111-1111-1111-1111-111111111112',
    'Commit Mapping',
    3,
    'completed',
    true,
    'PM',
    now() - interval '13 days',
    now() - interval '12 days',
    'Final mappings committed to repository with version tag v2.1.',
    'Peer review completed. All reviewers approved.',
    'john_pm',
    now() - interval '15 days',
    now() - interval '12 days'
  ),
  (
    '22222222-2222-2222-2222-222222222234',
    '11111111-1111-1111-1111-111111111112',
    'Code Generation',
    4,
    'completed',
    false,
    'PD',
    now() - interval '12 days',
    now() - interval '10 days',
    'ETL code generated and tested in development environment.',
    'Generated Python/PySpark code with comprehensive error handling.',
    'mike_pd',
    now() - interval '15 days',
    now() - interval '10 days'
  ),
  (
    '22222222-2222-2222-2222-222222222235',
    '11111111-1111-1111-1111-111111111112',
    'Ticket Creation',
    5,
    'completed',
    false,
    'PM',
    now() - interval '10 days',
    now() - interval '9 days',
    'Created 8 JIRA tickets for deployment and validation tasks.',
    'All tickets assigned and prioritized. Sprint planning complete.',
    'john_pm',
    now() - interval '15 days',
    now() - interval '9 days'
  ),
  (
    '22222222-2222-2222-2222-222222222236',
    '11111111-1111-1111-1111-111111111112',
    'Signoff',
    6,
    'completed',
    false,
    'PM',
    now() - interval '9 days',
    now() - interval '8 days',
    'Final signoff received from product owner and data governance team.',
    'Migration approved for production deployment. All acceptance criteria met.',
    'john_pm',
    now() - interval '15 days',
    now() - interval '8 days'
  )
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Tasks for Workflow 3: Order History Archive (Partially Completed)
INSERT INTO workflow_task (id, workflow_id, task_name, seq_order, status, artifact_mandatory, role_assigned, start_datetime, end_datetime, remarks, status_note, last_modified_by, created_at, updated_at)
VALUES
  (
    '22222222-2222-2222-2222-222222222241',
    '11111111-1111-1111-1111-111111111113',
    'Schema Mapping',
    1,
    'completed',
    true,
    'PM',
    now() - interval '5 days',
    now() - interval '4 days',
    'Archive schema defined for 12,500 historical order records.',
    'Schema mapping complete. Compression strategy approved.',
    'sarah_pm',
    now() - interval '5 days',
    now() - interval '4 days'
  ),
  (
    '22222222-2222-2222-2222-222222222242',
    '11111111-1111-1111-1111-111111111113',
    'Auto Mapping',
    2,
    'completed',
    true,
    'PM',
    now() - interval '4 days',
    now() - interval '3 days',
    'Automated field mapping for archive format conversion.',
    'Mapping rules generated and validated against sample data.',
    'sarah_pm',
    now() - interval '5 days',
    now() - interval '3 days'
  ),
  (
    '22222222-2222-2222-2222-222222222243',
    '11111111-1111-1111-1111-111111111113',
    'Commit Mapping',
    3,
    'in_process',
    true,
    'PM',
    now() - interval '3 days',
    NULL,
    'Finalizing archive configuration and retention policies.',
    'Awaiting legal review of data retention compliance requirements.',
    'sarah_pm',
    now() - interval '5 days',
    now() - interval '2 days'
  ),
  (
    '22222222-2222-2222-2222-222222222244',
    '11111111-1111-1111-1111-111111111113',
    'Code Generation',
    4,
    'pending',
    false,
    'PD',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '5 days',
    now() - interval '5 days'
  ),
  (
    '22222222-2222-2222-2222-222222222245',
    '11111111-1111-1111-1111-111111111113',
    'Ticket Creation',
    5,
    'pending',
    false,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '5 days',
    now() - interval '5 days'
  ),
  (
    '22222222-2222-2222-2222-222222222246',
    '11111111-1111-1111-1111-111111111113',
    'Signoff',
    6,
    'pending',
    false,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '5 days',
    now() - interval '5 days'
  )
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Tasks for Workflow 4: Legacy User Migration (All Pending)
INSERT INTO workflow_task (id, workflow_id, task_name, seq_order, status, artifact_mandatory, role_assigned, start_datetime, end_datetime, remarks, status_note, last_modified_by, created_at, updated_at)
VALUES
  (
    '22222222-2222-2222-2222-222222222251',
    '11111111-1111-1111-1111-111111111114',
    'Schema Mapping',
    1,
    'pending',
    true,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '1 day',
    now() - interval '1 day'
  ),
  (
    '22222222-2222-2222-2222-222222222252',
    '11111111-1111-1111-1111-111111111114',
    'Auto Mapping',
    2,
    'pending',
    true,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '1 day',
    now() - interval '1 day'
  ),
  (
    '22222222-2222-2222-2222-222222222253',
    '11111111-1111-1111-1111-111111111114',
    'Commit Mapping',
    3,
    'pending',
    true,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '1 day',
    now() - interval '1 day'
  ),
  (
    '22222222-2222-2222-2222-222222222254',
    '11111111-1111-1111-1111-111111111114',
    'Code Generation',
    4,
    'pending',
    false,
    'PD',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '1 day',
    now() - interval '1 day'
  ),
  (
    '22222222-2222-2222-2222-222222222255',
    '11111111-1111-1111-1111-111111111114',
    'Ticket Creation',
    5,
    'pending',
    false,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '1 day',
    now() - interval '1 day'
  ),
  (
    '22222222-2222-2222-2222-222222222256',
    '11111111-1111-1111-1111-111111111114',
    'Signoff',
    6,
    'pending',
    false,
    'PM',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    now() - interval '1 day',
    now() - interval '1 day'
  )
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- =====================================================
-- SUMMARY
-- =====================================================

/*
Demo Data Summary:
- 5 Users (2 PM, 2 PD, 1 Admin)
- 5 System Prompts (for various AI tasks)
- 5 Content Files (various file types and statuses)
- 3 Recon Specs (reconciliation configurations)
- 4 Workflows in different states:
  * Customer Data Migration: in_progress (3/6 tasks complete)
  * Product Catalog Migration: completed (all tasks done)
  * Order History Archive: in_progress (2/6 tasks complete)
  * Legacy User Migration: pending (no tasks started)
- 24 Total Tasks across all workflows

Test Credentials:
- Email: admin@codeless.com, Password: password123
- Email: john.smith@codeless.com, Password: password123
- Email: sarah.johnson@codeless.com, Password: password123
- Email: mike.chen@codeless.com, Password: password123
- Email: emma.davis@codeless.com, Password: password123
*/

from typing import Dict, Any, Optional
from uuid import UUID
from datetime import datetime
import psycopg2.extras
from db.connection import get_db_connection, DatabaseConnection
from tasks.task_definitions import get_all_task_definitions

def create_workflow_with_tasks(
    name: str,
    processor_name: str,
    user_id: str,
    conn=None
) -> Dict[str, Any]:
    """Create a workflow and automatically generate all tasks"""
    own_conn = conn is None
    if own_conn:
        conn = get_db_connection()

    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            INSERT INTO workflow_instance (name, processor_name, initiated_user, status)
            VALUES (%s, %s, %s, 'pending')
            RETURNING id, name, processor_name, status, start_datetime, end_datetime,
                      initiated_user, status_note, created_at, updated_at
        """, (name, processor_name, user_id))

        workflow = cursor.fetchone()
        workflow_id = workflow['id']

        task_definitions = get_all_task_definitions()
        tasks = []

        for task_def in task_definitions:
            cursor.execute("""
                INSERT INTO workflow_task (
                    workflow_id, task_name, seq_order, status,
                    artifact_mandatory, role_assigned
                )
                VALUES (%s, %s, %s, 'pending', %s, %s)
                RETURNING id, workflow_id, task_name, seq_order, status,
                          artifact_mandatory, role_assigned, start_datetime,
                          end_datetime, remarks, status_note, last_modified_by,
                          created_at, updated_at
            """, (
                workflow_id,
                task_def.name,
                task_def.seq_order,
                task_def.artifact_mandatory,
                task_def.role_assigned
            ))

            task = cursor.fetchone()
            tasks.append(dict(task))

        if own_conn:
            conn.commit()

        cursor.close()

        workflow_dict = dict(workflow)
        workflow_dict['tasks'] = tasks
        workflow_dict['can_complete'] = False

        return workflow_dict

    except Exception as e:
        if own_conn and conn:
            conn.rollback()
        raise e
    finally:
        if own_conn and conn:
            DatabaseConnection.return_connection(conn)

def update_workflow_status(
    workflow_id: UUID,
    new_status: str,
    status_note: str,
    user_id: str,
    user_role: str
) -> Dict[str, Any]:
    """Update workflow status with validation"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        if new_status == 'cancelled' and user_role != 'PM':
            raise ValueError("Only PM users can cancel workflows")

        if new_status == 'completed':
            cursor.execute("""
                SELECT COUNT(*) as incomplete_count
                FROM workflow_task
                WHERE workflow_id = %s AND status != 'completed'
            """, (str(workflow_id),))

            result = cursor.fetchone()
            if result['incomplete_count'] > 0:
                raise ValueError("Cannot complete workflow with incomplete tasks")

        end_datetime = None
        if new_status in ['completed', 'cancelled']:
            end_datetime = datetime.now()

        cursor.execute("""
            UPDATE workflow_instance
            SET status = %s, status_note = %s, end_datetime = %s, updated_at = now()
            WHERE id = %s
            RETURNING id, name, processor_name, status, start_datetime, end_datetime,
                      initiated_user, status_note, created_at, updated_at
        """, (new_status, status_note, end_datetime, str(workflow_id)))

        updated_workflow = cursor.fetchone()

        if not updated_workflow:
            raise ValueError("Workflow not found")

        conn.commit()
        cursor.close()

        return dict(updated_workflow)

    except Exception as e:
        if conn:
            conn.rollback()
        raise e
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

def get_workflow_with_tasks(workflow_id: UUID) -> Optional[Dict[str, Any]]:
    """Get a workflow with all its tasks"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT id, name, processor_name, status, start_datetime, end_datetime,
                   initiated_user, status_note, created_at, updated_at
            FROM workflow_instance
            WHERE id = %s
        """, (str(workflow_id),))

        workflow = cursor.fetchone()

        if not workflow:
            return None

        cursor.execute("""
            SELECT id, workflow_id, task_name, seq_order, status,
                   artifact_mandatory, role_assigned, start_datetime,
                   end_datetime, remarks, status_note, last_modified_by,
                   created_at, updated_at
            FROM workflow_task
            WHERE workflow_id = %s
            ORDER BY seq_order
        """, (str(workflow_id),))

        tasks = cursor.fetchall()
        cursor.close()

        workflow_dict = dict(workflow)
        workflow_dict['tasks'] = [dict(task) for task in tasks]

        all_completed = all(task['status'] == 'completed' for task in tasks)
        workflow_dict['can_complete'] = all_completed

        return workflow_dict

    except Exception as e:
        raise e
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

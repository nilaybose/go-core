from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from uuid import UUID
from models.workflow import (
    WorkflowCreate, WorkflowResponse, WorkflowDetailResponse,
    WorkflowStatusUpdate
)
from middleware.auth_middleware import get_current_user_from_session
from middleware.role_middleware import require_pm_role
from workflows.workflow_service import (
    create_workflow_with_tasks,
    update_workflow_status,
    get_workflow_with_tasks
)
from db.connection import get_db_connection, DatabaseConnection
import psycopg2.extras

router = APIRouter(prefix="/api/workflows", tags=["workflows"])

@router.get("", response_model=List[WorkflowResponse])
async def get_workflows(
    name: Optional[str] = Query(None, description="Filter by workflow name"),
    status: Optional[str] = Query(None, description="Filter by status"),
    processor_name: Optional[str] = Query(None, description="Filter by processor name"),
    role: Optional[str] = Query(None, description="Filter by user role (shows workflows with pending tasks)"),
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get all workflows with optional filters"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        query = """
            SELECT DISTINCT wi.id, wi.name, wi.processor_name, wi.status,
                   wi.start_datetime, wi.end_datetime, wi.initiated_user,
                   wi.status_note, wi.created_at, wi.updated_at
            FROM workflow_instance wi
        """

        conditions = []
        params = []

        if role:
            query += """
                LEFT JOIN workflow_task wt ON wi.id = wt.workflow_id
            """
            conditions.append("wt.role_assigned = %s")
            conditions.append("wt.status IN ('pending', 'in_process')")
            conditions.append("wi.status != 'cancelled'")
            params.append(role)

        if name:
            conditions.append("wi.name ILIKE %s")
            params.append(f'%{name}%')

        if status:
            conditions.append("wi.status = %s")
            params.append(status)

        if processor_name:
            conditions.append("wi.processor_name ILIKE %s")
            params.append(f'%{processor_name}%')

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY wi.created_at DESC"

        cursor.execute(query, tuple(params))
        workflows = cursor.fetchall()
        cursor.close()

        return [dict(workflow) for workflow in workflows]

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/notifications/count")
async def get_notification_count(
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get count of workflows with pending tasks for user's role"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        user_role = current_user.get('role')

        cursor.execute("""
            SELECT COUNT(DISTINCT wi.id) as count
            FROM workflow_instance wi
            JOIN workflow_task wt ON wi.id = wt.workflow_id
            WHERE wt.role_assigned = %s
              AND wt.status IN ('pending', 'in_process')
              AND wi.status != 'cancelled'
        """, (user_role,))

        result = cursor.fetchone()
        cursor.close()

        return {"count": result['count'], "role": user_role}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/{workflow_id}", response_model=WorkflowDetailResponse)
async def get_workflow(
    workflow_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get a specific workflow with all tasks"""
    try:
        workflow = get_workflow_with_tasks(workflow_id)

        if not workflow:
            raise HTTPException(status_code=404, detail="Workflow not found")

        return workflow

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@router.post("", response_model=WorkflowDetailResponse, status_code=201)
async def create_workflow(
    workflow_data: WorkflowCreate,
    current_user: dict = Depends(require_pm_role)
):
    """Create a new workflow with auto-generated tasks - PM role only"""
    try:
        workflow = create_workflow_with_tasks(
            name=workflow_data.name,
            processor_name=workflow_data.processor_name,
            user_id=current_user['user_id']
        )

        return workflow

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating workflow: {str(e)}")

@router.patch("/{workflow_id}/status", response_model=WorkflowResponse)
async def update_workflow_status_route(
    workflow_id: UUID,
    status_update: WorkflowStatusUpdate,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Update workflow status with required note"""
    try:
        updated_workflow = update_workflow_status(
            workflow_id=workflow_id,
            new_status=status_update.status,
            status_note=status_update.status_note,
            user_id=current_user['user_id'],
            user_role=current_user['role']
        )

        return updated_workflow

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

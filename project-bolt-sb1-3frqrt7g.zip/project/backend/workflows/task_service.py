from typing import Dict, Any
from uuid import UUID
from datetime import datetime
import psycopg2.extras
from db.connection import get_db_connection, DatabaseConnection

def update_task_status(
    task_id: UUID,
    new_status: str,
    status_note: str,
    user_id: str,
    user_role: str
) -> Dict[str, Any]:
    """Update task status with validation"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT wt.*, wi.status as workflow_status
            FROM workflow_task wt
            JOIN workflow_instance wi ON wt.workflow_id = wi.id
            WHERE wt.id = %s
        """, (str(task_id),))

        task = cursor.fetchone()

        if not task:
            raise ValueError("Task not found")

        if task['workflow_status'] == 'cancelled':
            raise ValueError("Cannot update tasks in cancelled workflows")

        if task['role_assigned'] != user_role:
            raise ValueError(f"Only {task['role_assigned']} users can update this task")

        if task['status'] == 'pending' and new_status == 'in_process':
            if task['seq_order'] > 1:
                cursor.execute("""
                    SELECT status FROM workflow_task
                    WHERE workflow_id = %s AND seq_order = %s
                """, (task['workflow_id'], task['seq_order'] - 1))

                prev_task = cursor.fetchone()
                if not prev_task or prev_task['status'] != 'completed':
                    raise ValueError("Previous task must be completed first")

        start_datetime = task['start_datetime']
        end_datetime = task['end_datetime']

        if task['status'] == 'pending' and new_status == 'in_process':
            start_datetime = datetime.now()

            cursor.execute("""
                UPDATE workflow_instance
                SET status = 'in_progress', updated_at = now()
                WHERE id = %s AND status = 'pending'
            """, (task['workflow_id'],))

        if new_status == 'completed':
            end_datetime = datetime.now()

        cursor.execute("""
            UPDATE workflow_task
            SET status = %s, status_note = %s, start_datetime = %s,
                end_datetime = %s, last_modified_by = %s, updated_at = now()
            WHERE id = %s
            RETURNING id, workflow_id, task_name, seq_order, status,
                      artifact_mandatory, role_assigned, start_datetime,
                      end_datetime, remarks, status_note, last_modified_by,
                      created_at, updated_at
        """, (new_status, status_note, start_datetime, end_datetime, user_id, str(task_id)))

        updated_task = cursor.fetchone()

        conn.commit()
        cursor.close()

        return dict(updated_task)

    except Exception as e:
        if conn:
            conn.rollback()
        raise e
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

def get_task_by_id(task_id: UUID) -> Dict[str, Any]:
    """Get a single task by ID"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT id, workflow_id, task_name, seq_order, status,
                   artifact_mandatory, role_assigned, start_datetime,
                   end_datetime, remarks, status_note, last_modified_by,
                   created_at, updated_at
            FROM workflow_task
            WHERE id = %s
        """, (str(task_id),))

        task = cursor.fetchone()
        cursor.close()

        if not task:
            raise ValueError("Task not found")

        return dict(task)

    except Exception as e:
        raise e
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

def update_task_remarks(task_id: UUID, remarks: str, user_id: str, user_role: str) -> Dict[str, Any]:
    """Update task remarks"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT role_assigned FROM workflow_task WHERE id = %s
        """, (str(task_id),))

        task = cursor.fetchone()

        if not task:
            raise ValueError("Task not found")

        if task['role_assigned'] != user_role:
            raise ValueError(f"Only {task['role_assigned']} users can update this task")

        cursor.execute("""
            UPDATE workflow_task
            SET remarks = %s, last_modified_by = %s, updated_at = now()
            WHERE id = %s
            RETURNING id, workflow_id, task_name, seq_order, status,
                      artifact_mandatory, role_assigned, start_datetime,
                      end_datetime, remarks, status_note, last_modified_by,
                      created_at, updated_at
        """, (remarks, user_id, str(task_id)))

        updated_task = cursor.fetchone()

        conn.commit()
        cursor.close()

        return dict(updated_task)

    except Exception as e:
        if conn:
            conn.rollback()
        raise e
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

from fastapi import APIRouter, HTTPException, Depends
from typing import List
from uuid import UUID
from models.workflow import TaskResponse, TaskStatusUpdate, TaskUpdate
from middleware.auth_middleware import get_current_user_from_session
from workflows.task_service import (
    update_task_status,
    get_task_by_id,
    update_task_remarks
)
from db.connection import get_db_connection, DatabaseConnection
import psycopg2.extras

router = APIRouter(prefix="/api", tags=["tasks"])

@router.get("/workflows/{workflow_id}/tasks", response_model=List[TaskResponse])
async def get_workflow_tasks(
    workflow_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get all tasks for a workflow"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT id, workflow_id, task_name, seq_order, status,
                   artifact_mandatory, role_assigned, start_datetime,
                   end_datetime, remarks, status_note, last_modified_by,
                   created_at, updated_at
            FROM workflow_task
            WHERE workflow_id = %s
            ORDER BY seq_order
        """, (str(workflow_id),))

        tasks = cursor.fetchall()
        cursor.close()

        return [dict(task) for task in tasks]

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

@router.get("/tasks/{task_id}", response_model=TaskResponse)
async def get_task(
    task_id: UUID,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Get a single task by ID"""
    try:
        task = get_task_by_id(task_id)
        return task

    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@router.patch("/tasks/{task_id}/status", response_model=TaskResponse)
async def update_task_status_route(
    task_id: UUID,
    status_update: TaskStatusUpdate,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Update task status with required note"""
    try:
        updated_task = update_task_status(
            task_id=task_id,
            new_status=status_update.status,
            status_note=status_update.status_note,
            user_id=current_user['user_id'],
            user_role=current_user['role']
        )

        return updated_task

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@router.patch("/tasks/{task_id}/remarks", response_model=TaskResponse)
async def update_task_remarks_route(
    task_id: UUID,
    task_update: TaskUpdate,
    current_user: dict = Depends(get_current_user_from_session)
):
    """Update task remarks"""
    try:
        updated_task = update_task_remarks(
            task_id=task_id,
            remarks=task_update.remarks or "",
            user_id=current_user['user_id'],
            user_role=current_user['role']
        )

        return updated_task

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

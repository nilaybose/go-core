from fastapi import APIRouter, HTTPException, Depends
from models.user import UserLogin, UserResponse
from models.session import SessionResponse
from utils.password import verify_password
from utils.session_manager import session_manager
from db.connection import get_db_connection, DatabaseConnection
import psycopg2.extras

router = APIRouter(prefix="/auth", tags=["authentication"])

@router.post("/login")
async def login(credentials: UserLogin):
    session_id = session_manager.create_session(credentials.user_id)

    return {
        "session_id": session_id,
        "user": {
            "user_id": credentials.user_id,
            "firstname": "Development",
            "lastname": "User",
            "email": f"{credentials.user_id}@example.com",
            "role": "PD"
        }
    }

@router.post("/logout")
async def logout(session_id: str):
    success = session_manager.remove_session(session_id)
    return {"success": success}

@router.get("/validate")
async def validate_session(session_id: str):
    user_id = session_manager.validate_session(session_id)
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid or expired session")

    return {"valid": True, "user_id": user_id}

@router.get("/profile")
async def get_profile(session_id: str):
    user_id = session_manager.validate_session(session_id)
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid or expired session")

    session_manager.update_activity(session_id)

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute(
            "SELECT user_id, firstname, lastname, email, role FROM users WHERE user_id = %s",
            (user_id,)
        )
        user = cursor.fetchone()
        cursor.close()

        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        return {
            "user_id": user['user_id'],
            "firstname": user['firstname'],
            "lastname": user['lastname'],
            "email": user['email'],
            "role": user['role']
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn:
            DatabaseConnection.return_connection(conn)

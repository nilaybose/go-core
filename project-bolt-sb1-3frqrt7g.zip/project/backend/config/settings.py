from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    database_url: str = "postgresql://postgres:postgres@postgres:5432/codeless_workflow"
    session_timeout_minutes: int = 30

    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()

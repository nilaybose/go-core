/*
  # Add updated_by Column to System Prompts Table

  1. Changes
    - Add `updated_by` column (varchar) to `system_prompts` table
      - References users table via foreign key
      - Set to NULL by default for existing records
      - Automatically populated on UPDATE operations
    
  2. Indexes
    - Add index on `updated_by` for efficient queries
    
  3. Triggers
    - Update the trigger function to automatically set `updated_by` on updates
      - Create new trigger that captures the current user from session
    
  4. Important Notes
    - Existing records will have `updated_by` as NULL until their first update
    - Foreign key constraint uses ON DELETE SET NULL to handle user deletions
    - The `updated_by` field will be set programmatically by the backend API
*/

-- Add updated_by column to system_prompts table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'system_prompts' AND column_name = 'updated_by'
  ) THEN
    ALTER TABLE system_prompts ADD COLUMN updated_by VARCHAR(50) REFERENCES users(user_id) ON DELETE SET NULL;
  END IF;
END $$;

-- Create index for efficient queries on updated_by
CREATE INDEX IF NOT EXISTS idx_system_prompts_updated_by ON system_prompts(updated_by);

-- Add comment to document the column purpose
COMMENT ON COLUMN system_prompts.updated_by IS 'User ID of the person who last modified this system prompt';
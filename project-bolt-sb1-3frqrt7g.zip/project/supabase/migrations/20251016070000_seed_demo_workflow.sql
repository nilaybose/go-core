/*
  # Seed Demo Workflow for Testing

  1. Creates a demo workflow with all 6 tasks
    - Workflow: "Customer Data Migration"
    - Processor: "ETL_Processor_v2"
    - Status: in_progress
    - Initiated by: admin user

  2. Creates all 6 tasks in various states for demonstration
    - Schema Mapping: completed
    - Auto Mapping: completed
    - Commit Mapping: in_process
    - Code Generation: pending
    - Ticket Creation: pending
    - Signoff: pending

  3. Notes
    - Uses the existing admin user (user_id: 'admin')
    - Demonstrates the full workflow lifecycle
    - Can be used for testing and demo purposes
*/

-- Insert demo workflow
INSERT INTO workflow_instance (
  id,
  name,
  processor_name,
  status,
  start_datetime,
  initiated_user,
  status_note,
  created_at,
  updated_at
)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'Customer Data Migration',
  'ETL_Processor_v2',
  'in_progress',
  now() - interval '2 days',
  'admin',
  'Initial workflow created for customer data migration project',
  now() - interval '2 days',
  now()
)
ON CONFLICT (id) DO NOTHING;

-- Insert Task 1: Schema Mapping (completed)
INSERT INTO workflow_task (
  id,
  workflow_id,
  task_name,
  seq_order,
  status,
  artifact_mandatory,
  role_assigned,
  start_datetime,
  end_datetime,
  remarks,
  status_note,
  last_modified_by,
  created_at,
  updated_at
)
VALUES (
  '22222222-2222-2222-2222-222222222221',
  '11111111-1111-1111-1111-111111111111',
  'Schema Mapping',
  1,
  'completed',
  true,
  'PM',
  now() - interval '2 days',
  now() - interval '1 day 18 hours',
  'Mapped all customer fields from legacy system to new schema',
  'Schema mapping completed successfully. All fields validated and documented.',
  'admin',
  now() - interval '2 days',
  now() - interval '1 day 18 hours'
)
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Insert Task 2: Auto Mapping (completed)
INSERT INTO workflow_task (
  id,
  workflow_id,
  task_name,
  seq_order,
  status,
  artifact_mandatory,
  role_assigned,
  start_datetime,
  end_datetime,
  remarks,
  status_note,
  last_modified_by,
  created_at,
  updated_at
)
VALUES (
  '22222222-2222-2222-2222-222222222222',
  '11111111-1111-1111-1111-111111111111',
  'Auto Mapping',
  2,
  'completed',
  true,
  'PM',
  now() - interval '1 day 18 hours',
  now() - interval '1 day 12 hours',
  'AI-generated mappings reviewed and approved',
  'Auto mapping completed. 95% accuracy achieved, manual adjustments made for edge cases.',
  'admin',
  now() - interval '2 days',
  now() - interval '1 day 12 hours'
)
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Insert Task 3: Commit Mapping (in_process)
INSERT INTO workflow_task (
  id,
  workflow_id,
  task_name,
  seq_order,
  status,
  artifact_mandatory,
  role_assigned,
  start_datetime,
  end_datetime,
  remarks,
  status_note,
  last_modified_by,
  created_at,
  updated_at
)
VALUES (
  '22222222-2222-2222-2222-222222222223',
  '11111111-1111-1111-1111-111111111111',
  'Commit Mapping',
  3,
  'in_process',
  true,
  'PM',
  now() - interval '1 day 12 hours',
  NULL,
  'Currently reviewing final mapping configurations before commit',
  'Started review process. Expected completion within 24 hours.',
  'admin',
  now() - interval '2 days',
  now() - interval '1 day 12 hours'
)
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Insert Task 4: Code Generation (pending)
INSERT INTO workflow_task (
  id,
  workflow_id,
  task_name,
  seq_order,
  status,
  artifact_mandatory,
  role_assigned,
  start_datetime,
  end_datetime,
  remarks,
  status_note,
  last_modified_by,
  created_at,
  updated_at
)
VALUES (
  '22222222-2222-2222-2222-222222222224',
  '11111111-1111-1111-1111-111111111111',
  'Code Generation',
  4,
  'pending',
  false,
  'PD',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  now() - interval '2 days',
  now() - interval '2 days'
)
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Insert Task 5: Ticket Creation (pending)
INSERT INTO workflow_task (
  id,
  workflow_id,
  task_name,
  seq_order,
  status,
  artifact_mandatory,
  role_assigned,
  start_datetime,
  end_datetime,
  remarks,
  status_note,
  last_modified_by,
  created_at,
  updated_at
)
VALUES (
  '22222222-2222-2222-2222-222222222225',
  '11111111-1111-1111-1111-111111111111',
  'Ticket Creation',
  5,
  'pending',
  false,
  'PM',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  now() - interval '2 days',
  now() - interval '2 days'
)
ON CONFLICT (workflow_id, task_name) DO NOTHING;

-- Insert Task 6: Signoff (pending)
INSERT INTO workflow_task (
  id,
  workflow_id,
  task_name,
  seq_order,
  status,
  artifact_mandatory,
  role_assigned,
  start_datetime,
  end_datetime,
  remarks,
  status_note,
  last_modified_by,
  created_at,
  updated_at
)
VALUES (
  '22222222-2222-2222-2222-222222222226',
  '11111111-1111-1111-1111-111111111111',
  'Signoff',
  6,
  'pending',
  false,
  'PM',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  now() - interval '2 days',
  now() - interval '2 days'
)
ON CONFLICT (workflow_id, task_name) DO NOTHING;

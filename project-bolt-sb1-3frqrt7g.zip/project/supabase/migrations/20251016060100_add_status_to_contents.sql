/*
  # Add status field to contents table

  1. Changes
    - Add status enum type with values: in_process, completed, failed
    - Add status column to contents table with default value 'in_process'
    - Update existing records to have status='in_process'
    - Add index on status column for filtering performance

  2. Notes
    - When content is uploaded, it will automatically have status='in_process'
    - Content status can be updated to 'completed' or 'failed' based on processing
*/

-- Create content status enum
DO $$ BEGIN
  CREATE TYPE content_status AS ENUM ('in_process', 'completed', 'failed');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Add status column to contents table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'contents' AND column_name = 'status'
  ) THEN
    ALTER TABLE contents ADD COLUMN status content_status DEFAULT 'in_process' NOT NULL;
  END IF;
END $$;

-- Update existing records to have in_process status
UPDATE contents SET status = 'in_process' WHERE status IS NULL;

-- Create index on status column
CREATE INDEX IF NOT EXISTS idx_contents_status ON contents(status);

-- Update RLS policy to allow status updates
CREATE POLICY "PM users can update contents"
  ON contents
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE user_id = user_uploaded
      AND role = 'PM'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE user_id = user_uploaded
      AND role = 'PM'
    )
  );

/*
  # Create Users Table

  1. New Tables
    - `users`
      - `user_id` (varchar, primary key) - Unique user identifier
      - `firstname` (varchar) - User's first name
      - `lastname` (varchar) - User's last name
      - `email` (varchar, unique) - User's email address
      - `password_hash` (varchar) - Hashed password for authentication
      - `role` (varchar) - User role: 'PD' (Product Designer) or 'PM' (Product Manager)
      - `created_date` (timestamptz) - Account creation timestamp

  2. Indexes
    - Primary key index on `user_id`
    - Unique index on `email` for email lookups
    - Index on `role` for role-based queries

  3. Security
    - Enable RLS on `users` table
    - Add policy for authenticated users to read their own user data

  4. Test Data
    - Insert test PD user (pd001) and PM user (pm001)
    - Both have password 'password123'
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  user_id VARCHAR(50) PRIMARY KEY,
  firstname VARCHAR(100) NOT NULL,
  lastname VARCHAR(100) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(10) NOT NULL CHECK (role IN ('PD', 'PM')),
  created_date TIMESTAMPTZ DEFAULT now()
);

-- Create indexes for efficient lookups
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Policy: Authenticated users can read their own user data
CREATE POLICY "Users can view own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = user_id);

-- Policy: Authenticated users can update their own profile
CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = user_id)
  WITH CHECK (auth.uid()::text = user_id);

-- Insert test users (password for both is 'password123')
INSERT INTO users (user_id, firstname, lastname, email, password_hash, role)
VALUES
  ('pd001', 'John', 'Doe', 'john.doe@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PD'),
  ('pm001', 'Jane', 'Smith', 'jane.smith@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lJNBWWJGxC6C', 'PM')
ON CONFLICT (user_id) DO NOTHING;
/*
  # Create System Prompts Table

  1. New Tables
    - `system_prompts`
      - `id` (uuid, primary key) - Unique identifier for each system prompt
      - `name` (varchar) - Name/title of the system prompt
      - `prompt` (text) - The actual prompt content stored as markdown text
      - `created_by` (varchar) - User ID of the creator, references users table
      - `created_at` (timestamptz) - Timestamp when prompt was created
      - `updated_at` (timestamptz) - Timestamp when prompt was last updated

  2. Indexes
    - Primary key index on `id` for fast lookups
    - Index on `created_by` for filtering by creator
    - Index on `name` for search functionality

  3. Security
    - Enable RLS on `system_prompts` table
    - Add policy for authenticated users to read all system prompts (both PD and PM)
    - Note: Write operations (INSERT, UPDATE, DELETE) will be controlled at the application level
      based on user role validation, as RLS doesn't have direct access to application session data

  4. Triggers
    - Automatic updated_at timestamp update on row modifications
*/

-- Create system_prompts table
CREATE TABLE IF NOT EXISTS system_prompts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  prompt TEXT NOT NULL,
  created_by VARCHAR(50) REFERENCES users(user_id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_system_prompts_created_by ON system_prompts(created_by);
CREATE INDEX IF NOT EXISTS idx_system_prompts_name ON system_prompts(name);
CREATE INDEX IF NOT EXISTS idx_system_prompts_created_at ON system_prompts(created_at DESC);

-- Enable Row Level Security
ALTER TABLE system_prompts ENABLE ROW LEVEL SECURITY;

-- Policy: Authenticated users can read all system prompts
CREATE POLICY "Authenticated users can view system prompts"
  ON system_prompts
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Authenticated users can insert system prompts (role check done in application)
CREATE POLICY "Authenticated users can create system prompts"
  ON system_prompts
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Policy: Authenticated users can update system prompts (role check done in application)
CREATE POLICY "Authenticated users can update system prompts"
  ON system_prompts
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policy: Authenticated users can delete system prompts (role check done in application)
CREATE POLICY "Authenticated users can delete system prompts"
  ON system_prompts
  FOR DELETE
  TO authenticated
  USING (true);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update updated_at on row updates
CREATE TRIGGER update_system_prompts_updated_at
  BEFORE UPDATE ON system_prompts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
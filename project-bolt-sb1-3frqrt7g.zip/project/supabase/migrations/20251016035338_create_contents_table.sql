/*
  # Create contents table for content management

  1. New Tables
    - `contents`
      - `content_id` (uuid, primary key) - Unique identifier for the content
      - `content_name` (text) - Display name for the content
      - `file_name` (text) - Original filename of the uploaded file
      - `blob_data` (text) - Base64-encoded file content
      - `metadata` (jsonb) - Key-value pairs for additional metadata
      - `date_created` (timestamptz) - Timestamp when content was created
      - `user_uploaded` (text, foreign key) - ID of user who uploaded the content

  2. Security
    - Enable RLS on `contents` table
    - Add policy for authenticated users to read content
    - Add policy for PM role users to insert content
    - Add policy for PM role users to delete content

  3. Indexes
    - Add index on content_name for search performance
    - Add index on user_uploaded for filtering by user
*/

CREATE TABLE IF NOT EXISTS contents (
  content_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_name text NOT NULL,
  file_name text NOT NULL,
  blob_data text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  date_created timestamptz DEFAULT now(),
  user_uploaded text NOT NULL,
  CONSTRAINT fk_user_uploaded FOREIGN KEY (user_uploaded) REFERENCES users(user_id) ON DELETE CASCADE
);

ALTER TABLE contents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read contents"
  ON contents
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "PM users can insert contents"
  ON contents
  FOR INSERT
  TO authenticated
  WITH CHECK (
    user_uploaded IN (
      SELECT user_id::text FROM users
      WHERE role = 'PM'
    )
  );

CREATE POLICY "PM users can delete contents"
  ON contents
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE user_id = user_uploaded
      AND role = 'PM'
    )
  );

CREATE INDEX IF NOT EXISTS idx_contents_name ON contents(content_name);
CREATE INDEX IF NOT EXISTS idx_contents_user ON contents(user_uploaded);
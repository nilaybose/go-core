/*
  # Create recon_specs table for storing reconnaissance specifications

  1. New Tables
    - `recon_specs`
      - `id` (uuid, primary key) - Unique identifier for each recon spec
      - `name` (varchar(50)) - Name of the recon spec (alphanumeric and underscore only)
      - `json_content` (jsonb) - JSON schema content for the spec
      - `date_created` (timestamptz) - Timestamp when spec was created
      - `date_modified` (timestamptz) - Timestamp when spec was last modified
      - `last_updated_by` (text) - User ID of the last person to modify the spec

  2. Security
    - Enable RLS on `recon_specs` table
    - Add policy for authenticated users to read all recon specs
    - Add policy for authenticated users to create recon specs
    - Add policy for authenticated users to update recon specs
    - Add policy for authenticated users to delete recon specs

  3. Indexes
    - Add index on name column for efficient searching
    - Add index on last_updated_by for user-based queries

  4. Constraints
    - Name must be alphanumeric with underscores only, max 50 characters
    - Name must be unique
    - JSON content cannot be null
*/

CREATE TABLE IF NOT EXISTS recon_specs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(50) NOT NULL UNIQUE,
  json_content jsonb NOT NULL,
  date_created timestamptz DEFAULT now() NOT NULL,
  date_modified timestamptz DEFAULT now() NOT NULL,
  last_updated_by text NOT NULL,
  CONSTRAINT name_format CHECK (name ~ '^[a-zA-Z0-9_]+$')
);

CREATE INDEX IF NOT EXISTS idx_recon_specs_name ON recon_specs(name);
CREATE INDEX IF NOT EXISTS idx_recon_specs_last_updated_by ON recon_specs(last_updated_by);

CREATE OR REPLACE FUNCTION update_recon_specs_date_modified()
RETURNS TRIGGER AS $$
BEGIN
  NEW.date_modified = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trigger_update_recon_specs_date_modified'
  ) THEN
    CREATE TRIGGER trigger_update_recon_specs_date_modified
      BEFORE UPDATE ON recon_specs
      FOR EACH ROW
      EXECUTE FUNCTION update_recon_specs_date_modified();
  END IF;
END $$;

ALTER TABLE recon_specs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all recon specs"
  ON recon_specs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create recon specs"
  ON recon_specs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update recon specs"
  ON recon_specs
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete recon specs"
  ON recon_specs
  FOR DELETE
  TO authenticated
  USING (true);
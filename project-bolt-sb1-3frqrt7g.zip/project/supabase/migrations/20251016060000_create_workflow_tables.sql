/*
  # Create Workflow Management Tables

  1. New Tables
    - `workflow_instance`
      - `id` (uuid, primary key) - Unique identifier for the workflow
      - `name` (text) - Name of the workflow
      - `processor_name` (text) - Name of the processor
      - `status` (enum: pending, in_progress, completed, cancelled) - Current workflow status
      - `start_datetime` (timestamptz) - When workflow was started
      - `end_datetime` (timestamptz) - When workflow was completed/cancelled
      - `initiated_user` (text, foreign key) - User who created the workflow
      - `status_note` (text) - Note captured during status changes
      - `created_at` (timestamptz) - Timestamp when record was created
      - `updated_at` (timestamptz) - Timestamp when record was last updated

    - `workflow_task`
      - `id` (uuid, primary key) - Unique identifier for the task
      - `workflow_id` (uuid, foreign key) - Reference to parent workflow
      - `task_name` (text) - Name of the task
      - `seq_order` (integer) - Sequential order of task execution
      - `status` (enum: pending, in_process, completed) - Current task status
      - `artifact_mandatory` (boolean) - Whether artifact is required
      - `role_assigned` (text) - Role responsible for task (PM or PD)
      - `start_datetime` (timestamptz) - When task was started
      - `end_datetime` (timestamptz) - When task was completed
      - `remarks` (text) - General task notes
      - `status_note` (text) - Note captured during status changes
      - `last_modified_by` (text, foreign key) - User who last modified the task
      - `created_at` (timestamptz) - Timestamp when record was created
      - `updated_at` (timestamptz) - Timestamp when record was last updated

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to read workflows and tasks
    - Add policies for PM users to create workflows
    - Add policies for role-based task updates

  3. Indexes
    - Add indexes on workflow_id, status, role_assigned for efficient queries
    - Add composite indexes for common filter patterns
*/

-- Create workflow status enum
DO $$ BEGIN
  CREATE TYPE workflow_status AS ENUM ('pending', 'in_progress', 'completed', 'cancelled');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Create task status enum
DO $$ BEGIN
  CREATE TYPE task_status AS ENUM ('pending', 'in_process', 'completed');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Create workflow_instance table
CREATE TABLE IF NOT EXISTS workflow_instance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  processor_name text NOT NULL,
  status workflow_status NOT NULL DEFAULT 'pending',
  start_datetime timestamptz DEFAULT now(),
  end_datetime timestamptz,
  initiated_user text NOT NULL,
  status_note text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT fk_initiated_user FOREIGN KEY (initiated_user) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Create workflow_task table
CREATE TABLE IF NOT EXISTS workflow_task (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL,
  task_name text NOT NULL,
  seq_order integer NOT NULL,
  status task_status NOT NULL DEFAULT 'pending',
  artifact_mandatory boolean DEFAULT false,
  role_assigned text NOT NULL,
  start_datetime timestamptz,
  end_datetime timestamptz,
  remarks text,
  status_note text,
  last_modified_by text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT fk_workflow_id FOREIGN KEY (workflow_id) REFERENCES workflow_instance(id) ON DELETE CASCADE,
  CONSTRAINT fk_last_modified_by FOREIGN KEY (last_modified_by) REFERENCES users(user_id) ON DELETE SET NULL,
  CONSTRAINT unique_workflow_task UNIQUE (workflow_id, task_name)
);

-- Create indexes for workflow_instance
CREATE INDEX IF NOT EXISTS idx_workflow_status ON workflow_instance(status);
CREATE INDEX IF NOT EXISTS idx_workflow_initiated_user ON workflow_instance(initiated_user);
CREATE INDEX IF NOT EXISTS idx_workflow_name ON workflow_instance(name);
CREATE INDEX IF NOT EXISTS idx_workflow_processor_name ON workflow_instance(processor_name);

-- Create indexes for workflow_task
CREATE INDEX IF NOT EXISTS idx_task_workflow_id ON workflow_task(workflow_id);
CREATE INDEX IF NOT EXISTS idx_task_status ON workflow_task(status);
CREATE INDEX IF NOT EXISTS idx_task_role_assigned ON workflow_task(role_assigned);
CREATE INDEX IF NOT EXISTS idx_task_seq_order ON workflow_task(seq_order);
CREATE INDEX IF NOT EXISTS idx_task_workflow_status ON workflow_task(workflow_id, status);
CREATE INDEX IF NOT EXISTS idx_task_role_status ON workflow_task(role_assigned, status);

-- Enable RLS
ALTER TABLE workflow_instance ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_task ENABLE ROW LEVEL SECURITY;

-- Workflow instance policies
CREATE POLICY "Authenticated users can read workflows"
  ON workflow_instance
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "PM users can create workflows"
  ON workflow_instance
  FOR INSERT
  TO authenticated
  WITH CHECK (
    initiated_user IN (
      SELECT user_id::text FROM users
      WHERE role = 'PM'
    )
  );

CREATE POLICY "Authenticated users can update workflows"
  ON workflow_instance
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Workflow task policies
CREATE POLICY "Authenticated users can read tasks"
  ON workflow_task
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update tasks"
  ON workflow_task
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "System can insert tasks"
  ON workflow_task
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

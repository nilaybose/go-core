export interface User {
  user_id: string;
  firstname: string;
  lastname: string;
  email: string;
  role: 'PD' | 'PM';
}

export interface LoginCredentials {
  user_id: string;
  password: string;
}

export interface LoginResponse {
  session_id: string;
  user: User;
}

export interface SessionResponse {
  valid: boolean;
  user_id: string;
}

export interface ApiError {
  detail: string;
}

export interface SystemPrompt {
  id: string;
  name: string;
  prompt: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  updated_by: string | null;
}

export interface SystemPromptFormData {
  name: string;
  prompt: string;
}

export type ContentStatus = 'in_process' | 'completed' | 'failed';

export interface Content {
  content_id: string;
  content_name: string;
  file_name: string;
  metadata: Record<string, any>;
  date_created: string;
  user_uploaded: string;
  status: ContentStatus;
}

export interface ContentDetail extends Content {
  blob_data: string;
}

export interface ContentFormData {
  content_name: string;
  file_name: string;
  blob_data: string;
  metadata: Record<string, any>;
  status?: ContentStatus;
}

export interface ContentMetadata {
  content_name: string;
  file_name: string;
  metadata: Record<string, any>;
  date_created: string;
  user_uploaded: string;
  status: ContentStatus;
}

export interface ReconSpec {
  id: string;
  name: string;
  json_content: Record<string, any>;
  date_created: string;
  date_modified: string;
  last_updated_by: string;
}

export interface ReconSpecFormData {
  name: string;
  json_content: Record<string, any>;
}

export type WorkflowStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';
export type TaskStatus = 'pending' | 'in_process' | 'completed';

export interface WorkflowTask {
  id: string;
  workflow_id: string;
  task_name: string;
  seq_order: number;
  status: TaskStatus;
  artifact_mandatory: boolean;
  role_assigned: 'PM' | 'PD';
  start_datetime: string | null;
  end_datetime: string | null;
  remarks: string | null;
  status_note: string | null;
  last_modified_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface WorkflowInstance {
  id: string;
  name: string;
  processor_name: string;
  status: WorkflowStatus;
  start_datetime: string;
  end_datetime: string | null;
  initiated_user: string;
  status_note: string | null;
  created_at: string;
  updated_at: string;
  tasks?: WorkflowTask[];
  can_complete?: boolean;
}

export interface WorkflowCreateData {
  name: string;
  processor_name: string;
}

export interface WorkflowStatusUpdate {
  status: WorkflowStatus;
  status_note: string;
}

export interface TaskStatusUpdate {
  status: TaskStatus;
  status_note: string;
}

export interface TaskUpdate {
  remarks: string;
}

export interface WorkflowFilters {
  name?: string;
  status?: WorkflowStatus;
  processor_name?: string;
  role?: 'PM' | 'PD';
}

export interface NotificationCount {
  count: number;
  role: string;
}

export interface TaskDefinition {
  name: string;
  seq_order: number;
  role_assigned: 'PM' | 'PD';
  artifact_mandatory: boolean;
  description: string;
}

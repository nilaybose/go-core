import { TaskDefinition } from '../types';

export const TASK_DEFINITIONS: TaskDefinition[] = [
  {
    name: 'Schema Mapping',
    seq_order: 1,
    role_assigned: 'PM',
    artifact_mandatory: true,
    description: 'Map source data schema to target schema format. Review and define field mappings, data transformations, and validation rules.',
  },
  {
    name: 'Auto Mapping',
    seq_order: 2,
    role_assigned: 'PM',
    artifact_mandatory: true,
    description: 'Automated mapping process using AI/ML algorithms to suggest field mappings based on schema analysis and historical patterns.',
  },
  {
    name: 'Commit Mapping',
    seq_order: 3,
    role_assigned: 'PM',
    artifact_mandatory: true,
    description: 'Review and finalize all mapping configurations. Commit approved mappings to the system for code generation.',
  },
  {
    name: 'Code Generation',
    seq_order: 4,
    role_assigned: 'PD',
    artifact_mandatory: false,
    description: 'Generate transformation code based on committed mappings. Create ETL scripts, data pipelines, and validation logic.',
  },
  {
    name: 'Ticket Creation',
    seq_order: 5,
    role_assigned: 'PM',
    artifact_mandatory: false,
    description: 'Create implementation tickets in project management system. Assign tasks, set priorities, and define acceptance criteria.',
  },
  {
    name: 'Signoff',
    seq_order: 6,
    role_assigned: 'PM',
    artifact_mandatory: false,
    description: 'Final review and approval of the workflow. Verify all deliverables, documentation, and sign off on completion.',
  },
];

export const getTaskBySequence = (seq_order: number): TaskDefinition | undefined => {
  return TASK_DEFINITIONS.find(task => task.seq_order === seq_order);
};

export const getTaskByName = (name: string): TaskDefinition | undefined => {
  return TASK_DEFINITIONS.find(task => task.name === name);
};

export const getAllTasks = (): TaskDefinition[] => {
  return TASK_DEFINITIONS;
};

export const TASK_COLORS = {
  'Schema Mapping': 'bg-blue-100 text-blue-800 border-blue-300',
  'Auto Mapping': 'bg-green-100 text-green-800 border-green-300',
  'Commit Mapping': 'bg-yellow-100 text-yellow-800 border-yellow-300',
  'Code Generation': 'bg-purple-100 text-purple-800 border-purple-300',
  'Ticket Creation': 'bg-orange-100 text-orange-800 border-orange-300',
  'Signoff': 'bg-pink-100 text-pink-800 border-pink-300',
};

export const TASK_STATUS_COLORS = {
  pending: 'bg-gray-100 text-gray-700',
  in_process: 'bg-blue-100 text-blue-700',
  completed: 'bg-green-100 text-green-700',
};

export const WORKFLOW_STATUS_COLORS = {
  pending: 'bg-gray-100 text-gray-700',
  in_progress: 'bg-blue-100 text-blue-700',
  completed: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

import { apiClient } from './api';
import { LoginCredentials, LoginResponse, User } from '../types';

const TOKEN_KEY = 'session_token';

export const authService = {
  async login(credentials: LoginCredentials): Promise<LoginResponse> {
    const response = await apiClient.post<LoginResponse>('/auth/login', credentials);
    this.setToken(response.session_id);
    return response;
  },

  async logout(): Promise<void> {
    const token = this.getToken();
    if (token) {
      try {
        await apiClient.post('/auth/logout', { session_id: token });
      } catch (error) {
        console.error('Logout error:', error);
      }
    }
    this.removeToken();
  },

  async getProfile(): Promise<User> {
    const token = this.getToken();
    if (!token) {
      throw new Error('No session token found');
    }
    return apiClient.get<User>(`/auth/profile?session_id=${token}`);
  },

  async validateSession(): Promise<boolean> {
    const token = this.getToken();
    if (!token) {
      return false;
    }

    try {
      await apiClient.get(`/auth/validate?session_id=${token}`);
      return true;
    } catch {
      this.removeToken();
      return false;
    }
  },

  setToken(token: string): void {
    localStorage.setItem(TOKEN_KEY, token);
  },

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },

  removeToken(): void {
    localStorage.removeItem(TOKEN_KEY);
  },
};

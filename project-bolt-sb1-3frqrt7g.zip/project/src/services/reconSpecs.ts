import { apiClient } from './api';
import { ReconSpec, ReconSpecFormData } from '../types';

const getAuthHeaders = (): HeadersInit => {
  const sessionId = localStorage.getItem('session_id');
  return {
    'X-Session-ID': sessionId || '',
  };
};

export const reconSpecsService = {
  async getAll(search?: string): Promise<ReconSpec[]> {
    const endpoint = search
      ? `/admin/recon-specs?search=${encodeURIComponent(search)}`
      : '/admin/recon-specs';
    return apiClient.get<ReconSpec[]>(endpoint, getAuthHeaders());
  },

  async getById(id: string): Promise<ReconSpec> {
    return apiClient.get<ReconSpec>(`/admin/recon-specs/${id}`, getAuthHeaders());
  },

  async create(data: ReconSpecFormData): Promise<ReconSpec> {
    return apiClient.post<ReconSpec>('/admin/recon-specs', data, getAuthHeaders());
  },

  async update(id: string, data: Partial<ReconSpecFormData>): Promise<ReconSpec> {
    return apiClient.put<ReconSpec>(`/admin/recon-specs/${id}`, data, getAuthHeaders());
  },

  async delete(id: string): Promise<void> {
    return apiClient.delete<void>(`/admin/recon-specs/${id}`, getAuthHeaders());
  },

  async download(id: string, name: string): Promise<void> {
    const sessionId = localStorage.getItem('session_id');
    const url = `http://localhost:8000/admin/recon-specs/${id}/download`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-Session-ID': sessionId || '',
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Failed to download spec' }));
      throw new Error(error.detail || 'Failed to download spec');
    }

    const blob = await response.blob();
    const downloadUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `${name}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(downloadUrl);
  },
};

import { apiClient } from './api';
import { SystemPrompt, SystemPromptFormData } from '../types';

const getAuthHeaders = (): HeadersInit => {
  const sessionId = localStorage.getItem('session_id');
  return {
    'X-Session-ID': sessionId || '',
  };
};

export const systemPromptsService = {
  async getAll(): Promise<SystemPrompt[]> {
    return apiClient.get<SystemPrompt[]>('/admin/system-prompts', getAuthHeaders());
  },

  async getById(id: string): Promise<SystemPrompt> {
    return apiClient.get<SystemPrompt>(`/admin/system-prompts/${id}`, getAuthHeaders());
  },

  async create(data: SystemPromptFormData): Promise<SystemPrompt> {
    return apiClient.post<SystemPrompt>('/admin/system-prompts', data, getAuthHeaders());
  },

  async update(id: string, data: Partial<SystemPromptFormData>): Promise<SystemPrompt> {
    return apiClient.put<SystemPrompt>(`/admin/system-prompts/${id}`, data, getAuthHeaders());
  },

  async delete(id: string): Promise<void> {
    return apiClient.delete<void>(`/admin/system-prompts/${id}`, getAuthHeaders());
  },
};

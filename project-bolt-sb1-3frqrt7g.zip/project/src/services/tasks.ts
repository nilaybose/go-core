import api from './api';
import { WorkflowTask, TaskStatusUpdate, TaskUpdate } from '../types';

export const getWorkflowTasks = async (workflowId: string): Promise<WorkflowTask[]> => {
  const response = await api.get<WorkflowTask[]>(`/api/workflows/${workflowId}/tasks`);
  return response.data;
};

export const getTaskById = async (taskId: string): Promise<WorkflowTask> => {
  const response = await api.get<WorkflowTask>(`/api/tasks/${taskId}`);
  return response.data;
};

export const updateTaskStatus = async (
  taskId: string,
  statusUpdate: TaskStatusUpdate
): Promise<WorkflowTask> => {
  const response = await api.patch<WorkflowTask>(
    `/api/tasks/${taskId}/status`,
    statusUpdate
  );
  return response.data;
};

export const updateTaskRemarks = async (
  taskId: string,
  taskUpdate: TaskUpdate
): Promise<WorkflowTask> => {
  const response = await api.patch<WorkflowTask>(
    `/api/tasks/${taskId}/remarks`,
    taskUpdate
  );
  return response.data;
};

import { apiClient } from './api';
import { Content, ContentDetail, ContentFormData, ContentMetadata, ContentStatus } from '../types';

const getAuthHeaders = (): HeadersInit => {
  const sessionId = localStorage.getItem('session_id');
  return {
    'X-Session-ID': sessionId || '',
  };
};

export const contentsService = {
  async getAll(search?: string): Promise<Content[]> {
    const endpoint = search
      ? `/admin/contents?search=${encodeURIComponent(search)}`
      : '/admin/contents';
    return apiClient.get<Content[]>(endpoint, getAuthHeaders());
  },

  async getById(id: string): Promise<ContentDetail> {
    return apiClient.get<ContentDetail>(`/admin/contents/${id}`, getAuthHeaders());
  },

  async getMetadata(id: string): Promise<ContentMetadata> {
    return apiClient.get<ContentMetadata>(`/admin/contents/${id}/metadata`, getAuthHeaders());
  },

  async create(data: ContentFormData): Promise<Content> {
    return apiClient.post<Content>('/admin/contents', data, getAuthHeaders());
  },

  async delete(id: string): Promise<void> {
    return apiClient.delete<void>(`/admin/contents/${id}`, getAuthHeaders());
  },

  async updateStatus(id: string, status: ContentStatus): Promise<Content> {
    return apiClient.patch<Content>(`/admin/contents/${id}/status`, { status }, getAuthHeaders());
  },

  async download(id: string, fileName: string): Promise<void> {
    const content = await this.getById(id);

    const byteCharacters = atob(content.blob_data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray]);

    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  },
};

import api from './api';
import {
  WorkflowInstance,
  WorkflowCreateData,
  WorkflowStatusUpdate,
  WorkflowFilters,
  NotificationCount,
} from '../types';

export const getWorkflows = async (filters?: WorkflowFilters): Promise<WorkflowInstance[]> => {
  const params = new URLSearchParams();

  if (filters?.name) params.append('name', filters.name);
  if (filters?.status) params.append('status', filters.status);
  if (filters?.processor_name) params.append('processor_name', filters.processor_name);
  if (filters?.role) params.append('role', filters.role);

  const queryString = params.toString();
  const url = queryString ? `/api/workflows?${queryString}` : '/api/workflows';

  const response = await api.get<WorkflowInstance[]>(url);
  return response.data;
};

export const getWorkflowById = async (workflowId: string): Promise<WorkflowInstance> => {
  const response = await api.get<WorkflowInstance>(`/api/workflows/${workflowId}`);
  return response.data;
};

export const createWorkflow = async (data: WorkflowCreateData): Promise<WorkflowInstance> => {
  const response = await api.post<WorkflowInstance>('/api/workflows', data);
  return response.data;
};

export const updateWorkflowStatus = async (
  workflowId: string,
  statusUpdate: WorkflowStatusUpdate
): Promise<WorkflowInstance> => {
  const response = await api.patch<WorkflowInstance>(
    `/api/workflows/${workflowId}/status`,
    statusUpdate
  );
  return response.data;
};

export const getNotificationCount = async (): Promise<NotificationCount> => {
  const response = await api.get<NotificationCount>('/api/workflows/notifications/count');
  return response.data;
};

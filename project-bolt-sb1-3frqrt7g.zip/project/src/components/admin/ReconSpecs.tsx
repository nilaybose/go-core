import React, { useState, useEffect } from 'react';
import { FileJson, Plus, Eye, Edit2, Trash2, Download, X, AlertCircle } from 'lucide-react';
import { ReconSpec, ReconSpecFormData } from '../../types';
import { reconSpecsService } from '../../services/reconSpecs';

type ModalType = 'add' | 'edit' | 'view' | 'delete' | null;

export const ReconSpecs: React.FC = () => {
  const [specs, setSpecs] = useState<ReconSpec[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [modalType, setModalType] = useState<ModalType>(null);
  const [selectedSpec, setSelectedSpec] = useState<ReconSpec | null>(null);
  const [formData, setFormData] = useState<ReconSpecFormData>({ name: '', json_content: {} });
  const [jsonText, setJsonText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    loadSpecs();
  }, []);

  const loadSpecs = async (search?: string) => {
    try {
      setLoading(true);
      setError(null);
      const data = await reconSpecsService.getAll(search);
      setSpecs(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load recon specs');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    if (value.trim()) {
      loadSpecs(value.trim());
    } else {
      loadSpecs();
    }
  };

  const validateName = (name: string): boolean => {
    if (!name.trim()) {
      setValidationError('Name is required');
      return false;
    }
    if (name.length > 50) {
      setValidationError('Name must be 50 characters or less');
      return false;
    }
    if (!/^[a-zA-Z0-9_]+$/.test(name)) {
      setValidationError('Name must contain only alphanumeric characters and underscores');
      return false;
    }
    return true;
  };

  const validateJson = (text: string): Record<string, any> | null => {
    if (!text.trim()) {
      setValidationError('JSON schema is required');
      return null;
    }
    try {
      const parsed = JSON.parse(text);
      if (typeof parsed !== 'object' || parsed === null) {
        setValidationError('JSON must be an object');
        return null;
      }
      return parsed;
    } catch (e) {
      setValidationError(`Invalid JSON: ${e instanceof Error ? e.message : 'Parse error'}`);
      return null;
    }
  };

  const openAddModal = () => {
    setFormData({ name: '', json_content: {} });
    setJsonText('');
    setValidationError(null);
    setModalType('add');
  };

  const openEditModal = (spec: ReconSpec) => {
    setSelectedSpec(spec);
    setFormData({ name: spec.name, json_content: spec.json_content });
    setJsonText(JSON.stringify(spec.json_content, null, 2));
    setValidationError(null);
    setModalType('edit');
  };

  const openViewModal = (spec: ReconSpec) => {
    setSelectedSpec(spec);
    setModalType('view');
  };

  const openDeleteModal = (spec: ReconSpec) => {
    setSelectedSpec(spec);
    setModalType('delete');
  };

  const closeModal = () => {
    setModalType(null);
    setSelectedSpec(null);
    setFormData({ name: '', json_content: {} });
    setJsonText('');
    setError(null);
    setValidationError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);
    setError(null);

    if (!validateName(formData.name)) {
      return;
    }

    const jsonContent = validateJson(jsonText);
    if (!jsonContent) {
      return;
    }

    try {
      setSubmitting(true);

      if (modalType === 'add') {
        await reconSpecsService.create({ name: formData.name, json_content: jsonContent });
      } else if (modalType === 'edit' && selectedSpec) {
        await reconSpecsService.update(selectedSpec.id, { name: formData.name, json_content: jsonContent });
      }

      await loadSpecs();
      closeModal();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Operation failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedSpec) return;

    try {
      setSubmitting(true);
      setError(null);
      await reconSpecsService.delete(selectedSpec.id);
      await loadSpecs();
      closeModal();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete spec');
      setSubmitting(false);
    }
  };

  const handleDownload = async (spec: ReconSpec) => {
    try {
      await reconSpecsService.download(spec.id, spec.name);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to download spec');
    }
  };

  const handleJsonTextChange = (text: string) => {
    setJsonText(text);
    setValidationError(null);
  };

  const formatJson = () => {
    try {
      const parsed = JSON.parse(jsonText);
      setJsonText(JSON.stringify(parsed, null, 2));
      setValidationError(null);
    } catch (e) {
      setValidationError(`Invalid JSON: ${e instanceof Error ? e.message : 'Parse error'}`);
    }
  };

  const filteredSpecs = specs.filter(spec =>
    spec.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-600">Loading recon specs...</div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Recon Specs</h1>
          <p className="text-gray-600 mt-1">Manage reconnaissance specifications and JSON schemas</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Spec
        </button>
      </div>

      {error && !modalType && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertCircle className="w-5 h-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
          <span className="text-red-800">{error}</span>
        </div>
      )}

      <div className="mb-4">
        <input
          type="text"
          placeholder="Search by spec name..."
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {filteredSpecs.length === 0 ? (
        <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 text-center">
          <FileJson className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {searchTerm ? 'No specs found' : 'No Recon Specs Yet'}
          </h3>
          <p className="text-gray-600">
            {searchTerm
              ? 'Try adjusting your search terms'
              : 'Get started by creating your first recon spec'}
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Spec Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Modified By
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date Modified
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredSpecs.map((spec) => (
                <tr key={spec.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{spec.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-600">{spec.last_updated_by}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-600">
                      {new Date(spec.date_modified).toLocaleString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-2">
                      <button
                        onClick={() => openViewModal(spec)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="View"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => openEditModal(spec)}
                        className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDownload(spec)}
                        className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => openDeleteModal(spec)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {(modalType === 'add' || modalType === 'edit') && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full mx-4 max-h-[90vh] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">
                {modalType === 'add' ? 'Create Recon Spec' : 'Edit Recon Spec'}
              </h2>
              <button
                onClick={closeModal}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto">
              <div className="p-6 space-y-4">
                {(error || validationError) && (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
                    <AlertCircle className="w-5 h-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-red-800">{error || validationError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Spec Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => {
                      setFormData({ ...formData, name: e.target.value });
                      setValidationError(null);
                    }}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., user_profile_spec (alphanumeric and underscore only, max 50 chars)"
                    maxLength={50}
                    required
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Only alphanumeric characters and underscores allowed (max 50 characters)
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      JSON Schema <span className="text-red-500">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={formatJson}
                      className="text-xs text-blue-600 hover:text-blue-700 font-medium"
                    >
                      Format JSON
                    </button>
                  </div>
                  <textarea
                    value={jsonText}
                    onChange={(e) => handleJsonTextChange(e.target.value)}
                    rows={16}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                    placeholder='{"type": "object", "properties": {...}}'
                    required
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Enter valid JSON schema content
                  </p>
                </div>
              </div>

              <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={submitting}
                >
                  {submitting ? 'Saving...' : modalType === 'add' ? 'Create' : 'Update'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {modalType === 'view' && selectedSpec && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full mx-4 max-h-[90vh] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">{selectedSpec.name}</h2>
              <button
                onClick={closeModal}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <div className="mb-4 text-sm text-gray-600 space-y-1">
                <div>Created: {new Date(selectedSpec.date_created).toLocaleString()}</div>
                <div>Last Modified: {new Date(selectedSpec.date_modified).toLocaleString()}</div>
                <div>Last Updated By: <span className="font-medium">{selectedSpec.last_updated_by}</span></div>
              </div>
              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <pre className="whitespace-pre-wrap font-mono text-sm text-gray-800 overflow-x-auto">
                  {JSON.stringify(selectedSpec.json_content, null, 2)}
                </pre>
              </div>
            </div>

            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-end space-x-3">
              <button
                onClick={() => {
                  closeModal();
                  openEditModal(selectedSpec);
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Edit
              </button>
              <button
                onClick={closeModal}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {modalType === 'delete' && selectedSpec && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Confirm Deletion</h2>
            </div>

            <div className="p-6">
              {error && (
                <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
                  <AlertCircle className="w-5 h-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-red-800">{error}</span>
                </div>
              )}
              <p className="text-gray-700">
                Are you sure you want to delete the recon spec "{selectedSpec.name}"? This action cannot be undone.
              </p>
            </div>

            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-end space-x-3">
              <button
                onClick={closeModal}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                disabled={submitting}
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={submitting}
              >
                {submitting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

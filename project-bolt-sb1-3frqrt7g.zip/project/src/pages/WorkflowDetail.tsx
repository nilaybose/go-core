import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, XCircle } from 'lucide-react';
import { getWorkflowById, updateWorkflowStatus } from '../services/workflows';
import { updateTaskStatus } from '../services/tasks';
import { WorkflowInstance, WorkflowTask, WorkflowStatusUpdate, TaskStatusUpdate } from '../types';
import { WORKFLOW_STATUS_COLORS, TASK_STATUS_COLORS, getTaskByName } from '../constants/taskDefinitions';
import { useAuth } from '../contexts/AuthContext';

export default function WorkflowDetail() {
  const { workflowId } = useParams<{ workflowId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [workflow, setWorkflow] = useState<WorkflowInstance | null>(null);
  const [selectedTask, setSelectedTask] = useState<WorkflowTask | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [showStatusModal, setShowStatusModal] = useState(false);
  const [modalType, setModalType] = useState<'workflow' | 'task'>('workflow');
  const [newStatus, setNewStatus] = useState('');
  const [statusNote, setStatusNote] = useState('');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (workflowId) {
      loadWorkflow();
    }
  }, [workflowId]);

  const loadWorkflow = async () => {
    if (!workflowId) return;

    try {
      setLoading(true);
      setError(null);
      const data = await getWorkflowById(workflowId);
      setWorkflow(data);

      if (data.tasks && data.tasks.length > 0 && !selectedTask) {
        setSelectedTask(data.tasks[0]);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load workflow');
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteWorkflow = () => {
    if (!workflow?.can_complete) {
      alert('All tasks must be completed before completing the workflow');
      return;
    }
    setModalType('workflow');
    setNewStatus('completed');
    setShowStatusModal(true);
  };

  const handleCancelWorkflow = () => {
    setModalType('workflow');
    setNewStatus('cancelled');
    setShowStatusModal(true);
  };

  const handleUpdateTaskStatus = (task: WorkflowTask, status: string) => {
    setSelectedTask(task);
    setModalType('task');
    setNewStatus(status);
    setShowStatusModal(true);
  };

  const handleSubmitStatusUpdate = async () => {
    if (statusNote.length < 5) {
      alert('Status note must be at least 5 characters');
      return;
    }

    try {
      setUpdating(true);

      if (modalType === 'workflow' && workflow) {
        const update: WorkflowStatusUpdate = {
          status: newStatus as any,
          status_note: statusNote,
        };
        await updateWorkflowStatus(workflow.id, update);
      } else if (modalType === 'task' && selectedTask) {
        const update: TaskStatusUpdate = {
          status: newStatus as any,
          status_note: statusNote,
        };
        await updateTaskStatus(selectedTask.id, update);
      }

      setShowStatusModal(false);
      setStatusNote('');
      setNewStatus('');
      loadWorkflow();
    } catch (err: any) {
      alert(err.message || 'Failed to update status');
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6 max-w-7xl mx-auto text-center">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <p className="mt-2 text-gray-600">Loading workflow...</p>
      </div>
    );
  }

  if (error || !workflow) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
          {error || 'Workflow not found'}
        </div>
      </div>
    );
  }

  const taskDefinition = selectedTask ? getTaskByName(selectedTask.task_name) : null;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <button
        onClick={() => navigate('/workflows')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to Workflows
      </button>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{workflow.name}</h1>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span>Processor: {workflow.processor_name}</span>
              <span>Started: {new Date(workflow.start_datetime).toLocaleDateString()}</span>
              <span>Initiated by: {workflow.initiated_user}</span>
            </div>
            <span
              className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-medium ${
                WORKFLOW_STATUS_COLORS[workflow.status]
              }`}
            >
              {workflow.status.replace('_', ' ')}
            </span>
            {workflow.status_note && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <p className="text-sm font-medium text-gray-700 mb-1">Status Note:</p>
                <p className="text-sm text-gray-600">{workflow.status_note}</p>
              </div>
            )}
          </div>

          {workflow.status !== 'completed' && workflow.status !== 'cancelled' && (
            <div className="flex gap-2">
              {user?.role === 'PM' && workflow.can_complete && (
                <button
                  onClick={handleCompleteWorkflow}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <CheckCircle className="w-4 h-4" />
                  Complete
                </button>
              )}
              {user?.role === 'PM' && (
                <button
                  onClick={handleCancelWorkflow}
                  className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  <XCircle className="w-4 h-4" />
                  Cancel
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-4 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <h2 className="text-lg font-semibold mb-4">Tasks</h2>
          <div className="space-y-2">
            {workflow.tasks?.map((task) => (
              <button
                key={task.id}
                onClick={() => setSelectedTask(task)}
                className={`w-full text-left p-3 rounded-lg border transition-colors ${
                  selectedTask?.id === task.id
                    ? 'bg-blue-50 border-blue-300'
                    : 'bg-white border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-sm">{task.seq_order}. {task.task_name}</span>
                  <span className={`px-2 py-0.5 rounded text-xs ${TASK_STATUS_COLORS[task.status]}`}>
                    {task.status.replace('_', ' ')}
                  </span>
                </div>
                <div className="text-xs text-gray-600">
                  Role: {task.role_assigned}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="col-span-8 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          {selectedTask ? (
            <>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{selectedTask.task_name}</h2>
                  <span className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-medium ${TASK_STATUS_COLORS[selectedTask.status]}`}>
                    {selectedTask.status.replace('_', ' ')}
                  </span>
                </div>

                {user?.role === selectedTask.role_assigned &&
                  workflow.status !== 'cancelled' &&
                  workflow.status !== 'completed' && (
                    <div className="flex gap-2">
                      {selectedTask.status === 'pending' && (
                        <button
                          onClick={() => handleUpdateTaskStatus(selectedTask, 'in_process')}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        >
                          Start Task
                        </button>
                      )}
                      {selectedTask.status === 'in_process' && (
                        <button
                          onClick={() => handleUpdateTaskStatus(selectedTask, 'completed')}
                          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                        >
                          Complete Task
                        </button>
                      )}
                    </div>
                  )}
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-1">Description</h3>
                  <p className="text-sm text-gray-600">{taskDefinition?.description || 'No description available'}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-1">Role Assigned</h3>
                    <p className="text-sm text-gray-900">{selectedTask.role_assigned}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-1">Artifact Mandatory</h3>
                    <p className="text-sm text-gray-900">{selectedTask.artifact_mandatory ? 'Yes' : 'No'}</p>
                  </div>
                </div>

                {selectedTask.status_note && (
                  <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <h3 className="text-sm font-medium text-gray-700 mb-1">Status Change Note</h3>
                    <p className="text-sm text-gray-600">{selectedTask.status_note}</p>
                    {selectedTask.last_modified_by && (
                      <p className="text-xs text-gray-500 mt-2">
                        Last modified by: {selectedTask.last_modified_by}
                      </p>
                    )}
                  </div>
                )}

                {selectedTask.remarks && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-1">Remarks</h3>
                    <p className="text-sm text-gray-600">{selectedTask.remarks}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-1">Start Time</h3>
                    <p className="text-sm text-gray-900">
                      {selectedTask.start_datetime
                        ? new Date(selectedTask.start_datetime).toLocaleString()
                        : 'Not started'}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-1">End Time</h3>
                    <p className="text-sm text-gray-900">
                      {selectedTask.end_datetime
                        ? new Date(selectedTask.end_datetime).toLocaleString()
                        : 'Not completed'}
                    </p>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <p className="text-gray-600">Select a task to view details</p>
          )}
        </div>
      </div>

      {showStatusModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <h2 className="text-2xl font-bold mb-4">
              {modalType === 'workflow' ? 'Update Workflow Status' : 'Update Task Status'}
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">New Status</label>
                <p className="text-lg font-semibold text-gray-900 capitalize">{newStatus.replace('_', ' ')}</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status Note (required, min 5 characters)
                </label>
                <textarea
                  value={statusNote}
                  onChange={(e) => setStatusNote(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter a note explaining this status change..."
                />
                <p className="text-xs text-gray-500 mt-1">{statusNote.length} / 5 characters minimum</p>
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <button
                onClick={handleSubmitStatusUpdate}
                disabled={updating || statusNote.length < 5}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {updating ? 'Updating...' : 'Update Status'}
              </button>
              <button
                onClick={() => {
                  setShowStatusModal(false);
                  setStatusNote('');
                  setNewStatus('');
                }}
                disabled={updating}
                className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React from 'react';
import { Workflow as WorkflowIcon, Plus } from 'lucide-react';

export const Workflow: React.FC = () => {
  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Workflow</h1>
          <p className="text-gray-600 mt-2">Create and manage your workflows</p>
        </div>
        <button className="flex items-center px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-lg hover:from-blue-600 hover:to-cyan-600 transition-all shadow-sm">
          <Plus className="w-5 h-5 mr-2" />
          New Workflow
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-2xl mb-6">
            <WorkflowIcon className="w-10 h-10 text-blue-600" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">Workflow Builder Coming Soon</h2>
          <p className="text-gray-600 max-w-md mx-auto">
            A powerful visual workflow builder to create, manage, and automate your business processes without code.
          </p>
        </div>
      </div>
    </div>
  );
};

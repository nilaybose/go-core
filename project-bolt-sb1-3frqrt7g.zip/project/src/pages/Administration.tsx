import React, { useState } from 'react';
import { Users, MessageSquare, FileText, FileJson } from 'lucide-react';
import { UsersManagement } from '../components/admin/UsersManagement';
import { SystemPrompts } from '../components/admin/SystemPrompts';
import { Contents } from '../components/admin/Contents';
import { ReconSpecs } from '../components/admin/ReconSpecs';

type AdminSection = 'users' | 'prompts' | 'contents' | 'reconspecs';

export const Administration: React.FC = () => {
  const [activeSection, setActiveSection] = useState<AdminSection>('users');

  const menuItems = [
    { id: 'users' as AdminSection, label: 'Users Management', icon: Users },
    { id: 'prompts' as AdminSection, label: 'System Prompts', icon: MessageSquare },
    { id: 'contents' as AdminSection, label: 'Contents', icon: FileText },
    { id: 'reconspecs' as AdminSection, label: 'Recon Specs', icon: FileJson },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'users':
        return <UsersManagement />;
      case 'prompts':
        return <SystemPrompts />;
      case 'contents':
        return <Contents />;
      case 'reconspecs':
        return <ReconSpecs />;
      default:
        return <UsersManagement />;
    }
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <aside className="w-64 bg-gray-50 border-r border-gray-200 flex-shrink-0">
        <div className="p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Administration</h2>
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-5 h-5 mr-3" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

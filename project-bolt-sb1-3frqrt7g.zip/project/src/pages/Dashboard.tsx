import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, CheckCircle, XCircle, Clock } from 'lucide-react';
import { getNotificationCount } from '../services/workflows';
import { getWorkflows } from '../services/workflows';
import { useAuth } from '../contexts/AuthContext';
import { WorkflowInstance } from '../types';

export const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notificationCount, setNotificationCount] = useState(0);
  const [workflowStats, setWorkflowStats] = useState({
    total: 0,
    inProgress: 0,
    completed: 0,
    cancelled: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();

    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [notificationData, workflows] = await Promise.all([
        getNotificationCount(),
        getWorkflows(),
      ]);

      setNotificationCount(notificationData.count);

      setWorkflowStats({
        total: workflows.length,
        inProgress: workflows.filter((w: WorkflowInstance) => w.status === 'in_progress').length,
        completed: workflows.filter((w: WorkflowInstance) => w.status === 'completed').length,
        cancelled: workflows.filter((w: WorkflowInstance) => w.status === 'cancelled').length,
      });
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNotificationClick = () => {
    navigate(`/workflows?role=${user?.role}&status=pending`);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">
          Welcome back, {user?.firstname} {user?.lastname} ({user?.role})
        </p>
      </div>

      {notificationCount > 0 && (
        <button
          onClick={handleNotificationClick}
          className="w-full mb-6 bg-blue-50 border-2 border-blue-200 rounded-lg p-6 hover:bg-blue-100 transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                <Bell className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <p className="text-lg font-semibold text-gray-900">
                  You have {notificationCount} pending {notificationCount === 1 ? 'task' : 'tasks'}
                </p>
                <p className="text-sm text-gray-600">Click here to view workflows with tasks for your role</p>
              </div>
            </div>
            <div className="text-3xl font-bold text-blue-600">{notificationCount}</div>
          </div>
        </button>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Workflows</p>
              <p className="text-2xl font-bold text-gray-900">
                {loading ? '...' : workflowStats.total}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Bell className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">In Progress</p>
              <p className="text-2xl font-bold text-gray-900">
                {loading ? '...' : workflowStats.inProgress}
              </p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Completed</p>
              <p className="text-2xl font-bold text-gray-900">
                {loading ? '...' : workflowStats.completed}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Cancelled</p>
              <p className="text-2xl font-bold text-gray-900">
                {loading ? '...' : workflowStats.cancelled}
              </p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <XCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <div className="text-center">
          <Bell className="w-20 h-20 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Workflow Management System</h2>
          <p className="text-gray-600">
            Navigate to Workflows to create and manage workflows, or check your pending tasks above.
          </p>
        </div>
      </div>
    </div>
  );
};

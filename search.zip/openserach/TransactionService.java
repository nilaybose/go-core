import org.opensearch.client.opensearch.OpenSearchClient;
import org.opensearch.client.opensearch.core.UpdateResponse;
import org.opensearch.client.opensearch.core.UpdateRequest;
import org.opensearch.client.opensearch.core.GetResponse;
import org.opensearch.client.opensearch.model.Script;
import org.opensearch.client.opensearch.model.ScriptLanguage;
import org.opensearch.client.opensearch._types.Refresh;
import org.opensearch.client.opensearch._types.OpenSearchException;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.util.List; 
import java.util.ArrayList; 
import java.util.Objects;
import java.util.Optional;

// Imports required for SSL configuration
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

// Imports required for OpenSearch Client setup with Basic Auth
import org.openseensearch.client.RestClient;
import org.opensearch.client.RestClientBuilder;
import org.opensearch.client.transport.OpenSearchTransport;
import org.opensearch.client.transport.restclient.RestClientTransport;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.ssl.SSLContexts;


/**
 * A service class for managing reconciled transactions using OpenSearch.
 * It handles partial updates from various independent events (Original, Funding, Settlement, Fees, Chargeback)
 * and guarantees concurrency safety using Upsert logic for creation and explicit OCC for subsequent updates.
 * Status is managed by four independent boolean flags: isSettled, isFunded, isChargeback, and isFeeRecorded.
 */
public class TransactionManagementService {

    private final OpenSearchClient client;
    private static final String INDEX_NAME = "reconciled_transactions";
    
    // Data transfer object to return the current state and version information
    public static class TransactionState {
        public final Map<String, Object> source;
        public final long seqNo;
        public final long primaryTerm;

        public TransactionState(Map<String, Object> source, long seqNo, long primaryTerm) {
            this.source = source;
            this.seqNo = seqNo;
            this.primaryTerm = primaryTerm;
        }
    }

    public TransactionManagementService(OpenSearchClient client) {
        this.client = client;
    }

    /**
     * Helper to check if a Map is present and not empty.
     */
    private static boolean isPresentMap(Map<String, Object> map) {
        return map != null && !map.isEmpty();
    }

    /**
     * Helper to check if a List of Maps is present and not empty.
     */
    private static boolean isPresentList(List<Map<String, Object>> list) {
        return list != null && !list.isEmpty();
    }

    /**
     * Factory method to create an OpenSearch client configured with Basic Auth,
     * using environment variables for connection details and configured for connection pooling.
     * * @return A configured OpenSearchClient instance.
     */
    public static OpenSearchClient createAuthenticatedClient() {
        // --- 1. Load Connection Parameters from Environment Variables ---
        final String host = System.getenv("OPENSEARCH_HOST");
        final int port = Integer.parseInt(System.getenv("OPENSEARCH_PORT"));
        final String protocol = System.getenv().getOrDefault("OPENSEARCH_PROTOCOL", "https");
        final String user = System.getenv("OPENSEARCH_USER");
        final String password = System.getenv("OPENSEARCH_PASSWORD");

        if (host == null || user == null || password == null) {
            throw new IllegalStateException("OpenSearch connection variables (HOST, USER, PASSWORD) must be set.");
        }

        // --- 2. Configure Basic Authentication ---
        final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY,
            new UsernamePasswordCredentials(user, password));

        // --- 3. Configure RestClient with Pooling, Auth, and SSL Bypass ---
        RestClientBuilder builder = RestClient.builder(
            new HttpHost(host, port, protocol))
            .setHttpClientConfigCallback((HttpAsyncClientBuilder httpClientBuilder) -> {
                
                // Configure Credentials Provider for Basic Auth
                httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                
                // --- Configuration to Ignore Certificates for HTTPS (WARNING: INSECURE) ---
                if ("https".equalsIgnoreCase(protocol)) {
                    try {
                        // Trust Strategy that blindly trusts all certificates
                        final TrustStrategy trustStrategy = (X509Certificate[] chain, String authType) -> true;
                        
                        // Build an SSL Context using the permissive trust strategy
                        final SSLContext sslContext = SSLContexts.custom()
                            .loadTrustMaterial(null, trustStrategy)
                            .build();

                        // Apply the custom SSL Context and disable hostname verification
                        httpClientBuilder.setSSLContext(sslContext)
                                         .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
                        
                    } catch (NoSuchAlgorithmException | KeyManagementException e) {
                        System.err.println("Error configuring SSL context to ignore certificates: " + e.getMessage());
                        // Depending on policy, you might re-throw the error here
                    }
                }
                
                // --- Connection Pooling Configuration ---
                // Set the maximum number of connections allowed across all routes.
                httpClientBuilder.setMaxConnTotal(50);
                // Set the maximum number of connections allowed per route.
                httpClientBuilder.setMaxConnPerRoute(20);
                
                return httpClientBuilder;
            });
            
        // Configure request timeouts (default is 30s)
        builder.setRequestConfigCallback(requestConfigBuilder -> 
            requestConfigBuilder.setConnectTimeout(5000) // 5s connection timeout
                                .setSocketTimeout(30000) // 30s socket timeout
        );


        // --- 4. Build the Client ---
        RestClient restClient = builder.build();
        OpenSearchTransport transport = new RestClientTransport(restClient, new org.opensearch.client.json.jackson.JacksonJsonpMapper());
        
        return new OpenSearchClient(transport);
    }
    
    /**
     * Retrieves the current state and OCC tokens for a transaction ID.
     * This is required before performing an OCC-protected update.
     * * @param transactionId The ID of the document.
     * @return An Optional containing the TransactionState if found, or empty if not.
     * @throws IOException If there is a client/network error.
     */
    public Optional<TransactionState> getTransactionState(String transactionId) throws IOException {
        try {
            GetResponse<Map> response = client.get(g -> g
                .index(INDEX_NAME)
                .id(transactionId), Map.class);

            if (response.found()) {
                // The Java Client uses Map.class to deserialize the source content
                Map<String, Object> source = response.source();
                long seqNo = response.seqNo();
                long primaryTerm = response.primaryTerm();
                
                return Optional.of(new TransactionState(source, seqNo, primaryTerm));
            } else {
                return Optional.empty();
            }
        } catch (OpenSearchException e) {
            // Handle cases where the index might not exist yet, treat as "not found"
            if (e.status() == 404) {
                return Optional.empty();
            }
            throw e;
        }
    }


    /**
     * Processes a transaction event by first checking for the document's existence.
     * If the document exists, it performs a Versioned Update (OCC). 
     * If the document does not exist, it performs an Atomic Upsert (Creation).
     * The method uses Painless scripts to atomically update fields that are present in the event.
     * * @param transactionId The ID of the document.
     * @param orgTrx Partial data for original transaction details.
     * @param funding Partial update data for funding.
     * @param settlements Partial update data for settlements.
     * @param fees Partial update data for fees (now a list of maps).
     * @param chargebacks Partial update data for chargebacks.
     * @return The UpdateResponse on success.
     * @throws IOException If there is a client/network error.
     * @throws OpenSearchException If OpenSearch returns an error (e.g., 409 Conflict).
     */
    public UpdateResponse processTransactionEvent(
        String transactionId, 
        Map<String, Object> orgTrx,
        Map<String, Object> funding, 
        Map<String, Object> settlements,
        List<Map<String, Object>> fees, 
        Map<String, Object> chargebacks
    ) throws IOException, OpenSearchException {

        // --- 1. Check Document State (The new explicit existence check) ---
        Optional<TransactionState> currentState = getTransactionState(transactionId);
        boolean isExistingDocument = currentState.isPresent();
        
        // --- 2. Dynamic Painless Script Construction ---
        
        StringBuilder scriptSource = new StringBuilder();
        Map<String, Object> scriptParams = new HashMap<>();

        
        // 1. Original Transaction Update 
        if (isPresentMap(orgTrx)) {
            scriptSource.append("ctx._source.org_trx = params.orgTrx;");
            scriptParams.put("orgTrx", orgTrx);
        }

        // 2. Funding Detail Update & Set isFunded flag
        if (isPresentMap(funding)) {
            scriptSource.append("ctx._source.funding = params.funding;");
            // Set isFunded flag to true upon receiving funding details
            scriptSource.append("ctx._source.isFunded = true;"); 
            scriptParams.put("funding", funding);
        }

        // 3. Settlement Detail Update & Set isSettled flag
        if (isPresentMap(settlements)) {
            scriptSource.append("ctx._source.settlements = params.settlements;");
            // Set isSettled flag to true upon receiving settlement details
            scriptSource.append("ctx._source.isSettled = true;"); 
            scriptParams.put("settlements", settlements);
        }
        
        // 4. Fees Detail Update (Overwrites the list; set isFeeRecorded flag)
        if (isPresentList(fees)) {
            scriptSource.append("ctx._source.fees = params.fees;");
            // Set isFeeRecorded flag to true upon receiving fee details
            scriptSource.append("ctx._source.isFeeRecorded = true;");
            scriptParams.put("fees", fees);
        }

        // 5. Chargeback Detail Update (Sets isChargeback flag)
        if (isPresentMap(chargebacks)) {
            scriptSource.append("ctx._source.chargebacks = params.chargebacks;");
            // Set isChargeback flag to true upon receiving chargeback details
            scriptSource.append("ctx._source.isChargeback = true;"); 
            scriptParams.put("chargebacks", chargebacks);
        }
        
        // --- NOTE: No conditional status transition logic required as booleans can only transition true ---


        // --- 3. Define Upsert Document (Used ONLY if the document does not exist) ---
        
        Map<String, Object> initialDocument = new HashMap<>();
        
        // Initialize all main map fields based on presence
        initialDocument.put("org_trx", orgTrx != null ? orgTrx : new HashMap<>());
        initialDocument.put("funding", funding != null ? funding : new HashMap<>());
        initialDocument.put("settlements", settlements != null ? settlements : new HashMap<>());
        initialDocument.put("chargebacks", chargebacks != null ? chargebacks : new HashMap<>());
        
        // Initialize fees as an empty list if null
        initialDocument.put("fees", fees != null ? fees : new ArrayList<>()); 
        
        // Initialize boolean status fields (false if null or empty, addressing user request explicitly)
        // If the map/list is null OR empty, it is false. Only true if data is present.
        initialDocument.put("isSettled", isPresentMap(settlements)); 
        initialDocument.put("isFunded", isPresentMap(funding));
        // Renamed from isDispute to isChargeback for consistency
        initialDocument.put("isChargeback", isPresentMap(chargebacks));
        // Renamed from hasFees to isFeeRecorded for consistency
        initialDocument.put("isFeeRecorded", isPresentList(fees));
        
        // Ensure the transaction ID is explicitly set in the document
        initialDocument.put("id", transactionId);


        // --- 4. Build the Update Request and Apply Mode Logic ---

        UpdateRequest.Builder<Map, Map> updateBuilder = new UpdateRequest.Builder<Map, Map>()
            .index(INDEX_NAME)
            .id(transactionId)
            .refresh(Refresh.WaitFor)
            // Use retryOnConflict to handle potential race between GET and UPDATE on an existing document
            .retryOnConflict(5) 
            .script(s -> s
                .source(scriptSource.toString())
                .lang(ScriptLanguage.Painless)
                .params(scriptParams)
            );
            
        if (isExistingDocument) {
            // MODE: Versioned Update (OCC Path - Document was found in step 1)
            TransactionState state = currentState.get();
            System.out.println("MODE: Versioned Update. Applying OCC for ID: " + transactionId + " with SeqNo: " + state.seqNo);
            updateBuilder
                .ifSeqNo(state.seqNo)
                .ifPrimaryTerm(state.primaryTerm);
        } else {
            // MODE: Atomic Upsert (Creation Path - Document was NOT found in step 1)
            System.out.println("MODE: Atomic Upsert. Document not found, creating ID: " + transactionId);
            updateBuilder.upsert(initialDocument);
        }

        // --- 5. Execute the Request ---
        
        try {
            return client.update(updateBuilder.build(), Map.class);
        } catch (OpenSearchException e) {
            if (e.status() == 409) {
                // This means the update failed after 5 retries due to OCC token mismatch (race condition too intense).
                System.err.println("Fatal OCC Conflict (409) after retries for ID: " + transactionId);
                throw e; 
            }
            throw e; 
        }
    }
}

